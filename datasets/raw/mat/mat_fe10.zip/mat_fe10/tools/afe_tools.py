#!/usr/bin/env python3
"""Automatic Feature Engineering (AFE) low-level primitives for multi-element
catalyst datasets.

Design philosophy: every function here is a SMALL composable primitive that
the agent must chain together. There is NO one-shot "generate_all_features"
function — the agent must decide which commutative operations, which
nonlinear transforms, and which feature combinations to try.

Primitive groups
----------------
1. Composition parsing (catalyst-string -> element fractions)
2. Element-property lookup (XenonPy CSV)
3. Commutative aggregations over catalyst composition
4. Nonlinear single-variable transforms
5. Feature-subset scoring (Huber regression + LOOCV MAE)
6. Genetic-algorithm search for feature subsets (single generation at a time)
7. Plotting: one plot function per answer image item
"""

import csv
import math
import json
import random
from typing import Any

import numpy as np
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("AFE_Catalyst_Tools")


# ---------------------------------------------------------------------------
# 1. Data loading
# ---------------------------------------------------------------------------

@mcp.tool()
def load_catalyst_dataset(csv_path: str, target_column: str) -> dict:
    """Load a catalyst CSV with element-fraction columns and a target column.

    The CSV layout expected: first column = catalyst name (string), middle
    columns = element symbols with their molar/mass fractions per sample,
    final column = the performance target.

    Args:
        csv_path: path to OCM/ETB/TWC-style CSV
        target_column: name of the performance column (e.g., 'C2y',
            'C4H6 yield (%)', 'T50(NO)')

    Returns:
        dict with n_samples, element_columns, target_column, target_values,
        plus a compact preview of the first 3 rows.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    # First column = catalyst name; last meaningful column = target
    name_col = df.columns[0]
    elem_cols = [c for c in df.columns if c not in (name_col, target_column)]
    preview = df.head(3).to_dict(orient="records")
    return {
        "n_samples": int(len(df)),
        "catalyst_name_column": name_col,
        "element_columns": elem_cols,
        "target_column": target_column,
        "target_values": [round(float(v), 4) for v in df[target_column].values],
        "preview": preview,
    }


@mcp.tool()
def clean_catalyst_dataset(csv_path: str, target_column: str,
                           dedup: str = "max",
                           out_csv: str | None = None) -> dict:
    """Clean a catalyst dataset: drop rows with a missing/empty target, then
    collapse duplicate catalyst-name records that carry conflicting targets.

    The OCM dataset in particular contains a few catalyst names that appear
    twice with identical element columns but different target values (e.g.
    Ca-W at 6.2% and 17.7% C2 yield). Because the OCM target is defined as the
    *maximum* C2 yield across the reaction-condition grid, the default
    `dedup='max'` keeps the larger value per name; `dedup='mean'` averages and
    `dedup='first'` keeps the first occurrence.

    Args:
        csv_path: path to the catalyst CSV
        target_column: name of the performance/target column
        dedup: 'max' | 'mean' | 'first' collapse rule for duplicate names
        out_csv: if given, write the cleaned/deduplicated table (name column +
            all element-fraction columns + target column, original column order
            preserved) to this path. The written CSV has the SAME schema as the
            raw dataset CSV, so it can be passed straight back into
            ``aggregate_property_over_composition(dataset_csv=out_csv, ...)``.
            This is the intended way to feed the deduplicated OCM matrix into
            the feature-generation pipeline.

    Returns:
        dict with the cleaned matrix, the per-step row counts, the list of
        duplicate names that were collapsed, the element-fraction columns and
        matrix, and (if ``out_csv`` was given) the written path.
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    name_col = df.columns[0]
    orig_cols = list(df.columns)
    elem_cols = [c for c in orig_cols if c not in (name_col, target_column)]
    n_raw = len(df)
    df = df[df[target_column].notna()]
    df = df[df[target_column].astype(str).str.strip() != ""]
    n_after_empty = len(df)
    dup_names = sorted(df[name_col][df.duplicated(subset=[name_col], keep=False)].unique().tolist())
    if dedup == "max":
        df = df.sort_values(target_column).groupby(name_col, as_index=False).last()
    elif dedup == "mean":
        agg = {c: ("mean" if c == target_column else "first")
               for c in df.columns if c != name_col}
        df = df.groupby(name_col, as_index=False).agg(agg)
    elif dedup == "first":
        df = df.drop_duplicates(subset=[name_col], keep="first")
    else:
        return {"error": f"unknown dedup rule {dedup}"}
    # Preserve the original column order so the written CSV is schema-identical
    # to the raw dataset (name | element columns... | target).
    df = df[orig_cols].reset_index(drop=True)
    n_final = len(df)
    written = None
    if out_csv is not None:
        df.to_csv(out_csv, index=False)
        written = out_csv
    return {
        "n_raw": int(n_raw),
        "n_after_dropping_empty_target": int(n_after_empty),
        "n_duplicate_names_collapsed": len(dup_names),
        "duplicate_names": dup_names,
        "n_modelable": int(n_final),
        "element_columns": elem_cols,
        "catalyst_names": df[name_col].astype(str).tolist(),
        "composition_matrix": df[elem_cols].to_numpy(dtype=float).tolist(),
        "target_values": [round(float(v), 4) for v in df[target_column].values],
        "cleaned_csv_path": written,
    }


@mcp.tool()
def load_element_property_library(csv_path: str) -> dict:
    """Load XenonPy-style normalized element property library.

    Args:
        csv_path: path to xenonpy_normalized.csv (first column = element
            symbol, remaining columns = 58 physicochemical properties).

    Returns:
        dict with list of elements covered, list of property names, and
        total count.
    """
    import pandas as pd
    df = pd.read_csv(csv_path, index_col=0)
    return {
        "n_elements": int(len(df)),
        "elements": list(df.index.astype(str)),
        "n_properties": int(len(df.columns)),
        "property_names": list(df.columns),
    }


# ---------------------------------------------------------------------------
# 2. Primary feature assignment (commutative operations over composition)
# ---------------------------------------------------------------------------

@mcp.tool()
def aggregate_property_over_composition(
    property_csv: str,
    dataset_csv: str,
    target_column: str,
    property_name: str,
    operation: str,
) -> dict:
    """Compute ONE commutative aggregation of ONE element property for every
    catalyst. This is the AFE primary-feature assignment primitive.

    For each catalyst row, look up the given element property for every
    element present (nonzero fraction), then combine according to `operation`.

    Args:
        property_csv: path to the element-property CSV
        dataset_csv: catalyst CSV (element fractions + target)
        target_column: target column name (to exclude from element columns)
        property_name: one column of the property CSV (e.g. 'first_ion_en')
        operation: one of the paper's eight commutative operations
            'max' | 'min' | 'wsum' | 'wavg' | 'wssd' | 'wvar' | 'wprod' | 'gmean'
            max  = max_i p_i            (maximum)
            min  = min_i p_i            (minimum)
            wsum = sum_i f_i * p_i      (weighted sum, f = composition fraction)
            wavg = wsum / sum_i f_i     (weighted average)
            wssd = sum_i f_i * (p_i - mean_p)^2          (weighted sum of squared distance)
            wvar = sum_i f_i * (p_i - mean_p)^2 / sum_i f_i  (weighted average squared distance)
            wprod = prod p_i^{f_i}      (weighted product)
            gmean = (prod p_i^{f_i})^{1/sum f_i}  (weighted geometric mean)
        The eight operations match Taniike et al. (2024): maximum, minimum,
        weighted sum, weighted average, weighted sum of squared distance,
        weighted average squared distance, weighted product, weighted geometric
        mean (58 properties x 8 ops = 464 primary features).

    Returns:
        dict with feature name and list of per-sample values.
    """
    import pandas as pd
    prop = pd.read_csv(property_csv, index_col=0)
    df = pd.read_csv(dataset_csv)
    name_col = df.columns[0]
    elem_cols = [c for c in df.columns if c not in (name_col, target_column)]
    if property_name not in prop.columns:
        return {"error": f"property {property_name} not found"}
    pvec = prop[property_name].reindex(elem_cols).to_numpy(dtype=float)
    if np.isnan(pvec).any():
        missing = [e for e, v in zip(elem_cols, pvec) if np.isnan(v)]
        return {"error": f"missing properties for elements: {missing}"}

    frac = df[elem_cols].to_numpy(dtype=float)
    feat = np.zeros(len(df))
    for i in range(len(df)):
        f = frac[i]
        mask = f > 0
        if not mask.any():
            feat[i] = np.nan
            continue
        p_i = pvec[mask]
        f_i = f[mask]
        if operation == "min":
            feat[i] = p_i.min()
        elif operation == "max":
            feat[i] = p_i.max()
        elif operation == "wsum":
            feat[i] = (f_i * p_i).sum()
        elif operation == "wavg":
            feat[i] = (f_i * p_i).sum() / f_i.sum()
        elif operation == "wssd":
            mp = (f_i * p_i).sum() / f_i.sum()
            feat[i] = (f_i * (p_i - mp) ** 2).sum()
        elif operation == "wvar":
            mp = (f_i * p_i).sum() / f_i.sum()
            feat[i] = (f_i * (p_i - mp) ** 2).sum() / f_i.sum()
        elif operation == "gmean":
            # guard against zero / negative
            safe = np.clip(p_i, 1e-12, None)
            feat[i] = float(np.prod(safe ** f_i) ** (1.0 / f_i.sum()))
        elif operation == "wprod":
            safe = np.clip(p_i, 1e-12, None)
            feat[i] = float(np.prod(safe ** f_i))
        else:
            return {"error": f"unknown operation {operation}"}

    name = f"{property_name}_{operation}"
    return {"feature_name": name, "n_samples": len(feat),
            "values": [round(float(v), 8) for v in feat]}


# ---------------------------------------------------------------------------
# 3. Higher-order nonlinear transforms
# ---------------------------------------------------------------------------

@mcp.tool()
def apply_nonlinear_transform(values: list, transform: str,
                               feature_name: str = "x") -> dict:
    """Apply one nonlinear function to a single primary feature.

    Supported transforms (one per call — chain by calling again):
        'identity', 'inv', 'sqrt', 'inv_sqrt', 'sq', 'inv_sq',
        'cube', 'inv_cube', 'ln', 'inv_ln', 'exp', 'inv_exp'

    Args:
        values: list of floats (output of aggregate_property_over_composition)
        transform: see list above
        feature_name: original feature name for labeling

    Returns:
        dict with transformed feature name and values (NaN if undefined).
    """
    x = np.array(values, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        if transform == "identity":
            y = x; label = feature_name
        elif transform == "inv":
            y = 1.0 / x; label = f"1/({feature_name})"
        elif transform == "sqrt":
            y = np.sqrt(x); label = f"sqrt({feature_name})"
        elif transform == "inv_sqrt":
            y = 1.0 / np.sqrt(x); label = f"1/sqrt({feature_name})"
        elif transform == "sq":
            y = x ** 2; label = f"({feature_name})^2"
        elif transform == "inv_sq":
            y = 1.0 / (x ** 2); label = f"1/({feature_name})^2"
        elif transform == "cube":
            y = x ** 3; label = f"({feature_name})^3"
        elif transform == "inv_cube":
            y = 1.0 / (x ** 3); label = f"1/({feature_name})^3"
        elif transform == "ln":
            y = np.log(x); label = f"ln({feature_name})"
        elif transform == "inv_ln":
            y = 1.0 / np.log(x); label = f"1/ln({feature_name})"
        elif transform == "exp":
            y = np.exp(x); label = f"exp({feature_name})"
        elif transform == "inv_exp":
            y = 1.0 / np.exp(x); label = f"1/exp({feature_name})"
        else:
            return {"error": f"unknown transform {transform}"}
    y_out = [round(float(v), 8) if np.isfinite(v) else None for v in y]
    return {"feature_name": label, "values": y_out}


@mcp.tool()
def combine_features_product(values_a: list, values_b: list,
                              name_a: str = "A", name_b: str = "B") -> dict:
    """Second-order feature = elementwise product of two first-order features.

    Args:
        values_a: list of floats
        values_b: list of floats (same length)
        name_a, name_b: labels
    """
    a = np.array(values_a, dtype=float)
    b = np.array(values_b, dtype=float)
    y = a * b
    return {"feature_name": f"({name_a})*({name_b})",
            "values": [round(float(v), 8) if np.isfinite(v) else None for v in y]}


# ---------------------------------------------------------------------------
# 4. Feature-subset scoring (Huber + LOOCV-MAE)
# ---------------------------------------------------------------------------

@mcp.tool()
def huber_loocv_mae(features: list, target: list, epsilon: float = 1.0) -> dict:
    """Score a candidate feature subset by leave-one-out CV MAE under Huber
    regression.

    Args:
        features: list of per-feature value-lists (k features of length n)
            or an n-by-k matrix as list-of-lists (each inner list = one row)
        target: length-n list of target values
        epsilon: Huber loss threshold (paper uses 1.00)

    Returns:
        dict with train_mae, loocv_mae, n_samples, n_features.
    """
    from sklearn.linear_model import HuberRegressor
    from sklearn.model_selection import LeaveOneOut, cross_val_score
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler

    X = np.array(features, dtype=float)
    # Accept either (k, n) feature-major or (n, k) row-major
    y = np.array(target, dtype=float)
    if X.ndim != 2:
        return {"error": "features must be 2-D"}
    if X.shape[0] == len(y):
        Xr = X
    elif X.shape[1] == len(y):
        Xr = X.T
    else:
        return {"error": f"shape mismatch features {X.shape} target {len(y)}"}

    # drop any rows with NaN / inf
    mask = np.isfinite(Xr).all(axis=1) & np.isfinite(y)
    Xr = Xr[mask]; y = y[mask]
    if len(y) < 5:
        return {"error": "too few finite samples"}

    # Standardize features before the (scale-sensitive) Huber fit; the paper
    # normalizes/shifts features to prevent first-order divergence. Wrapping the
    # regressor in a StandardScaler avoids l-BFGS-b convergence failures on
    # poorly-scaled candidate subsets.
    def _make():
        return make_pipeline(
            StandardScaler(),
            HuberRegressor(max_iter=5000, epsilon=epsilon))
    try:
        lr = _make()
        lr.fit(Xr, y)
        train_pred = lr.predict(Xr)
        train_mae = float(np.mean(np.abs(train_pred - y)))
        cv = LeaveOneOut()
        scores = cross_val_score(lr, Xr, y, cv=cv,
                                 scoring="neg_mean_absolute_error",
                                 error_score=np.nan)
        finite = scores[np.isfinite(scores)]
        if finite.size == 0:
            return {"error": "Huber regression did not converge for this subset",
                    "n_samples": int(len(y)), "n_features": int(Xr.shape[1])}
        cv_mae = float(-np.mean(finite))
    except (ValueError, FloatingPointError) as exc:
        return {"error": f"Huber regression failed: {exc}",
                "n_samples": int(len(y)), "n_features": int(Xr.shape[1])}
    reg = lr.named_steps["huberregressor"]

    return {
        "train_mae": round(train_mae, 4),
        "loocv_mae": round(cv_mae, 4),
        "n_samples": int(len(y)),
        "n_features": int(Xr.shape[1]),
        "coefficients": [round(float(c), 4) for c in reg.coef_],
        "intercept": round(float(reg.intercept_), 4),
    }


@mcp.tool()
def huber_fit_predict(features: list, target: list,
                       epsilon: float = 1.0) -> dict:
    """Fit Huber regression on full data and return in-sample predictions.
    Useful for parity plots. Features are standardized before the fit.

    Args:
        features: 2-D (n_samples, n_features) list of lists
        target: length-n target values
        epsilon: Huber epsilon

    Returns:
        dict with predictions, coefficients, intercept.
    """
    from sklearn.linear_model import HuberRegressor
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    X = np.array(features, dtype=float)
    y = np.array(target, dtype=float)
    if X.shape[0] != len(y) and X.shape[1] == len(y):
        X = X.T
    mask = np.isfinite(X).all(axis=1) & np.isfinite(y)
    X = X[mask]; y = y[mask]
    lr = make_pipeline(StandardScaler(),
                       HuberRegressor(max_iter=5000, epsilon=epsilon))
    lr.fit(X, y)
    pred = lr.predict(X)
    reg = lr.named_steps["huberregressor"]
    return {
        "predictions": [round(float(v), 4) for v in pred],
        "targets": [round(float(v), 4) for v in y],
        "train_mae": round(float(np.mean(np.abs(pred - y))), 4),
        "coefficients": [round(float(c), 4) for c in reg.coef_],
        "intercept": round(float(reg.intercept_), 4),
    }


# ---------------------------------------------------------------------------
# 5. Genetic-algorithm building blocks (one step at a time)
# ---------------------------------------------------------------------------

@mcp.tool()
def ga_random_population(feature_names: list, n_population: int = 100,
                          subset_size: int = 8, seed: int = 0) -> dict:
    """Initial GA population: each individual = `subset_size` distinct feature
    names picked uniformly from `feature_names`.

    Args:
        feature_names: pool of candidate feature column names
        n_population: number of individuals
        subset_size: features per individual (paper uses 8)
        seed: RNG seed

    Returns:
        dict with 'population' list of subsets.
    """
    rng = random.Random(seed)
    pop = []
    for _ in range(n_population):
        pop.append(rng.sample(list(feature_names), subset_size))
    return {"population": pop, "n_population": n_population,
            "subset_size": subset_size}


@mcp.tool()
def ga_crossover_mutate(parent_a: list, parent_b: list,
                         all_features: list, mutation_rate: float = 0.05,
                         seed: int = 0) -> dict:
    """Uniform crossover of two parents + random mutation. Returns one child.

    Args:
        parent_a, parent_b: lists of feature names (same length)
        all_features: full feature pool for mutation replacement
        mutation_rate: per-gene probability of replacement
        seed: RNG seed

    Returns:
        dict with 'child' = list of feature names (de-duplicated,
        same length as parent_a).
    """
    rng = random.Random(seed)
    n = len(parent_a)
    child = []
    used = set()
    for i in range(n):
        cand = rng.choice([parent_a[i], parent_b[i]])
        if rng.random() < mutation_rate or cand in used:
            # pick a fresh feature
            while True:
                cand = rng.choice(list(all_features))
                if cand not in used:
                    break
        child.append(cand)
        used.add(cand)
    return {"child": child}


OPS_ALL = ("max", "min", "wsum", "wavg", "wssd", "wvar", "wprod", "gmean")
TRANSFORMS_ALL = ("identity", "inv", "sqrt", "inv_sqrt", "sq", "inv_sq",
                  "cube", "inv_cube", "ln", "inv_ln", "exp", "inv_exp")


# NOTE: This is an INTERNAL reference/verification helper, NOT an exposed MCP
# tool. It is deliberately undecorated (no @mcp.tool()) and underscore-prefixed
# so a solver cannot call one tool that hands back the final selected-feature
# subset + train/LOOCV MAE (that would be answer-leakage). The solver must
# instead COMPOSE the exposed primitives — aggregate_property_over_composition
# (8 ops) -> apply_nonlinear_transform (12 transforms) -> a correlation rank /
# greedy or GA loop -> huber_loocv_mae — to derive the result itself. This
# function is retained only so the [PIPELINE] answer numbers stay exactly
# reproducible offline; it reproduces what the composed primitive workflow
# yields.
def _afe_select_features_deterministic(property_csv: str, dataset_csv: str,
                                      target_column: str, dedup: str = "max",
                                      subset_size: int = 8,
                                      corr_pool: int = 25,
                                      epsilon: float = 1.0) -> dict:
    """Reproducible (deterministic) AFE feature search + scoring (INTERNAL).

    This is a PINNED, seed-free alternative to the stochastic genetic-algorithm
    search. It (1) optionally de-duplicates the dataset, (2) builds the full
    first-order feature pool (8 commutative ops x 58 properties x 12 nonlinear
    transforms = 5,568 candidates), dropping features with any non-finite value
    or zero variance, (3) ranks survivors by absolute Pearson correlation with
    the target, (4) keeps the top ``corr_pool`` as a candidate pool, then (5)
    greedily forward-selects ``subset_size`` features that minimise Huber-LOOCV
    MAE. Because every step is deterministic, the returned feature names,
    train MAE and LOOCV MAE reproduce exactly on every run.

    Not exposed as an MCP tool: a solver must reconstruct this workflow from the
    composable primitives; this helper only fixes the reference [PIPELINE]
    numbers reported in the answer.

    Note: the paper uses a multi-generation genetic algorithm and reports
    smaller MAE; this deterministic greedy is a reproducible lower-bound
    surrogate, so its MAE is expected to be somewhat higher than the paper's
    GA-optimised values.

    Args:
        property_csv: xenonpy_normalized.csv
        dataset_csv: OCM/ETB/TWC catalyst CSV
        target_column: target column name
        dedup: 'max'|'mean'|'first'|'none' (OCM should use 'max')
        subset_size: features to select (paper uses 8)
        corr_pool: size of the correlation-ranked candidate pool
        epsilon: Huber epsilon

    Returns:
        dict with selected_features, train_mae, loocv_mae, n_samples,
        n_feature_pool, primary_count, first_order_count.
    """
    import pandas as pd
    src = dataset_csv
    if dedup and dedup != "none":
        clean = clean_catalyst_dataset(dataset_csv, target_column,
                                       dedup=dedup, out_csv="/tmp/_afe_clean.csv")
        if "error" in clean:
            return clean
        src = "/tmp/_afe_clean.csv"
    prop = pd.read_csv(property_csv, index_col=0)
    props = list(prop.columns)
    df = pd.read_csv(src)
    y = df[target_column].to_numpy(dtype=float)
    names: list[str] = []
    cols: list[np.ndarray] = []
    for p in props:
        for op in OPS_ALL:
            r = aggregate_property_over_composition(property_csv, src,
                                                    target_column, p, op)
            if "values" not in r:
                continue
            base = np.asarray(r["values"], dtype=float)
            for t in TRANSFORMS_ALL:
                tr = apply_nonlinear_transform(base.tolist(), t, r["feature_name"])
                vals = np.asarray([np.nan if v is None else v
                                   for v in tr["values"]], dtype=float)
                if np.isfinite(vals).sum() < len(vals):
                    continue
                if np.nanstd(vals) < 1e-9:
                    continue
                names.append(tr["feature_name"])
                cols.append(vals)
    if not cols:
        return {"error": "no finite feature columns generated"}
    M = np.column_stack(cols)
    fin = np.isfinite(M).all(axis=1) & np.isfinite(y)
    M = M[fin]; yv = y[fin]
    cors = np.array([abs(np.corrcoef(M[:, j], yv)[0, 1])
                     if np.std(M[:, j]) > 0 else 0.0 for j in range(M.shape[1])])
    cors[~np.isfinite(cors)] = 0.0
    pool = list(np.argsort(cors)[::-1][:corr_pool])
    chosen: list[int] = []
    remaining = list(pool)

    def _score(idxs):
        res = huber_loocv_mae(M[:, idxs].T.tolist(), yv.tolist(), epsilon=epsilon)
        return res.get("loocv_mae"), res.get("train_mae")

    while len(chosen) < subset_size and remaining:
        best_j = None; best_cv = float("inf")
        for j in remaining:
            cv, _ = _score(chosen + [j])
            if cv is not None and cv < best_cv:
                best_cv = cv; best_j = j
        if best_j is None:
            break
        chosen.append(best_j); remaining.remove(best_j)
    cv, tr = _score(chosen)
    return {
        "selected_features": [names[j] for j in chosen],
        "n_selected": len(chosen),
        "train_mae": round(float(tr), 4) if tr is not None else None,
        "loocv_mae": round(float(cv), 4) if cv is not None else None,
        "n_samples": int(len(yv)),
        "n_feature_pool": int(M.shape[1]),
        "primary_count": len(props) * len(OPS_ALL),
        "first_order_count": len(props) * len(OPS_ALL) * len(TRANSFORMS_ALL),
        "dedup": dedup,
    }


@mcp.tool()
def build_feature_matrix_from_csv(csv_path: str, feature_names: list) -> dict:
    """Look up a list of named feature columns in a precomputed feature CSV
    (e.g., the repo's *_dataset_with_1st_order_features.csv).

    Args:
        csv_path: path to feature CSV
        feature_names: list of column names to extract

    Returns:
        dict with 2-D matrix (rows x len(feature_names)) and shape.
    """
    import pandas as pd
    df = pd.read_csv(csv_path, index_col=0)
    missing = [f for f in feature_names if f not in df.columns]
    if missing:
        return {"error": f"missing columns: {missing[:5]}..."}
    mat = df[list(feature_names)].to_numpy(dtype=float).tolist()
    return {"n_rows": len(mat), "n_features": len(feature_names),
            "matrix": mat}


# ---------------------------------------------------------------------------
# 6. Farthest-point sampling in feature space (active-learning helper)
# ---------------------------------------------------------------------------

@mcp.tool()
def farthest_point_sampling(features: list, n_select: int,
                             seed_index: int = 0) -> dict:
    """Greedy farthest-point sampling in Euclidean feature space.

    Args:
        features: 2-D list (n_points, n_features) — typically the AFE-
            selected features over a candidate catalyst pool
        n_select: number of points to pick
        seed_index: starting index

    Returns:
        dict with 'selected_indices' (ordered list of picked indices).
    """
    X = np.array(features, dtype=float)
    n = X.shape[0]
    picked = [seed_index]
    dists = np.linalg.norm(X - X[seed_index], axis=1)
    for _ in range(1, n_select):
        nxt = int(np.argmax(dists))
        picked.append(nxt)
        new_d = np.linalg.norm(X - X[nxt], axis=1)
        dists = np.minimum(dists, new_d)
    return {"selected_indices": picked, "n_selected": len(picked)}


# ---------------------------------------------------------------------------
# 7. t-SNE embedding (for machine-perception visualization)
# ---------------------------------------------------------------------------

@mcp.tool()
def tsne_embed(features: list, perplexity: float = 30.0,
                random_state: int = 0) -> dict:
    """Project a feature matrix into 2-D via t-SNE.

    Args:
        features: 2-D list of shape (n_points, n_features)
        perplexity: t-SNE perplexity
        random_state: RNG seed

    Returns:
        dict with list of (x, y) pairs.
    """
    from sklearn.manifold import TSNE
    X = np.array(features, dtype=float)
    mask = np.isfinite(X).all(axis=1)
    Xg = X[mask]
    emb = TSNE(n_components=2, perplexity=perplexity,
               random_state=random_state, init="pca").fit_transform(Xg)
    coords = [[round(float(a), 4), round(float(b), 4)] for a, b in emb]
    return {"coords": coords, "n_points": len(coords),
            "kept_mask": mask.tolist()}


# ---------------------------------------------------------------------------
# 8. Plot functions — one per answer image item
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_parity(predictions_by_panel: dict,
                 output_path: str,
                 xlabels: list = None,
                 ylabels: list = None,
                 titles: list = None) -> dict:
    """Multi-panel parity plot (observed vs predicted) reproducing Fig. 1b-d.

    Args:
        predictions_by_panel: dict with keys 'OCM', 'ETB', 'TWC' (or similar)
            each mapping to {'observed': [...], 'predicted': [...]}
        output_path: png path (e.g. artifacts/fig1_parity.png)
        xlabels, ylabels, titles: per-panel strings (optional)

    Returns:
        dict with output_path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    panels = list(predictions_by_panel.keys())
    n = len(panels)
    fig, axes = plt.subplots(1, n, figsize=(5 * n, 5))
    if n == 1:
        axes = [axes]
    for i, k in enumerate(panels):
        obs = np.array(predictions_by_panel[k]["observed"])
        prd = np.array(predictions_by_panel[k]["predicted"])
        ax = axes[i]
        ax.scatter(obs, prd, alpha=0.55, s=22, c="#3570b2")
        lims = [min(obs.min(), prd.min()), max(obs.max(), prd.max())]
        ax.plot(lims, lims, "k--", lw=1, alpha=0.5)
        ax.set_xlabel(xlabels[i] if xlabels else f"Observed ({k})")
        ax.set_ylabel(ylabels[i] if ylabels else f"Predicted ({k})")
        ax.set_title(titles[i] if titles else k)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_panels": n}


@mcp.tool()
def plot_active_learning_scores(cycles: list, mae_train: list,
                                  mae_cv: list, mae_test: list,
                                  output_path: str) -> dict:
    """Bar/line chart of active-learning training/CV/test MAE per cycle —
    reproduces Fig. 2b.

    Args:
        cycles: list of cycle indices (e.g. [0,1,2,3,4])
        mae_train, mae_cv, mae_test: equal-length lists of MAE values
        output_path: png path

    Returns:
        dict with output_path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    c = np.array(cycles)
    w = 0.35
    fig, ax1 = plt.subplots(figsize=(7, 5))
    ax1.bar(c - w/2, mae_train, width=w, label="Train MAE", color="#a6c8ec")
    ax1.bar(c + w/2, mae_cv,    width=w, label="CV MAE",    color="#bababa")
    ax1.set_xlabel("Active learning cycle")
    ax1.set_ylabel("MAE$_{train,CV}$ (%)")
    ax1.set_xticks(c)
    ax2 = ax1.twinx()
    ax2.plot(c, mae_test, "o-", color="#1f5faa", label="Test MAE")
    ax2.set_ylabel("MAE$_{test}$ (%)")
    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines + lines2, labels + labels2, loc="upper right")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_cycles": len(cycles)}


@mcp.tool()
def plot_tsne_yield_map(coords: list, target_values: list,
                         highlight_indices: list = None,
                         output_path: str = "artifacts/tsne_map.png",
                         cbar_label: str = "C2 yield (%)",
                         cycle: int = None) -> dict:
    """2-D t-SNE scatter colored by yield — reproduces Fig. 2d / Fig. 3.

    When producing one t-SNE per active-learning cycle, pass a distinct
    `cycle` index (or a distinct `output_path`) so successive calls do NOT
    overwrite the same file: if `cycle` is given, the cycle index is inserted
    before the extension (e.g. tsne_map.png -> tsne_map_cycle3.png).

    Args:
        coords: list of (x, y) pairs from tsne_embed
        target_values: per-point target (color)
        highlight_indices: optional indices to circle (test set)
        output_path: png path
        cbar_label: colorbar label
        cycle: optional active-learning cycle index used to disambiguate the
            output filename so per-cycle plots are not overwritten.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import os
    if cycle is not None:
        root, ext = os.path.splitext(output_path)
        output_path = f"{root}_cycle{cycle}{ext}"
    c = np.array(coords)
    v = np.array(target_values, dtype=float)
    fig, ax = plt.subplots(figsize=(8, 7))
    sc = ax.scatter(c[:, 0], c[:, 1], c=v, cmap="jet", s=18, alpha=0.85)
    if highlight_indices:
        ax.scatter(c[highlight_indices, 0], c[highlight_indices, 1],
                   facecolors="none", edgecolors="k", s=55, linewidths=0.9)
    ax.set_xlabel("t-SNE 1"); ax.set_ylabel("t-SNE 2")
    cb = fig.colorbar(sc, ax=ax); cb.set_label(cbar_label)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path}


@mcp.tool()
def plot_discovery_bars(catalyst_names: list, observed_yields: list,
                         threshold: float = 15.0,
                         output_path: str = "artifacts/discovery.png") -> dict:
    """Bar chart of experimentally measured yields for a recommended catalyst
    set, colored by whether they cross a threshold — reproduces Fig. 4.

    Args:
        catalyst_names: labels on x-axis
        observed_yields: measured yield (%)
        threshold: cutoff for color split
        output_path: png path
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    y = np.array(observed_yields, dtype=float)
    colors = ["#1f5faa" if yi >= 18 else ("#6ba4d7" if yi >= threshold else "#cccccc") for yi in y]
    fig, ax = plt.subplots(figsize=(max(8, 0.35 * len(y)), 5))
    ax.bar(range(len(y)), y, color=colors)
    ax.set_xticks(range(len(y)))
    ax.set_xticklabels(catalyst_names, rotation=90, fontsize=7)
    ax.axhline(threshold, color="k", ls="--", lw=0.8)
    ax.set_ylabel("Observed C$_2$ yield (%)")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return {"output_path": output_path, "n_catalysts": len(y),
            "n_above_threshold": int((y >= threshold).sum()),
            "n_above_18": int((y >= 18).sum())}


if __name__ == "__main__":
    mcp.run(transport="stdio")
