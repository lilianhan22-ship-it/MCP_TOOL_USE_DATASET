# mat_fe10 tools

Tools for the Automatic Feature Engineering (AFE) catalyst task.

## Layout

| File | Kind | Purpose |
|------|------|---------|
| `afe_tools.py`         | **FastMCP server** (`AFE_Catalyst_Tools`) | Domain-specific primitives exposed as MCP tools: composition parsing, XenonPy property lookup, commutative aggregations, nonlinear transforms, Huber + LOOCV scorer, GA building blocks, FPS, t-SNE, plotters. This is the only MCP server in the bundle. |
| `data_processing.py`   | Plain Python module (not an MCP server) | Generic CSV / JSON / tabular helpers (`read_csv`, `join_tables`, `groupby_aggregate`, ...) imported directly as functions. |
| `database_retrieval.py`| Plain Python module (not an MCP server) | Optional external-database query helpers (`websearch`, `query_*`). Not needed for this task — every input is bundled locally — and intentionally left unimplemented (`pass`). |

> Only `afe_tools.py` registers an MCP server (`mcp = FastMCP(...)` with
> `@mcp.tool()` decorators). `data_processing.py` and `database_retrieval.py`
> are ordinary importable modules, NOT MCP servers, and expose no MCP tools.

## Design notes

* **Low-level primitives only.** There is deliberately no one-shot
  `generate_all_5568_features()` function. The agent must choose which of the
  paper's eight commutative operations
  (`max/min/wsum/wavg/wssd/wvar/wprod/gmean` = maximum, minimum, weighted sum,
  weighted average, weighted sum of squared distance, weighted average squared
  distance, weighted product, weighted geometric mean) and which of 12
  nonlinear transforms (`identity/inv/sqrt/inv_sqrt/sq/inv_sq/cube/inv_cube/
  ln/inv_ln/exp/inv_exp`) to compose. The solver drives feature selection
  itself — either the stochastic GA loop (`ga_random_population` → score with
  `huber_loocv_mae` → `ga_crossover_mutate` → repeat) or a deterministic
  correlation-rank + greedy forward selection built from the same primitives
  (`aggregate_property_over_composition` → `apply_nonlinear_transform` →
  `huber_loocv_mae`). There is intentionally **no exposed one-shot tool that
  returns the selected features + MAE** (that would leak the answer); the
  selection must be composed from the primitives. Eight ops × 58 XenonPy
  properties = **464 primary features**; × 12 transforms = **5,568 first-order
  features** (these counts reproduce exactly on the bundled data).
* **Dataset cleaning.** `clean_catalyst_dataset` drops any empty/NaN-target
  rows (the bundled OCM CSV has none — all 171 rows carry a numeric C2y) and
  collapses duplicate catalyst names. The OCM CSV has 171 rows; four names
  recur — Ca-W, Mg-Pd-Ce, Pd-W-W, Sr-Zr-La — leaving **167** unique modelable
  catalysts after keeping the maximum C2 yield per name (171 → 171 after the
  empty-target pass → 167 after dedup). ETB (177) and TWC (51) have no
  duplicate names and are used as-is. Pass `out_csv=` to
  write the de-duplicated table back out with the SAME schema as the raw CSV;
  that written file feeds straight into
  `aggregate_property_over_composition(dataset_csv=out_csv, ...)`, so the
  dedup → feature-generation pipeline is fully connected (the dedup result also
  returns `element_columns` + `composition_matrix` for direct use).
* **Reproducible (pinned) selection — internal reference only.** The module
  contains an undecorated, underscore-prefixed helper
  `_afe_select_features_deterministic` that is **NOT exposed as an MCP tool**.
  It is a seed-free deterministic recipe (build the full 5,568-feature pool,
  rank by absolute Pearson correlation, keep the top `corr_pool` = 25, then
  greedily forward-select 8 features minimising Huber-LOOCV MAE). It exists only
  to verify the recipe offline; a solver must reconstruct the same recipe by
  composing the exposed primitives rather than calling a single tool that hands
  back the answer. The deterministic-greedy surrogate is expected to return a
  somewhat higher MAE than the paper's multi-generation genetic algorithm, since
  a single greedy pass over a correlation-pruned pool explores far fewer feature
  combinations than a multi-generation GA. The solver computes the actual train
  and LOOCV MAE per dataset itself by running the composed primitive workflow;
  no MAE values are pre-tabulated here.
* **Huber + LOOCV** is the paper's scoring target; `epsilon` defaults to
  1.00. Features are standardized (StandardScaler) inside the scorer to keep
  the scale-sensitive Huber solver convergent; subsets that still fail to
  converge return an `error` key rather than raising.
* **No precomputed-feature shortcut.** Although the paper's public repo
  ships `*_dataset_with_1st_order_features.csv` with 3300 features already
  expanded, that file is NOT included in this task's `input_data/`. The
  agent must rebuild features from `xenonpy_normalized.csv` and the three
  composition CSVs.
* **Plotters.** The reproducible deliverable is the parity figure:
  * `plot_parity` → `Fig1_AFE_regression.png` (the only bundled answer image).
  * `plot_active_learning_scores`, `plot_tsne_yield_map` (per-cycle: pass a
    distinct `cycle` index so successive calls do not overwrite the same PNG)
    and `plot_discovery_bars` remain available, but the active-learning cycle
    splits, the farthest-point-sampling recommendation list and the HTE
    observations are NOT bundled, so the active-learning evolution and the
    discovery results are paper-only ([PAPER]) and are not scored figures.

## Python dependencies

```
numpy
pandas
scikit-learn
matplotlib
mcp  # FastMCP server
```

Install with:
```bash
pip install numpy pandas scikit-learn matplotlib mcp
```

## How to run

`afe_tools.py` is the MCP server:

```bash
python tools/afe_tools.py          # stdio transport
```

Every `@mcp.tool()`-decorated function in `afe_tools.py` also remains a plain
callable, so it can be imported directly in a notebook/test for offline
debugging. `data_processing.py` / `database_retrieval.py` are imported as plain
modules.
