# Tools

This directory follows the three-layer task-tool structure.

- `data_processing.py`: file discovery, workbook ingestion, archive inspection, numeric coercion, robust z-scoring, and tidy-table helpers.
- `database_retrieval.py`: local inventory, article-link extraction, and public repository discovery.
- `information_tools.py`: domain-specific primitives for reproducing the paper's public workflow without requiring the agent to invent core analysis code.

The tools intentionally expose reusable workflow primitives rather than a one-click answer script. Intermediate analyses belong here; `task_content.json` only states the scientific objective and final report requirement.
