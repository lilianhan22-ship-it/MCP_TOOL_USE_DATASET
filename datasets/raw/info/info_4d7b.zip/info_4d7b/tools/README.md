This tools folder is organized into three layers.

- `information_tools.py`: domain primitives for individual-based good-science simulation, replication sweeps, theory-replication interaction checks, and artifact generation.
- `data_processing.py`: generic file-listing and text-reading helpers.
- `database_retrieval.py`: local code/reference inventory and PDF-text helpers.

Use the domain tool to compose the evolutionary-model reproduction workflow without relying on a one-click final answer.
