# Tools

- `data_processing.py`: CSV/table readers and plot output helpers.
- `database_retrieval.py`: local file inventory helpers for the citation-diversity bundle.
- `information_tools.py`: composable OA/non-OA citation-diversity primitives.

Key primitives:

- `oa_diversity_gap_summary(data_root)`: yearly OA-minus-non-OA diversity gaps.
- `citation_count_diversity_summary(data_root)`: overall median diversity as a function of citation count; the source table is not an OA/non-OA contrast.
- `field_diversity_summary(data_root)`: latest-year field-level OA gaps.
- `subregion_diversity_summary(data_root)`: computes Shannon diversity from `subregion_citing_count` by `(subregion_cited, year, is_oa)`.
- `table_schema_inventory(data_root)`: verifies required released tables and columns without returning final numeric answers.
- `plot_two_series`, `plot_single_series`, `plot_ranked_bars`: generic plotting primitives where the caller supplies columns, labels, and output path.

The tools intentionally do not create the final scored artifact paths directly; the solver must compose summaries, choose checkpoint rows, and save final artifacts.
