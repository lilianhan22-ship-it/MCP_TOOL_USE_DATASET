
from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _repo(data_root: str) -> Path:
    p = Path(data_root)
    if (p / 'Curtin-Open-Knowledge-Initiative-citation-diversity-ee3e8e0').exists():
        return p / 'Curtin-Open-Knowledge-Initiative-citation-diversity-ee3e8e0' / 'tempdata'
    if (p / 'tempdata').exists():
        return p / 'tempdata'
    if (p / 'data' / 'summary_stats_by_year_atleast2cit.csv').exists():
        return p / 'data'
    return p


def oa_diversity_gap_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'summary_stats_by_year_atleast2cit.csv')
    df = df.copy()
    df['country_gap'] = df['oa_Countries_Shannon_mean'] - df['noa_Countries_Shannon_mean']
    df['institution_gap'] = df['oa_Institutions_Shannon_mean'] - df['noa_Institutions_Shannon_mean']
    df['subregion_gap'] = df['oa_Subregions_Shannon_mean'] - df['noa_Subregions_Shannon_mean']
    df['region_gap'] = df['oa_Regions_Shannon_mean'] - df['noa_Regions_Shannon_mean']
    df['field_gap'] = df['oa_Fields_Shannon_mean'] - df['noa_Fields_Shannon_mean']
    return {
        'yearly_gaps': df[['year', 'country_gap', 'institution_gap', 'subregion_gap', 'region_gap', 'field_gap']].to_dict('records'),
        'mean_country_gap': float(df['country_gap'].mean()),
        'mean_institution_gap': float(df['institution_gap'].mean()),
        'mean_subregion_gap': float(df['subregion_gap'].mean()),
        'mean_region_gap': float(df['region_gap'].mean()),
        'mean_field_gap': float(df['field_gap'].mean()),
        'latest_year': int(df['year'].max()),
        'latest_year_country_gap': float(df.loc[df['year'] == df['year'].max(), 'country_gap'].iloc[0]),
        'latest_year_institution_gap': float(df.loc[df['year'] == df['year'].max(), 'institution_gap'].iloc[0]),
        'latest_year_subregion_gap': float(df.loc[df['year'] == df['year'].max(), 'subregion_gap'].iloc[0]),
        'latest_year_region_gap': float(df.loc[df['year'] == df['year'].max(), 'region_gap'].iloc[0]),
        'latest_year_field_gap': float(df.loc[df['year'] == df['year'].max(), 'field_gap'].iloc[0]),
    }


def citation_count_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_vs_cit_count.csv')
    # Aggregate over years and summarize the monotone relationship for countries Shannon.
    g = df.groupby('CitationCount', as_index=False)['CitingCountries_Shannon_perc50'].median()
    low = float(g['CitingCountries_Shannon_perc50'].iloc[0])
    high = float(g['CitingCountries_Shannon_perc50'].iloc[-1])
    return {
        'rows': int(len(df)),
        'citation_count_min': int(df['CitationCount'].min()),
        'citation_count_max': int(df['CitationCount'].max()),
        'median_country_shannon_first': low,
        'median_country_shannon_last': high,
        'median_country_shannon_trajectory_sample': g.head(10).to_dict('records'),
    }


def field_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_by_field.csv')
    latest = df[df['year'] == df['year'].max()].copy()
    latest['country_gap'] = latest['oa_CitingCountries_Shannon_mean'] - latest['noa_CitingCountries_Shannon_mean']
    top = latest.sort_values('country_gap', ascending=False).head(8)
    return {
        'latest_year': int(latest['year'].max()),
        'top_country_gaps': top[['field', 'country_gap', 'oa_CitingCountries_Shannon_mean', 'noa_CitingCountries_Shannon_mean']].to_dict('records'),
    }


def subregion_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'summary_stats_by_subregion_atleast2cit.csv')
    # Build Shannon diversity per (cited_subregion, year, OA-status) from citing-subregion counts.
    g = (
        df.groupby(['subregion_cited', 'year', 'is_oa', 'subregion_citing'], as_index=False)['subregion_citing_count']
        .sum()
    )
    rows = []
    for (subregion, year, is_oa), chunk in g.groupby(['subregion_cited', 'year', 'is_oa']):
        counts = chunk['subregion_citing_count'].to_numpy(dtype=float)
        total = counts.sum()
        if total <= 0:
            continue
        probs = counts / total
        shannon = float(-(probs * np.log(probs)).sum())
        rows.append({'subregion_cited': subregion, 'year': int(year), 'is_oa': bool(is_oa), 'shannon': shannon})

    sh = pd.DataFrame(rows)
    if sh.empty:
        return {'rows': 0, 'latest_year': None, 'top_subregions': []}

    latest_year = int(sh['year'].max())
    latest = sh[sh['year'] == latest_year]
    oa = latest[latest['is_oa']][['subregion_cited', 'shannon']].rename(columns={'shannon': 'oa_shannon'})
    noa = latest[~latest['is_oa']][['subregion_cited', 'shannon']].rename(columns={'shannon': 'noa_shannon'})
    merged = oa.merge(noa, on='subregion_cited', how='inner')
    merged['oa_minus_noa_gap'] = merged['oa_shannon'] - merged['noa_shannon']
    top = merged.sort_values('oa_minus_noa_gap', ascending=False).head(10)

    return {
        'rows': int(len(sh)),
        'latest_year': latest_year,
        'top_subregions': top[['subregion_cited', 'oa_shannon', 'noa_shannon', 'oa_minus_noa_gap']].to_dict('records'),
    }



def checkpoint_rows_from_summaries(data_root: str, target_year: int | None = None) -> list[dict]:
    """Return candidate numeric checkpoint rows without writing final artifacts.

    This is a generic table primitive: callers choose which rows to report and
    where to save them. It avoids hard-coding the benchmark artifact path.
    """
    temp = _repo(data_root)
    year_df = pd.read_csv(temp / 'summary_stats_by_year_atleast2cit.csv')
    count_df = pd.read_csv(temp / 'cit_div_vs_cit_count.csv')
    field_df = pd.read_csv(temp / 'cit_div_by_field.csv')
    if target_year is None or target_year not in set(int(y) for y in year_df['year'].unique()):
        target_year = int(year_df['year'].max())
    year_row = year_df[year_df['year'] == target_year].iloc[0]
    count_med = count_df.groupby('CitationCount', as_index=False)['CitingCountries_Shannon_perc50'].median()
    latest_field = field_df[field_df['year'] == field_df['year'].max()].copy()
    latest_field['country_gap'] = latest_field['oa_CitingCountries_Shannon_mean'] - latest_field['noa_CitingCountries_Shannon_mean']
    top_field_row = latest_field.sort_values('country_gap', ascending=False).iloc[0]
    subregion = subregion_diversity_summary(data_root)
    top_sub = subregion['top_subregions'][0] if subregion.get('top_subregions') else {}
    return [
        {'metric': 'oa_country_shannon_mean', 'value': float(year_row['oa_Countries_Shannon_mean']), 'year': int(target_year), 'source_file': 'summary_stats_by_year_atleast2cit.csv'},
        {'metric': 'non_oa_country_shannon_mean', 'value': float(year_row['noa_Countries_Shannon_mean']), 'year': int(target_year), 'source_file': 'summary_stats_by_year_atleast2cit.csv'},
        {'metric': 'oa_subregion_shannon_mean', 'value': float(year_row['oa_Subregions_Shannon_mean']), 'year': int(target_year), 'source_file': 'summary_stats_by_year_atleast2cit.csv'},
        {'metric': 'non_oa_subregion_shannon_mean', 'value': float(year_row['noa_Subregions_Shannon_mean']), 'year': int(target_year), 'source_file': 'summary_stats_by_year_atleast2cit.csv'},
        {'metric': 'country_shannon_lowest_citation_bin', 'value': float(count_med.iloc[0]['CitingCountries_Shannon_perc50']), 'citation_count': int(count_med.iloc[0]['CitationCount']), 'source_file': 'cit_div_vs_cit_count.csv'},
        {'metric': 'country_shannon_highest_citation_bin', 'value': float(count_med.iloc[-1]['CitingCountries_Shannon_perc50']), 'citation_count': int(count_med.iloc[-1]['CitationCount']), 'source_file': 'cit_div_vs_cit_count.csv'},
        {'metric': 'largest_field_country_gap', 'value': float(top_field_row['country_gap']), 'field': str(top_field_row['field']), 'year': int(top_field_row['year']), 'source_file': 'cit_div_by_field.csv'},
        {'metric': 'largest_subregion_gap', 'value': float(top_sub.get('oa_minus_noa_gap', float('nan'))), 'subregion': str(top_sub.get('subregion_cited', '')), 'year': int(subregion.get('latest_year') or 0), 'source_file': 'summary_stats_by_subregion_atleast2cit.csv'},
    ]


def plot_two_series(df: pd.DataFrame, x_col: str, y_a: str, y_b: str, output_path: str, labels: tuple[str, str] = ('A', 'B'), ylabel: str = 'value') -> dict:
    """Generic two-series line plot for caller-selected columns."""
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    ax.plot(df[x_col], df[y_a], marker='o', label=labels[0])
    ax.plot(df[x_col], df[y_b], marker='o', label=labels[1])
    ax.set_xlabel(x_col)
    ax.set_ylabel(ylabel)
    ax.legend()
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path, 'x_col': x_col, 'y_cols': [y_a, y_b]}


def plot_single_series(df: pd.DataFrame, x_col: str, y_col: str, output_path: str, xscale: str | None = None, ylabel: str = 'value') -> dict:
    """Generic single-series line plot; callers choose columns and file name."""
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    ax.plot(df[x_col], df[y_col], marker='o')
    ax.set_xlabel(x_col)
    ax.set_ylabel(ylabel)
    if xscale:
        ax.set_xscale(xscale)
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path, 'x_col': x_col, 'y_col': y_col}


def plot_ranked_bars(labels: list[str], values: list[float], output_path: str, xlabel: str = 'value') -> dict:
    """Generic ranked horizontal bar plot."""
    order = np.argsort(values)
    labels_arr = np.array(labels, dtype=object)[order]
    values_arr = np.array(values, dtype=float)[order]
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.barh(labels_arr, values_arr, color='#756bb1')
    ax.set_xlabel(xlabel)
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path, 'n': int(len(values_arr))}


def package_smoke_test(data_root: str) -> dict:
    """Validate data joins and summaries without writing final answer artifacts."""
    return {
        'oa_gap': oa_diversity_gap_summary(data_root),
        'citation_count': citation_count_diversity_summary(data_root),
        'field_gap': field_diversity_summary(data_root),
        'subregion_gap': subregion_diversity_summary(data_root),
        'checkpoint_candidates': checkpoint_rows_from_summaries(data_root),
    }
