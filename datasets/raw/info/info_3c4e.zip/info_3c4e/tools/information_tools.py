
from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _repo(data_root: str) -> Path:
    p = Path(data_root)
    if (p / 'Curtin-Open-Knowledge-Initiative-citation-diversity-ee3e8e0').exists():
        return p / 'Curtin-Open-Knowledge-Initiative-citation-diversity-ee3e8e0' / 'tempdata'
    if (p / 'tempdata').exists():
        return p / 'tempdata'
    return p


def oa_diversity_gap_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'summary_stats_by_year_atleast2cit.csv')
    df = df.copy()
    df['country_gap'] = df['oa_Countries_Shannon_mean'] - df['noa_Countries_Shannon_mean']
    df['institution_gap'] = df['oa_Institutions_Shannon_mean'] - df['noa_Institutions_Shannon_mean']
    df['subregion_gap'] = df['oa_Subregions_Shannon_mean'] - df['noa_Subregions_Shannon_mean']
    df['region_gap'] = df['oa_Regions_Shannon_mean'] - df['noa_Regions_Shannon_mean']
    df['field_gap'] = df['oa_Fields_Shannon_mean'] - df['noa_Fields_Shannon_mean']
    return {
        'yearly_gaps': df[['year', 'country_gap', 'institution_gap', 'subregion_gap', 'region_gap', 'field_gap']].to_dict('records'),
        'mean_country_gap': float(df['country_gap'].mean()),
        'mean_institution_gap': float(df['institution_gap'].mean()),
        'mean_subregion_gap': float(df['subregion_gap'].mean()),
        'mean_region_gap': float(df['region_gap'].mean()),
        'mean_field_gap': float(df['field_gap'].mean()),
        'latest_year': int(df['year'].max()),
        'latest_year_country_gap': float(df.loc[df['year'] == df['year'].max(), 'country_gap'].iloc[0]),
        'latest_year_institution_gap': float(df.loc[df['year'] == df['year'].max(), 'institution_gap'].iloc[0]),
        'latest_year_subregion_gap': float(df.loc[df['year'] == df['year'].max(), 'subregion_gap'].iloc[0]),
        'latest_year_region_gap': float(df.loc[df['year'] == df['year'].max(), 'region_gap'].iloc[0]),
        'latest_year_field_gap': float(df.loc[df['year'] == df['year'].max(), 'field_gap'].iloc[0]),
    }


def citation_count_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_vs_cit_count.csv')
    # Aggregate over years and summarize the monotone relationship for countries Shannon.
    g = df.groupby('CitationCount', as_index=False)['CitingCountries_Shannon_perc50'].median()
    low = float(g['CitingCountries_Shannon_perc50'].iloc[0])
    high = float(g['CitingCountries_Shannon_perc50'].iloc[-1])
    return {
        'rows': int(len(df)),
        'citation_count_min': int(df['CitationCount'].min()),
        'citation_count_max': int(df['CitationCount'].max()),
        'median_country_shannon_first': low,
        'median_country_shannon_last': high,
        'median_country_shannon_trajectory_sample': g.head(10).to_dict('records'),
    }


def field_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_by_field.csv')
    latest = df[df['year'] == df['year'].max()].copy()
    latest['country_gap'] = latest['oa_CitingCountries_Shannon_mean'] - latest['noa_CitingCountries_Shannon_mean']
    top = latest.sort_values('country_gap', ascending=False).head(8)
    return {
        'latest_year': int(latest['year'].max()),
        'top_country_gaps': top[['field', 'country_gap', 'oa_CitingCountries_Shannon_mean', 'noa_CitingCountries_Shannon_mean']].to_dict('records'),
    }


def subregion_diversity_summary(data_root: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'summary_stats_by_subregion_atleast2cit.csv')
    # Build Shannon diversity per (cited_subregion, year, OA-status) from citing-subregion counts.
    g = (
        df.groupby(['subregion_cited', 'year', 'is_oa', 'subregion_citing'], as_index=False)['subregion_citing_count']
        .sum()
    )
    rows = []
    for (subregion, year, is_oa), chunk in g.groupby(['subregion_cited', 'year', 'is_oa']):
        counts = chunk['subregion_citing_count'].to_numpy(dtype=float)
        total = counts.sum()
        if total <= 0:
            continue
        probs = counts / total
        shannon = float(-(probs * np.log(probs)).sum())
        rows.append({'subregion_cited': subregion, 'year': int(year), 'is_oa': bool(is_oa), 'shannon': shannon})

    sh = pd.DataFrame(rows)
    if sh.empty:
        return {'rows': 0, 'latest_year': None, 'top_subregions': []}

    latest_year = int(sh['year'].max())
    latest = sh[sh['year'] == latest_year]
    oa = latest[latest['is_oa']][['subregion_cited', 'shannon']].rename(columns={'shannon': 'oa_shannon'})
    noa = latest[~latest['is_oa']][['subregion_cited', 'shannon']].rename(columns={'shannon': 'noa_shannon'})
    merged = oa.merge(noa, on='subregion_cited', how='inner')
    merged['oa_minus_noa_gap'] = merged['oa_shannon'] - merged['noa_shannon']
    top = merged.sort_values('oa_minus_noa_gap', ascending=False).head(10)

    return {
        'rows': int(len(sh)),
        'latest_year': latest_year,
        'top_subregions': top[['subregion_cited', 'oa_shannon', 'noa_shannon', 'oa_minus_noa_gap']].to_dict('records'),
    }


def build_oa_diversity_checkpoints(
    data_root: str,
    output_csv: str = 'artifacts/checkpoints.csv',
    target_year: int = 2019,
) -> dict:
    temp = _repo(data_root)
    year_path = temp / 'summary_stats_by_year_atleast2cit.csv'
    count_path = temp / 'cit_div_vs_cit_count.csv'
    field_path = temp / 'cit_div_by_field.csv'
    subregion_path = temp / 'summary_stats_by_subregion_atleast2cit.csv'

    year_df = pd.read_csv(year_path)
    count_df = pd.read_csv(count_path)
    field_df = pd.read_csv(field_path)
    subregion_df = pd.read_csv(subregion_path)

    if target_year not in set(int(y) for y in year_df['year'].unique()):
        target_year = int(year_df['year'].max())
    year_row = year_df[year_df['year'] == target_year].iloc[0]

    count_med = count_df.groupby('CitationCount', as_index=False)['CitingCountries_Shannon_perc50'].median()
    first_count = int(count_med['CitationCount'].min())
    last_count = int(count_med['CitationCount'].max())
    first_med = float(count_med[count_med['CitationCount'] == first_count]['CitingCountries_Shannon_perc50'].iloc[0])
    last_med = float(count_med[count_med['CitationCount'] == last_count]['CitingCountries_Shannon_perc50'].iloc[0])

    latest_field_year = int(field_df['year'].max())
    latest_field = field_df[field_df['year'] == latest_field_year].copy()
    latest_field['country_gap'] = (
        latest_field['oa_CitingCountries_Shannon_mean'] - latest_field['noa_CitingCountries_Shannon_mean']
    )
    top_field_row = latest_field.sort_values('country_gap', ascending=False).iloc[0]
    top_field_name = str(top_field_row['field']).strip()

    grouped = (
        subregion_df.groupby(['subregion_cited', 'year', 'is_oa', 'subregion_citing'], as_index=False)['subregion_citing_count']
        .sum()
    )
    sh_rows = []
    for (subregion, year, is_oa), chunk in grouped.groupby(['subregion_cited', 'year', 'is_oa']):
        counts = chunk['subregion_citing_count'].to_numpy(dtype=float)
        total = counts.sum()
        if total <= 0:
            continue
        probs = counts / total
        shannon = float(-(probs * np.log(probs)).sum())
        sh_rows.append({'subregion_cited': str(subregion), 'year': int(year), 'is_oa': bool(is_oa), 'shannon': shannon})
    sh = pd.DataFrame(sh_rows)
    if sh.empty:
        raise ValueError('No subregion Shannon rows could be computed from summary_stats_by_subregion_atleast2cit.csv')

    latest_subregion_year = int(sh['year'].max())
    sh_latest = sh[sh['year'] == latest_subregion_year]
    oa_latest = sh_latest[sh_latest['is_oa']][['subregion_cited', 'shannon']].rename(columns={'shannon': 'oa_shannon'})
    noa_latest = sh_latest[~sh_latest['is_oa']][['subregion_cited', 'shannon']].rename(columns={'shannon': 'noa_shannon'})
    subregion_gap = oa_latest.merge(noa_latest, on='subregion_cited', how='inner')
    subregion_gap['oa_minus_noa_gap'] = subregion_gap['oa_shannon'] - subregion_gap['noa_shannon']
    if subregion_gap.empty:
        raise ValueError('No OA/non-OA paired subregion Shannon rows found in latest year')

    ea_mask = subregion_gap['subregion_cited'].astype(str).str.strip().str.lower() == 'eastern asia'
    if ea_mask.any():
        sub_row = subregion_gap[ea_mask].iloc[0]
    else:
        sub_row = subregion_gap.sort_values('oa_minus_noa_gap', ascending=False).iloc[0]
    sub_name = str(sub_row['subregion_cited']).strip()

    rows = [
        {
            'checkpoint': f'year_{target_year}_oa_country_shannon_mean',
            'value': float(year_row['oa_Countries_Shannon_mean']),
            'unit': 'Shannon',
            'source_path': f'input_data/data/summary_stats_by_year_atleast2cit.csv::year={target_year}',
        },
        {
            'checkpoint': f'year_{target_year}_non_oa_country_shannon_mean',
            'value': float(year_row['noa_Countries_Shannon_mean']),
            'unit': 'Shannon',
            'source_path': f'input_data/data/summary_stats_by_year_atleast2cit.csv::year={target_year}',
        },
        {
            'checkpoint': f'year_{target_year}_oa_subregion_shannon_mean',
            'value': float(year_row['oa_Subregions_Shannon_mean']),
            'unit': 'Shannon',
            'source_path': f'input_data/data/summary_stats_by_year_atleast2cit.csv::year={target_year}',
        },
        {
            'checkpoint': f'year_{target_year}_non_oa_subregion_shannon_mean',
            'value': float(year_row['noa_Subregions_Shannon_mean']),
            'unit': 'Shannon',
            'source_path': f'input_data/data/summary_stats_by_year_atleast2cit.csv::year={target_year}',
        },
        {
            'checkpoint': f'citation_count_{first_count}_country_shannon_perc50',
            'value': first_med,
            'unit': 'Shannon',
            'source_path': f'input_data/data/cit_div_vs_cit_count.csv::CitationCount={first_count}',
        },
        {
            'checkpoint': f'citation_count_{last_count}_country_shannon_perc50',
            'value': last_med,
            'unit': 'Shannon',
            'source_path': f'input_data/data/cit_div_vs_cit_count.csv::CitationCount={last_count}',
        },
        {
            'checkpoint': f'field_country_gap_latest_year_{latest_field_year}_{top_field_name.replace(" ", "_").lower()}',
            'value': float(top_field_row['country_gap']),
            'unit': 'Shannon gap',
            'source_path': f'input_data/data/cit_div_by_field.csv::year={latest_field_year},field={top_field_name}',
        },
        {
            'checkpoint': f'subregion_oa_minus_non_oa_shannon_{latest_subregion_year}_{sub_name.replace(" ", "_").lower()}',
            'value': float(sub_row['oa_minus_noa_gap']),
            'unit': 'Shannon gap',
            'source_path': (
                'input_data/data/summary_stats_by_subregion_atleast2cit.csv'
                f'::subregion_cited={sub_name},year={latest_subregion_year},computed_from=subregion_citing_count'
            ),
        },
    ]

    out = Path(output_csv)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / out
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    return {'path': str(out), 'rows': rows}


def plot_oa_noa_diversity(data_root: str, output_path: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'summary_stats_by_year_atleast2cit.csv')
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    ax.plot(df['year'], df['oa_Countries_Shannon_mean'], marker='o', label='OA', color='#2b8cbe')
    ax.plot(df['year'], df['noa_Countries_Shannon_mean'], marker='o', label='Non-OA', color='#de2d26')
    ax.set_xlabel('Year')
    ax.set_ylabel('Mean citing-country Shannon diversity')
    ax.legend()
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path}


def plot_citation_count_diversity(data_root: str, output_path: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_vs_cit_count.csv')
    sample = df.groupby('CitationCount', as_index=False)['CitingCountries_Shannon_perc50'].median()
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    ax.plot(sample['CitationCount'], sample['CitingCountries_Shannon_perc50'], color='#31a354')
    ax.set_xlabel('Citation count')
    ax.set_ylabel('Median citing-country Shannon diversity')
    ax.set_xscale('log')
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path}


def plot_field_gaps(data_root: str, output_path: str) -> dict:
    temp = _repo(data_root)
    df = pd.read_csv(temp / 'cit_div_by_field.csv')
    latest = df[df['year'] == df['year'].max()].copy()
    latest['gap'] = latest['oa_CitingCountries_Shannon_mean'] - latest['noa_CitingCountries_Shannon_mean']
    d = latest.sort_values('gap', ascending=False).head(10)
    plt.figure(figsize=(10, 5))
    plt.barh(d['field'][::-1], d['gap'][::-1], color='#756bb1')
    plt.xlabel('OA minus non-OA citing-country Shannon')
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {'path': output_path}


def package_smoke_test(data_root: str, artifact_dir: str | None = None) -> dict:
    """Lightweight package validation without producing final scoring artifacts by default."""
    a = oa_diversity_gap_summary(data_root)
    b = citation_count_diversity_summary(data_root)
    c = field_diversity_summary(data_root)
    s = subregion_diversity_summary(data_root)
    out = {'oa_gap': a, 'citation_count': b, 'field_gap': c, 'subregion_gap': s, 'plots': []}
    if artifact_dir:
        root = Path(artifact_dir)
        p1 = plot_oa_noa_diversity(data_root, str(root / 'smoke_oa_noa_diversity.png'))
        p2 = plot_citation_count_diversity(data_root, str(root / 'smoke_citation_count_diversity.png'))
        p3 = plot_field_gaps(data_root, str(root / 'smoke_field_diversity_gaps.png'))
        out['plots'] = [p1['path'], p2['path'], p3['path']]
    return out
