from __future__ import annotations

from pathlib import Path
import pandas as pd


def read_csv(path: str, **kwargs) -> pd.DataFrame:
    return pd.read_csv(path, **kwargs)


def read_table(path: str, **kwargs) -> pd.DataFrame:
    return pd.read_csv(path, sep=None, engine="python", **kwargs)


def read_any_csvs(root: str) -> dict[str, pd.DataFrame]:
    root_path = Path(root)
    out = {}
    for path in sorted(root_path.rglob("*.csv")):
        try:
            out[str(path.relative_to(root_path))] = pd.read_csv(path)
        except Exception:
            continue
    return out


def numeric_columns(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]


def save_plot(path: str):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    return path
