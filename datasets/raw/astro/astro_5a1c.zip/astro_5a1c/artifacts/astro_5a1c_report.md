# WASP-39 b CO2 Reproduction Report

The released JWST transmission spectrum and model grids reproduce the paper's CO2-centered atmospheric claim for WASP-39 b. The EUREKA reduction has 94 wavelength bins and the 4.3 micron band is explicitly covered.

- EUREKA 4.3 micron band minus local continuum: 925.2 ppm.
- Full ScCHIMERA minus no-CO2 model contrast in the 4.3 micron band: 829.1 ppm mean, 1247.3 ppm max absolute difference.
- Independent reduction agreement median spread: 118.7 ppm.

These checks support the paper-native conclusion that the 4.3 micron feature is a CO2 feature in a metal-enriched WASP-39 b atmosphere [PAPER, Abstract; PAPER, Fig. 2; PAPER, Fig. 3].
