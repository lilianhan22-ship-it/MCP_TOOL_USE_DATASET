from __future__ import annotations
from pathlib import Path
import io
import zipfile
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = PACKAGE_ROOT / "input_data" / "data"
ARTIFACT_DIR = PACKAGE_ROOT / "artifacts"
ARCHIVE = DATA_ROOT / "41586_2022_5269_MOESM1_ESM.zip"
LIGHTCURVE = DATA_ROOT / "41586_2022_5269_MOESM2_ESM.csv"


def _read_ecsv_text(text: str) -> pd.DataFrame:
    lines = [ln for ln in text.splitlines() if ln.strip()]
    data_start = next(i for i, ln in enumerate(lines) if not ln.startswith('#'))
    return pd.read_csv(io.StringIO('\n'.join(lines[data_start:])), sep=r'\s+', engine='python')


def _read_archive_text(member: str, archive: str | Path = ARCHIVE) -> str:
    with zipfile.ZipFile(archive) as zf:
        with zf.open(member) as handle:
            return handle.read().decode('utf-8', errors='replace')


def archive_members(archive: str | Path = ARCHIVE) -> list[str]:
    with zipfile.ZipFile(archive) as zf:
        return zf.namelist()


def load_transmission_spectrum(reduction: str = 'EUREKA', archive: str | Path = ARCHIVE) -> pd.DataFrame:
    """Load one released transmission-spectrum reduction and normalize column names."""
    reduction = reduction.upper()
    member = f'ZENODO/TRANSMISSION_SPECTRA_DATA/{reduction}_REDUCTION.txt'
    df = _read_ecsv_text(_read_archive_text(member, archive))
    if reduction == 'TIBERIUS' and 'wavelength' not in df.columns:
        df = df.copy()
        df.columns = ['wavelength', 'tr_depth', 'tr_depth_err', 'flag'][:len(df.columns)]
    rename = {
        'wv_center': 'wavelength', 'wave': 'wavelength',
        'transit_depth': 'tr_depth', 'depth': 'tr_depth',
        'tran_unc': 'tr_depth_err', 'err': 'tr_depth_err',
    }
    df = df.rename(columns=rename)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    if 'tr_depth' not in df or 'wavelength' not in df:
        raise ValueError(f'{reduction} reduction lacks wavelength/tr_depth columns: {list(df.columns)}')
    return df.dropna(subset=['wavelength', 'tr_depth']).reset_index(drop=True)


def load_model_spectrum(model_name: str = 'ScCHIMERA_MODEL', archive: str | Path = ARCHIVE) -> pd.DataFrame:
    """Load a released model spectrum from MODEL_FITS."""
    member = f'ZENODO/MODEL_FITS/{model_name}.txt'
    text = _read_archive_text(member, archive)
    rows = []
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        parts = line.split()
        if len(parts) >= 2:
            rows.append((float(parts[0]), float(parts[1])))
    return pd.DataFrame(rows, columns=['wavelength', 'depth'])


def load_lightcurve_table(path: str | Path = LIGHTCURVE) -> pd.DataFrame:
    """Read the whitespace ECSV light-curve product with wavelength, flux and residual columns."""
    return _read_ecsv_text(Path(path).read_text(errors='replace'))


def band_depth_summary(spectrum: pd.DataFrame, center: float = 4.3, half_width: float = 0.12, continuum_width: float = 0.45) -> dict:
    """Compare mean transit depth in a molecular band with neighboring continuum."""
    wave = spectrum['wavelength'].to_numpy(float)
    depth = spectrum['tr_depth'].to_numpy(float)
    band = (wave >= center-half_width) & (wave <= center+half_width)
    cont = ((wave >= center-continuum_width) & (wave < center-half_width)) | ((wave > center+half_width) & (wave <= center+continuum_width))
    return {
        'center_micron': center,
        'band_mean_depth': float(np.nanmean(depth[band])),
        'continuum_mean_depth': float(np.nanmean(depth[cont])),
        'band_minus_continuum_ppm': float((np.nanmean(depth[band]) - np.nanmean(depth[cont])) * 1e6),
        'n_band': int(np.sum(band)),
        'n_continuum': int(np.sum(cont)),
    }


def model_band_contrast(full_model: pd.DataFrame, comparison_model: pd.DataFrame, center: float = 4.3, half_width: float = 0.16) -> dict:
    """Interpolate two model spectra and summarize their difference inside a band."""
    wave = full_model['wavelength'].to_numpy(float)
    full = full_model['depth'].to_numpy(float)
    comp = np.interp(wave, comparison_model['wavelength'], comparison_model['depth'])
    band = (wave >= center-half_width) & (wave <= center+half_width)
    diff = full - comp
    return {'center_micron': center, 'mean_full_minus_comparison_ppm': float(np.nanmean(diff[band]) * 1e6), 'max_abs_difference_ppm': float(np.nanmax(np.abs(diff[band])) * 1e6), 'n_band': int(np.sum(band))}


def reduction_agreement(reductions: list[str] | None = None) -> dict:
    """Compare released independent reductions on common wavelength support."""
    reductions = reductions or ['EUREKA', 'FIREFLY', 'TIBERIUS', 'TSHIRT']
    tables = {r: load_transmission_spectrum(r) for r in reductions}
    base = tables[reductions[0]][['wavelength', 'tr_depth']].rename(columns={'tr_depth': reductions[0]})
    for r in reductions[1:]:
        vals = np.interp(base['wavelength'], tables[r]['wavelength'], tables[r]['tr_depth'])
        base[r] = vals
    spread = base[reductions].std(axis=1)
    return {'reductions': reductions, 'n_wavelengths': int(len(base)), 'median_reduction_spread_ppm': float(spread.median() * 1e6), 'max_reduction_spread_ppm': float(spread.max() * 1e6)}


def plot_spectrum_with_models(spectrum: pd.DataFrame, full_model: pd.DataFrame, no_co2_model: pd.DataFrame, output_path: str) -> dict:
    fig, ax = plt.subplots(figsize=(8, 4.8))
    yerr = None
    if {'tr_depth_errneg', 'tr_depth_errpos'} <= set(spectrum.columns):
        yerr = [spectrum['tr_depth_errneg'], spectrum['tr_depth_errpos']]
    ax.errorbar(spectrum['wavelength'], spectrum['tr_depth']*100, yerr=None if yerr is None else np.array(yerr)*100, fmt='o', ms=3, alpha=0.7, label='released spectrum')
    ax.plot(full_model['wavelength'], full_model['depth']*100, label='full ScCHIMERA model')
    ax.plot(no_co2_model['wavelength'], no_co2_model['depth']*100, label='no CO2 model', ls='--')
    ax.axvspan(4.18, 4.42, color='orange', alpha=0.18, label='4.3 um CO2 band')
    ax.set_xlabel('Wavelength (micron)'); ax.set_ylabel('Transit depth (%)'); ax.legend(fontsize=8)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True); fig.tight_layout(); fig.savefig(output_path, dpi=200); plt.close(fig)
    return {'path': output_path}


def plot_model_residuals(full_model: pd.DataFrame, models: dict[str, pd.DataFrame], output_path: str) -> dict:
    fig, ax = plt.subplots(figsize=(8, 4.8))
    for name, model in models.items():
        comp = np.interp(full_model['wavelength'], model['wavelength'], model['depth'])
        ax.plot(full_model['wavelength'], (full_model['depth'] - comp) * 1e6, label=f'full - {name}')
    ax.axvspan(4.18, 4.42, color='orange', alpha=0.18)
    ax.set_xlabel('Wavelength (micron)'); ax.set_ylabel('Model contrast (ppm)'); ax.legend(fontsize=8)
    fig.tight_layout(); Path(output_path).parent.mkdir(parents=True, exist_ok=True); fig.savefig(output_path, dpi=200); plt.close(fig)
    return {'path': output_path}


def plot_lightcurve_residuals(lightcurve: pd.DataFrame, output_path: str) -> dict:
    fig, ax = plt.subplots(figsize=(7, 4.5))
    sample = lightcurve.sort_values(['wavelength', 'time']).groupby('wavelength').head(999)
    sc = ax.scatter(sample['time'], sample['residuals']*1e6, c=sample['wavelength'], s=4, cmap='viridis', alpha=0.5)
    ax.set_xlabel('Time from mid-transit (d)'); ax.set_ylabel('Residuals (ppm)')
    fig.colorbar(sc, ax=ax, label='Wavelength (micron)')
    fig.tight_layout(); Path(output_path).parent.mkdir(parents=True, exist_ok=True); fig.savefig(output_path, dpi=200); plt.close(fig)
    return {'path': output_path}


def package_smoke_test() -> dict:
    spec = load_transmission_spectrum('EUREKA')
    full = load_model_spectrum('ScCHIMERA_MODEL')
    no_co2 = load_model_spectrum('ScCHIMERA_MODEL_noCO2')
    lc = load_lightcurve_table()
    return {'members': len(archive_members()), 'spectrum_rows': len(spec), 'co2_band': band_depth_summary(spec), 'model_contrast': model_band_contrast(full, no_co2), 'reduction_agreement': reduction_agreement(), 'lightcurve_rows': len(lc)}
