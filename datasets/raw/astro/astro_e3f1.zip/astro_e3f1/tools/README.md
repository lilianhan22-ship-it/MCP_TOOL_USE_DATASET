This tools folder is organized into three layers.

- `astro_tools.py`: domain primitives for TOI-1853 b mass-radius-density context, multi-band transit consistency, density-period outlier checks, and artifact generation.
- `data_processing.py`: generic CSV reading and dataframe/file sanity helpers.
- `database_retrieval.py`: local data/reference inventory and lightweight PDF text lookup helpers.

Use the domain tool to compose the released transit and comparison-table reproduction workflow.
