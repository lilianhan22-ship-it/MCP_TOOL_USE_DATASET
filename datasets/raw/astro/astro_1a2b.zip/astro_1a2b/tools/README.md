This tools folder is organized into three layers.

- `astro_tools.py`
  Domain-specific astronomy workflow primitives for the astro_1a2b package.
- `data_processing.py`
  Generic table-reading, reshaping, inventory, and archive helpers.
- `database_retrieval.py`
  Lightweight local-reference and PDF-text inspection helpers.

Use the domain tool for the paper-specific inference workflow. Use the helper modules for data loading and reference inspection.

Column-order notes for released tables used by this task:
- `input_data/data/dynamical_simulation/Multinest_sampling.dat`:
  `DYN_POSTERIOR_COLS` in `astro_tools.py` defines the released order.
- `input_data/data/dynamical_simulation/simulation_result_20241120/combined_result.dat`:
  `tstable_yr, m_b_msun, m_c_msun, ab_au, ac_au, eb, ec`.
- `input_data/data/dynamical_simulation/simulation_result_20241120/*orbit*.dat`:
  `m_b_msun, m_c_msun, ab_au, ac_au, eb, ec, tstable_yr`.

Dependencies:
- `pypdf` is required only for optional `database_retrieval.extract_pdf_text` /
  `find_pdf_lines` helpers that inspect `target.pdf`.


## Units and checkpoint boundaries

- `SourceData_ED_Fig4.csv`: `Period` is days and `M_b` is Jupiter masses.
- `Multinest_sampling.dat`: `m_c_msun` is solar masses; convert with physical constants before plotting in Earth/Jupiter mass units.
- Any posterior `e_c_proxy` diagnostic is not the same quantity as the
  stability-table eccentricity column `ec`.
