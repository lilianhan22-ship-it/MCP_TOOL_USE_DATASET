from __future__ import annotations

from pathlib import Path
from typing import Iterable

import pandas as pd


def read_csv(path: str | Path, **kwargs) -> pd.DataFrame:
    return pd.read_csv(path, **kwargs)


def dataframe_overview(df: pd.DataFrame, preview_rows: int = 5) -> dict:
    return {
        "shape": [int(df.shape[0]), int(df.shape[1])],
        "columns": list(df.columns),
        "preview": df.head(preview_rows).to_dict("records"),
    }


def list_files(root: str, suffixes: Iterable[str] | None = None) -> list[str]:
    path = Path(root)
    items: list[str] = []
    for child in sorted(path.rglob("*")):
        if not child.is_file():
            continue
        if suffixes and child.suffix.lower() not in suffixes:
            continue
        items.append(str(child))
    return items
