from __future__ import annotations

from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "input_data" / "data"
ARTIFACT_DIR = ROOT / "artifacts"
SPECTRA_DIR = DATA / "zenodo_subset" / "4_TRANSMISSION_SPECTRA" / "Fixed_LimbDarkening"
MODEL_PATH = DATA / "zenodo_subset" / "5_MODEL_SPECTRUM" / "BestFitModel.txt"


def released_spectrum_files() -> list[dict]:
    rows = []
    for path in sorted(SPECTRA_DIR.rglob("*.csv")):
        if path.name.startswith("._"):
            continue
        rows.append({"instrument": path.parent.name, "file": str(path.relative_to(DATA)), "bytes": path.stat().st_size})
    return rows


def load_transmission_spectrum(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    if "wave" not in df or "rp/rs" not in df:
        raise ValueError(f"{path} is missing wave and rp/rs columns")
    out = df.copy()
    out["wave"] = pd.to_numeric(out["wave"], errors="coerce")
    out["transit_depth"] = pd.to_numeric(out["rp/rs"], errors="coerce") ** 2
    err_cols = [c for c in ["rp/rs_err_low", "rp/rs_err_hih"] if c in out]
    if err_cols:
        err = out[err_cols].apply(pd.to_numeric, errors="coerce").mean(axis=1)
        out["transit_depth_err"] = 2 * pd.to_numeric(out["rp/rs"], errors="coerce") * err
    else:
        out["transit_depth_err"] = np.nan
    if "satflag" in out:
        out["satflag"] = pd.to_numeric(out["satflag"], errors="coerce").fillna(0).astype(int)
    else:
        out["satflag"] = 0
    return out.dropna(subset=["wave", "transit_depth"]).reset_index(drop=True)


def combined_transmission_spectrum() -> pd.DataFrame:
    frames = []
    for row in released_spectrum_files():
        path = DATA / row["file"]
        df = load_transmission_spectrum(path)
        df["instrument"] = row["instrument"]
        frames.append(df[["instrument", "wave", "transit_depth", "transit_depth_err", "satflag"]])
    if not frames:
        raise FileNotFoundError("No released transmission spectra found in zenodo_subset")
    return pd.concat(frames, ignore_index=True).sort_values(["wave", "instrument"]).reset_index(drop=True)


def load_best_fit_model(path: str | Path = MODEL_PATH) -> pd.DataFrame:
    df = pd.read_csv(path, comment="#", sep=r"\s+", names=["wave", "transit_depth"])
    return df.dropna().sort_values("wave").reset_index(drop=True)


def spectrum_checkpoint_summary() -> dict:
    spec = combined_transmission_spectrum()
    model = load_best_fit_model()
    interp = np.interp(spec["wave"], model["wave"], model["transit_depth"])
    residual = spec["transit_depth"].to_numpy() - interp
    by_inst = spec.groupby("instrument").agg(
        points=("wave", "size"), wave_min=("wave", "min"), wave_max=("wave", "max"), median_depth=("transit_depth", "median"), saturated_bins=("satflag", "sum")
    ).reset_index()
    return {
        "n_points": int(len(spec)),
        "wavelength_min_micron": float(spec["wave"].min()),
        "wavelength_max_micron": float(spec["wave"].max()),
        "model_points": int(len(model)),
        "residual_rms_depth": float(np.sqrt(np.nanmean(residual ** 2))),
        "instruments": by_inst.to_dict(orient="records"),
    }


def plot_transmission_spectrum(output_path: str | Path) -> dict:
    spec = combined_transmission_spectrum()
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(9, 4.8))
    for inst, sub in spec.groupby("instrument"):
        yerr = sub["transit_depth_err"].replace(0, np.nan)
        ax.errorbar(sub["wave"], sub["transit_depth"] * 100, yerr=yerr * 100, fmt=".", ms=4, alpha=0.8, label=inst)
    ax.set_xlabel("Wavelength (micron)")
    ax.set_ylabel("Transit depth (%)")
    ax.set_title("WASP-39 b released JWST transmission spectrum")
    ax.legend(frameon=False, fontsize=7, ncol=2)
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), **spectrum_checkpoint_summary()}


def plot_model_comparison(output_path: str | Path) -> dict:
    spec = combined_transmission_spectrum()
    model = load_best_fit_model()
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, (ax, rx) = plt.subplots(2, 1, figsize=(9, 6), sharex=True, height_ratios=[2.2, 1])
    ax.plot(model["wave"], model["transit_depth"] * 100, color="black", lw=1.4, label="1D-RCPE model")
    for inst, sub in spec.groupby("instrument"):
        pred = np.interp(sub["wave"], model["wave"], model["transit_depth"])
        ax.scatter(sub["wave"], sub["transit_depth"] * 100, s=10, label=inst, alpha=0.75)
        rx.scatter(sub["wave"], (sub["transit_depth"] - pred) * 1e6, s=10, alpha=0.75)
    ax.set_ylabel("Transit depth (%)")
    ax.set_title("WASP-39 b spectrum against best-fit model")
    ax.legend(frameon=False, fontsize=7, ncol=3)
    rx.axhline(0, color="black", lw=0.8)
    rx.set_ylabel("Residual (ppm)")
    rx.set_xlabel("Wavelength (micron)")
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), **spectrum_checkpoint_summary()}


def plot_instrument_offsets(output_path: str | Path) -> dict:
    spec = combined_transmission_spectrum()
    rows = []
    for inst, sub in spec.groupby("instrument"):
        rows.append({"instrument": inst, "median_depth_percent": float(sub["transit_depth"].median() * 100), "wave_min": float(sub["wave"].min()), "wave_max": float(sub["wave"].max()), "saturated_bins": int(sub["satflag"].sum())})
    df = pd.DataFrame(rows).sort_values("wave_min")
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 4.4))
    ax.bar(df["instrument"], df["median_depth_percent"], color="#4c78a8")
    ax.set_ylabel("Median transit depth (%)")
    ax.set_title("Mode-level depth offsets and PRISM saturation flag support")
    ax.tick_params(axis="x", rotation=25)
    for i, row in df.reset_index(drop=True).iterrows():
        if row["saturated_bins"]:
            ax.text(i, row["median_depth_percent"], f"sat={int(row['saturated_bins'])}", ha="center", va="bottom", fontsize=7)
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), "modes": rows}


def package_smoke_test() -> dict:
    return {"files": released_spectrum_files(), "summary": spectrum_checkpoint_summary()}
