from __future__ import annotations

import math
from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
import re

HYDROGEN_BURNING_LIMIT_MSUN = 0.075


TABLE2_COLS = [
    (0, 16, "Name"),
    (17, 18, "n_Name"),
    (19, 27, "Plx"),
    (28, 34, "e_Plx"),
    (35, 44, "pmRA"),
    (45, 50, "e_pmRA"),
    (51, 60, "pmDE"),
    (61, 66, "e_pmDE"),
    (67, 72, "epsi"),
    (73, 81, "sepsi"),
    (82, 89, "Gmag"),
    (90, 96, "e_Gmag"),
    (97, 103, "AG"),
    (105, 111, "e_AG"),
    (113, 119, "E_AG"),
    (120, 121, "Note1"),
    (122, 137, "RAdeg"),
    (138, 153, "DEdeg"),
]

TABLE3_COLS = [
    (0, 16, "Name"),
    (16, 17, "companion_host_flag"),
    (17, 26, "rho"),
    (27, 34, "e_rho"),
    (35, 44, "PA"),
    (45, 52, "e_PA"),
    (53, 57, "Dplx"),
    (58, 62, "e_Dplx"),
    (63, 67, "sDplx"),
    (72, 77, "mu_rel"),
    (78, 82, "e_mu_rel"),
    (83, 89, "smu_rel"),
    (90, 96, "CPM"),
]

TABLE4_COLS = [
    (0, 16, "Name"),
    (16, 17, "companion_host_flag"),
    (17, 32, "RAdeg"),
    (33, 48, "DEdeg"),
    (49, 55, "GMAG"),
    (56, 61, "Sep"),
    (62, 63, "l_Mass"),
    (64, 75, "Mass"),
    (76, 85, "Teff"),
    (86, 88, "Note"),
]


def _read_fixed_width(path: str, spec: list[tuple[int, int, str]]) -> pd.DataFrame:
    rows = []
    for line in Path(path).read_text(encoding="utf-8", errors="ignore").splitlines():
        rows.append({name: line[start:end].strip() for start, end, name in spec})
    return pd.DataFrame(rows)


def _coerce_numeric(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    out = df.copy()
    for col in cols:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    return out


def _load_table2(path: str) -> pd.DataFrame:
    df = _read_fixed_width(path, TABLE2_COLS)
    df["is_host"] = df["n_Name"].eq("*")
    return _coerce_numeric(df, ["Plx", "e_Plx", "pmRA", "e_pmRA", "pmDE", "e_pmDE", "RAdeg", "DEdeg"])


def _load_table3(path: str) -> pd.DataFrame:
    df = _read_fixed_width(path, TABLE3_COLS)
    df["is_dual_host_companion"] = df["companion_host_flag"].eq("*")
    return _coerce_numeric(df, ["rho", "Dplx", "e_Dplx", "sDplx", "mu_rel", "e_mu_rel", "smu_rel", "CPM"])


def _load_table4(path: str) -> pd.DataFrame:
    df = _companion_table(path)
    df["is_dual_host_companion"] = df["companion_host_flag"].eq("*")
    return _coerce_numeric(df, ["RAdeg", "DEdeg", "GMAG", "Sep"])


def _parse_mass_components(value: str) -> list[float]:
    return [float(x) for x in re.findall(r"\d+(?:\.\d+)?", str(value))]


def _companion_table(table4_path: str, explode_components: bool = False) -> pd.DataFrame:
    df = _read_fixed_width(table4_path, TABLE4_COLS)
    df["Sep"] = pd.to_numeric(df["Sep"], errors="coerce")
    df["mass_components"] = df["Mass"].map(_parse_mass_components)
    df["Mass_num"] = df["mass_components"].map(lambda xs: sum(xs) if xs else pd.NA)
    df["component_count"] = df["mass_components"].map(len)
    if not explode_components:
        return df
    rows = []
    for _, row in df.iterrows():
        masses = row["mass_components"] or [pd.NA]
        for idx, mass in enumerate(masses, start=1):
            item = row.copy()
            item["component_index"] = idx
            item["Mass_num"] = mass
            rows.append(item)
    return pd.DataFrame(rows)


def load_hosts_and_companions(table2_path: str) -> dict:
    df = _load_table2(table2_path)
    return {
        "rows": int(len(df)),
        "host_flag_rows": int(df["is_host"].sum()),
        "unflagged_table2_companion_rows": int((~df["is_host"]).sum()),
        "sample_names": df["Name"].head(10).tolist(),
    }


def astrometric_support_summary(table3_path: str) -> dict:
    df = _load_table3(table3_path)
    return {
        "pairs": int(len(df)),
        "dual_host_companion_rows": int(df["is_dual_host_companion"].sum()),
        "median_cpm": float(df["CPM"].median()),
        "cpm_gt_10": int((df["CPM"] > 10).sum()),
        "cpm_ge_3_common_motion": int((df["CPM"] >= 3).sum()),
        "parallax_consistent_sDplx_lt_3": int((df["sDplx"] < 3).sum()),
        "median_rho_arcsec": float(df["rho"].median()),
        "max_rho_arcsec": float(df["rho"].max()),
    }


def companion_population_summary(table4_path: str) -> dict:
    df = _companion_table(table4_path)
    components = _companion_table(table4_path, explode_components=True)

    def classify(row: pd.Series) -> str:
        if row["Note"] == "WD":
            return "white dwarf"
        if pd.notna(row["Mass_num"]) and row["Mass_num"] < HYDROGEN_BURNING_LIMIT_MSUN:
            return "brown dwarf"
        return "stellar"

    df["class"] = df.apply(classify, axis=1)
    components["class"] = components.apply(classify, axis=1)
    class_counts = {k: int(v) for k, v in df["class"].value_counts().to_dict().items()}
    component_class_counts = {k: int(v) for k, v in components["class"].value_counts().to_dict().items()}
    paper_type_counts = {
        "main_sequence_stellar": int(class_counts.get("stellar", 0)),
        "white_dwarf": int(class_counts.get("white dwarf", 0)),
        "brown_dwarf": int(class_counts.get("brown dwarf", 0)),
    }
    return {
        "companion_systems": int(len(df)),
        "companion_mass_points": int(components["Mass_num"].notna().sum()),
        "multi_component_systems": int((df["component_count"] > 1).sum()),
        "class_counts": class_counts,
        "paper_type_counts": paper_type_counts,
        "component_class_counts": component_class_counts,
        "median_projected_separation_au": float(df["Sep"].median()),
        "max_projected_separation_au": float(df["Sep"].max()),
        "median_system_mass_msun": float(pd.to_numeric(df["Mass_num"], errors="coerce").dropna().median()),
        "median_component_mass_msun": float(pd.to_numeric(components["Mass_num"], errors="coerce").dropna().median()),
    }


def cross_table_companion_consistency(table2_path: str, table3_path: str, table4_path: str) -> dict:
    """Check the CDS Tables 2-4 companion accounting used by the paper."""
    t2 = _load_table2(table2_path)
    t3 = _load_table3(table3_path)
    t4 = _load_table4(table4_path)
    unflagged_t2_names = set(t2.loc[~t2["is_host"], "Name"])
    t3_names = set(t3["Name"])
    t4_names = set(t4["Name"])
    dual_host_names = sorted(set(t3.loc[t3["is_dual_host_companion"], "Name"]) | set(t4.loc[t4["is_dual_host_companion"], "Name"]))
    return {
        "table2_rows": int(len(t2)),
        "table2_host_flag_rows": int(t2["is_host"].sum()),
        "table2_unflagged_companion_rows": int((~t2["is_host"]).sum()),
        "table3_companion_pairs": int(len(t3)),
        "table4_companion_property_rows": int(len(t4)),
        "table3_table4_name_agreement": bool(t3_names == t4_names),
        "dual_host_companion_rows": int(len(dual_host_names)),
        "dual_host_companion_names": dual_host_names,
        "table3_names_not_unflagged_table2_companions": sorted(t3_names - unflagged_t2_names),
    }


def _small_angle_rho_pa(ra_host: float, dec_host: float, ra_companion: float, dec_companion: float) -> tuple[float, float]:
    dra = (ra_companion - ra_host) * math.cos(math.radians((dec_host + dec_companion) / 2.0)) * 3600.0
    ddec = (dec_companion - dec_host) * 3600.0
    rho = math.hypot(dra, ddec)
    pa = (math.degrees(math.atan2(dra, ddec)) + 360.0) % 360.0
    return rho, pa


def coordinate_consistency_summary(table2_path: str, table3_path: str, table4_path: str, tolerance_arcsec: float = 1e-3) -> dict:
    """Validate that the released coordinate columns support the Table 3 astrometry."""
    t2 = _load_table2(table2_path)
    t3 = _load_table3(table3_path)
    t4 = _load_table4(table4_path)
    merged = t4.merge(t2[["Name", "RAdeg", "DEdeg"]], on="Name", suffixes=("_table4", "_table2"))
    merged["coord_delta_arcsec"] = (
        ((merged["RAdeg_table4"] - merged["RAdeg_table2"]) * 3600.0) ** 2
        + ((merged["DEdeg_table4"] - merged["DEdeg_table2"]) * 3600.0) ** 2
    ) ** 0.5
    mismatches = merged.loc[merged["coord_delta_arcsec"] > tolerance_arcsec, ["Name", "coord_delta_arcsec"]]
    rho_pa = recompute_separation_position_angle(table2_path, table3_path)
    return {
        "same_name_table2_table4_matches": int(len(merged)),
        "same_name_coordinate_mismatches": int(len(mismatches)),
        "max_same_name_coordinate_delta_arcsec": float(merged["coord_delta_arcsec"].max()) if len(merged) else None,
        "table3_table4_name_agreement": bool(set(t3["Name"]) == set(t4["Name"])),
        "rho_pa_recompute": rho_pa,
        "mismatch_examples": mismatches.head(10).to_dict(orient="records"),
    }


def recompute_separation_position_angle(table2_path: str, table3_path: str, tolerance_arcsec: float = 0.01, tolerance_deg: float = 0.01) -> dict:
    """Recompute Table 3 angular separations and position angles from Table 2 coordinates."""
    t2 = _load_table2(table2_path)
    t3 = _load_table3(table3_path)
    table4_path = Path(table3_path).with_name("table4.dat")
    t4 = _load_table4(str(table4_path)).set_index("Name", drop=False) if table4_path.exists() else pd.DataFrame()
    rows = []
    skipped = []
    for _, rel in t3.iterrows():
        comp_matches = t2.index[t2["Name"].eq(rel["Name"])].tolist()
        if comp_matches:
            comp_idx = int(comp_matches[0])
        elif len(t4) and rel["Name"] in t4.index:
            comp_idx = _find_table2_index_by_name_or_position(t2, t4.loc[rel["Name"]], rel["Name"])
        else:
            comp_idx = None
        if comp_idx is None:
            skipped.append(rel["Name"])
            continue
        host_idx = _infer_host_index_for_companion(t2, comp_idx)
        if host_idx is None:
            skipped.append(rel["Name"])
            continue
        host = t2.loc[host_idx]
        comp = t2.loc[comp_idx]
        rho, pa = _small_angle_rho_pa(float(host["RAdeg"]), float(host["DEdeg"]), float(comp["RAdeg"]), float(comp["DEdeg"]))
        pa_error = abs(((pa - float(rel["PA"]) + 180.0) % 360.0) - 180.0)
        if bool(rel.get("is_dual_host_companion", False)):
            pa_error = min(pa_error, abs(pa_error - 180.0))
        rows.append(
            {
                "companion": rel["Name"],
                "host": host["Name"],
                "rho_arcsec": rho,
                "table3_rho_arcsec": float(rel["rho"]),
                "rho_abs_error_arcsec": abs(rho - float(rel["rho"])),
                "pa_deg": pa,
                "table3_pa_deg": float(rel["PA"]),
                "pa_abs_error_deg": pa_error,
            }
        )
    out = pd.DataFrame(rows)
    if len(out):
        failing = out[(out["rho_abs_error_arcsec"] > tolerance_arcsec) | (out["pa_abs_error_deg"] > tolerance_deg)]
    else:
        failing = out
    return {
        "checked_pairs": int(len(out)),
        "skipped_pairs": skipped,
        "within_tolerance_pairs": int(len(out) - len(failing)),
        "max_rho_abs_error_arcsec": float(out["rho_abs_error_arcsec"].max()) if len(out) else None,
        "max_pa_abs_error_deg": float(out["pa_abs_error_deg"].max()) if len(out) else None,
        "failing_examples": failing.head(10).round(6).to_dict(orient="records"),
    }


def _angular_distance_arcsec(ra1: float, dec1: float, ra2: float, dec2: float) -> float:
    dec_mid = math.radians((dec1 + dec2) / 2.0)
    dra = (ra1 - ra2) * math.cos(dec_mid)
    ddec = dec1 - dec2
    return math.hypot(dra, ddec) * 3600.0


def _find_table2_index_by_name_or_position(t2: pd.DataFrame, table4_row: pd.Series | None, name: str) -> int | None:
    matches = t2.index[t2["Name"].eq(name)].tolist()
    if matches:
        return int(matches[0])
    if table4_row is None or pd.isna(table4_row.get("RAdeg")) or pd.isna(table4_row.get("DEdeg")):
        return None
    distances = t2.apply(
        lambda row: _angular_distance_arcsec(float(row["RAdeg"]), float(row["DEdeg"]), float(table4_row["RAdeg"]), float(table4_row["DEdeg"])),
        axis=1,
    )
    idx = int(distances.idxmin())
    return idx if float(distances.loc[idx]) < 1.0 else None


def _infer_host_index_for_companion(t2: pd.DataFrame, comp_idx: int) -> int | None:
    if not bool(t2.loc[comp_idx, "is_host"]):
        prev_hosts = [idx for idx in t2.index[t2.index < comp_idx] if bool(t2.loc[idx, "is_host"])]
        return int(prev_hosts[-1]) if prev_hosts else None

    # Four paper-noted binaries have both components listed as exoplanet hosts.
    candidates = []
    for idx, row in t2[t2["is_host"]].iterrows():
        if idx == comp_idx:
            continue
        sep = _angular_distance_arcsec(float(row["RAdeg"]), float(row["DEdeg"]), float(t2.loc[comp_idx, "RAdeg"]), float(t2.loc[comp_idx, "DEdeg"]))
        if sep <= 260.0:
            candidates.append((sep, int(idx)))
    if not candidates:
        return None
    candidates.sort()
    return candidates[0][1]


def recompute_relative_motion_from_table2(table2_path: str, table3_path: str, table4_path: str, tolerance_masyr: float = 0.02) -> dict:
    """Recompute Table 3 parallax, differential proper motion, and CPM from Table 2 astrometry."""
    t2 = _load_table2(table2_path)
    t3 = _load_table3(table3_path)
    t4 = _load_table4(table4_path).set_index("Name", drop=False)
    rows = []
    skipped = []
    for _, rel in t3.iterrows():
        comp_name = rel["Name"]
        table4_row = t4.loc[comp_name] if comp_name in t4.index else None
        comp_idx = _find_table2_index_by_name_or_position(t2, table4_row, comp_name)
        if comp_idx is None:
            skipped.append(comp_name)
            continue
        host_idx = _infer_host_index_for_companion(t2, comp_idx)
        if host_idx is None:
            skipped.append(comp_name)
            continue
        host = t2.loc[host_idx]
        comp = t2.loc[comp_idx]
        d_plx = abs(float(host["Plx"]) - float(comp["Plx"]))
        e_d_plx = math.hypot(float(host["e_Plx"]), float(comp["e_Plx"]))
        d_pm_ra = float(host["pmRA"]) - float(comp["pmRA"])
        d_pm_de = float(host["pmDE"]) - float(comp["pmDE"])
        mu_rel = math.hypot(d_pm_ra, d_pm_de)
        e_mu_rel = math.hypot(float(host["e_pmRA"]), float(host["e_pmDE"]), float(comp["e_pmRA"]), float(comp["e_pmDE"]))
        cpm = math.hypot(float(host["pmRA"]) + float(comp["pmRA"]), float(host["pmDE"]) + float(comp["pmDE"])) / mu_rel if mu_rel else math.inf
        rows.append(
            {
                "companion": comp_name,
                "host": host["Name"],
                "recomputed_Dplx": d_plx,
                "table3_Dplx": float(rel["Dplx"]),
                "recomputed_mu_rel": mu_rel,
                "table3_mu_rel": float(rel["mu_rel"]),
                "recomputed_CPM": cpm,
                "table3_CPM": float(rel["CPM"]),
                "mu_rel_abs_error": abs(mu_rel - float(rel["mu_rel"])),
                "cpm_abs_error": abs(cpm - float(rel["CPM"])),
                "e_mu_rel_from_components": e_mu_rel,
            }
        )
    out = pd.DataFrame(rows)
    return {
        "matched_pairs": int(len(out)),
        "skipped_pairs": skipped,
        "median_mu_rel_abs_error_masyr": float(out["mu_rel_abs_error"].median()) if len(out) else None,
        "max_mu_rel_abs_error_masyr": float(out["mu_rel_abs_error"].max()) if len(out) else None,
        "within_tolerance_pairs": int((out["mu_rel_abs_error"] <= tolerance_masyr).sum()) if len(out) else 0,
        "median_cpm_abs_error": float(out["cpm_abs_error"].median()) if len(out) else None,
        "sample_rows": out.head(12).round(4).to_dict(orient="records"),
    }


def plot_companion_mass_vs_separation(table4_path: str, output_path: str) -> dict:
    df = _companion_table(table4_path, explode_components=True)
    df["class"] = df.apply(
        lambda row: "white dwarf"
        if row["Note"] == "WD"
        else ("brown dwarf" if pd.notna(row["Mass_num"]) and row["Mass_num"] < HYDROGEN_BURNING_LIMIT_MSUN else "stellar"),
        axis=1,
    )
    plot_df = df.dropna(subset=["Sep", "Mass_num"]).copy()

    colors = {"stellar": "#4C78A8", "brown dwarf": "#F58518", "white dwarf": "#54A24B"}
    plt.figure(figsize=(7, 5))
    for klass, sub in plot_df.groupby("class"):
        plt.scatter(sub["Sep"], sub["Mass_num"], label=klass, alpha=0.75, s=28, color=colors[klass])
    plt.xscale("log")
    plt.yscale("log")
    plt.xlabel("Projected separation (au)")
    plt.ylabel("Companion mass (Msun)")
    plt.title("Released companion population")
    plt.legend(frameon=False)
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), "mass_points": int(len(plot_df))}


def plot_astrometric_support(table3_path: str, output_path: str) -> dict:
    df = _load_table3(table3_path)
    df = df.dropna(subset=["rho", "CPM", "sDplx"])

    plt.figure(figsize=(7, 5))
    sc = plt.scatter(df["rho"], df["CPM"], c=df["sDplx"], cmap="viridis_r", alpha=0.75, s=28)
    plt.xscale("log")
    plt.xlabel("Angular separation (arcsec)")
    plt.ylabel("Common proper motion index")
    plt.title("Released astrometric support for companion candidates")
    cbar = plt.colorbar(sc)
    cbar.set_label("Parallax-difference significance")
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), "points": int(len(df))}
def plot_companion_type_counts(table4_path: str, output_path: str) -> dict:
    summary = companion_population_summary(table4_path)
    counts = {
        "stellar": summary["paper_type_counts"]["main_sequence_stellar"],
        "white dwarf": summary["paper_type_counts"]["white_dwarf"],
        "brown dwarf": summary["paper_type_counts"]["brown_dwarf"],
    }
    plt.figure(figsize=(5.8, 4.2))
    plt.bar(list(counts), list(counts.values()), color="#4C78A8")
    plt.ylabel("Number of companions")
    plt.title("Released companion classifications")
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), "class_counts": counts}
