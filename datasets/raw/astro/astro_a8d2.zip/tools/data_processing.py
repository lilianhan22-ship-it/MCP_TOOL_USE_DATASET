from __future__ import annotations

from pathlib import Path
from typing import Iterable


def list_files(root: str, suffixes: Iterable[str] | None = None) -> list[str]:
    path = Path(root)
    items: list[str] = []
    for child in sorted(path.rglob("*")):
        if not child.is_file():
            continue
        if suffixes and child.suffix.lower() not in suffixes:
            continue
        items.append(str(child))
    return items


def read_text(path: str) -> str:
    return Path(path).read_text(encoding="utf-8", errors="ignore")
