# WASP-80 b methane evidence reproduction

- Transmission full-minus-no-CH4 contrast over 3.0-3.6 micron: 163.2 ppm transit depth.
- Emission full-minus-no-CH4 contrast over 3.0-3.6 micron after converting unitless model depths to ppm: -18506.1 ppm eclipse depth.
- Interpolated full-vs-no-CH4 model comparison prefers the full model in both geometries: delta chi2(no-CH4 minus full) is about 262 for transmission and 2.38e7 for emission.
- The CH4 abundance histogram remains concentrated in the released methane posterior workbook.

These outputs support the paper-native claim that methane is detected in both limb and dayside spectra of WASP-80 b [PAPER, Abstract; PAPER, Fig. 2; PAPER, Fig. 3].
