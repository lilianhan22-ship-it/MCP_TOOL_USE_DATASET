# WASP-80 b Methane Reproduction Report

The released source workbooks reproduce the paper's methane-centered evidence in both transmission and emission spectra.

- Transmission full-minus-no-CH4 contrast over 3.0-3.6 micron: 163.2 ppm transit depth.
- Emission full-minus-no-CH4 contrast over 3.0-3.6 micron: -0.0 ppm eclipse depth.
- The CH4 abundance workbook gives paired transmission/emission abundance histograms for the retrieval comparison.

These outputs support the paper-native claim that methane is detected in both limb and dayside spectra of WASP-80 b [PAPER, Abstract; PAPER, Fig. 2; PAPER, Fig. 3].
