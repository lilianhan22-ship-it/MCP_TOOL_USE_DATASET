from __future__ import annotations

from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "input_data" / "data"
SOURCE = DATA / "41586_2023_6687_MOESM3_ESM.xlsx"
ABUNDANCE = DATA / "41586_2023_6687_MOESM4_ESM.xlsx"


def _read(sheet: str, path: Path = SOURCE) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name=sheet)


def load_spectrum(kind: str = "transmission") -> pd.DataFrame:
    sheet = "Transmission_Data" if kind.lower().startswith("trans") else "Emission_Data"
    df = _read(sheet)
    cols = list(df.columns)
    wave = cols[0]; val = cols[1]; err = cols[2]
    out = pd.DataFrame({"wavelength": pd.to_numeric(df[wave], errors="coerce"), "value": pd.to_numeric(df[val], errors="coerce"), "uncertainty": pd.to_numeric(df[err], errors="coerce")})
    return out.dropna().reset_index(drop=True)


def load_model_grid(kind: str = "transmission") -> pd.DataFrame:
    sheet = "Transmission_Models" if kind.lower().startswith("trans") else "Emission_Models"
    df = _read(sheet)
    out = df.copy()
    out.columns = [str(c).replace("# ", "").strip() for c in out.columns]
    for c in out.columns:
        out[c] = pd.to_numeric(out[c], errors="coerce")
    out = out.dropna(subset=[out.columns[0]]).rename(columns={out.columns[0]: "wavelength"})
    out["full_model_mid"] = out[["full model lower contour", "full model upper contour"]].mean(axis=1)
    out["no_ch4_mid"] = out[["no CH4 model lower contour", "no CH4 model upper contour"]].mean(axis=1)
    return out


def methane_model_contrast(kind: str = "transmission", band: tuple[float, float] = (3.1, 3.6)) -> dict:
    model = load_model_grid(kind)
    sub = model[(model["wavelength"] >= band[0]) & (model["wavelength"] <= band[1])]
    if sub.empty:
        raise ValueError("Methane band not covered by model grid")
    contrast = sub["full_model_mid"] - sub["no_ch4_mid"]
    return {"kind": kind, "band_micron": list(band), "mean_full_minus_no_ch4": float(contrast.mean()), "max_abs_full_minus_no_ch4": float(contrast.abs().max()), "points": int(len(sub))}


def abundance_histogram(molecule: str = "CH4") -> pd.DataFrame:
    df = pd.read_excel(ABUNDANCE, sheet_name=f"{molecule}_Free")
    out = df.copy()
    out.columns = [str(c).replace("# ", "").strip() for c in out.columns]
    return out.apply(pd.to_numeric, errors="coerce").dropna(subset=["log abundance"])


def spectrum_checkpoint_summary() -> dict:
    trans = load_spectrum("transmission")
    emis = load_spectrum("emission")
    return {
        "transmission_points": int(len(trans)),
        "emission_points": int(len(emis)),
        "wavelength_min_micron": float(min(trans["wavelength"].min(), emis["wavelength"].min())),
        "wavelength_max_micron": float(max(trans["wavelength"].max(), emis["wavelength"].max())),
        "transmission_ch4_contrast": methane_model_contrast("transmission"),
        "emission_ch4_contrast": methane_model_contrast("emission"),
    }


def plot_transmission_emission_spectra(output_path: str | Path) -> dict:
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(2, 1, figsize=(8.8, 6.2), sharex=True)
    for ax, kind, ylabel in [(axes[0], "transmission", "Transit depth"), (axes[1], "emission", "Eclipse depth")]:
        data = load_spectrum(kind); model = load_model_grid(kind)
        ax.errorbar(data["wavelength"], data["value"], yerr=data["uncertainty"], fmt=".", ms=5, label=f"{kind} data")
        ax.plot(model["wavelength"], model["full_model_mid"], color="black", lw=1, label="full model")
        ax.set_ylabel(ylabel)
        ax.legend(frameon=False, fontsize=8)
    axes[1].set_xlabel("Wavelength (micron)")
    fig.suptitle("WASP-80 b transmission and emission spectra")
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), **spectrum_checkpoint_summary()}


def plot_methane_model_contrast(output_path: str | Path) -> dict:
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(2, 1, figsize=(8.8, 6.2), sharex=True)
    summaries = []
    for ax, kind in [(axes[0], "transmission"), (axes[1], "emission")]:
        model = load_model_grid(kind)
        ax.plot(model["wavelength"], model["full_model_mid"], label="full model", color="#4c78a8")
        ax.plot(model["wavelength"], model["no_ch4_mid"], label="no CH4", color="#f58518")
        ax.axvspan(3.1, 3.6, color="grey", alpha=0.15, label="CH4 band")
        ax.set_ylabel(kind)
        ax.legend(frameon=False, fontsize=8)
        summaries.append(methane_model_contrast(kind))
    axes[1].set_xlabel("Wavelength (micron)")
    fig.suptitle("CH4 model contrast in released WASP-80 b grids")
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), "contrasts": summaries}


def plot_abundance_posteriors(output_path: str | Path) -> dict:
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 4.6))
    rows = []
    for mol, color in [("CH4", "#4c78a8"), ("H2O", "#54a24b"), ("CO2", "#e45756")]:
        df = abundance_histogram(mol)
        x = df["log abundance"]
        y_cols = [c for c in df.columns if "histogram height" in c]
        y = df[y_cols].sum(axis=1)
        ax.plot(x, y, label=mol, color=color)
        rows.append({"molecule": mol, "peak_log_abundance": float(x.iloc[int(np.nanargmax(y))])})
    ax.set_xlabel("Log abundance")
    ax.set_ylabel("Posterior histogram height")
    ax.set_title("Key molecular abundance posteriors")
    ax.legend(frameon=False)
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), "peaks": rows}


def package_smoke_test() -> dict:
    return spectrum_checkpoint_summary()
