"""Data preprocessing utilities: imputation, scaling, train/test split."""

import numpy as np
import pandas as pd
from typing import Tuple, Optional


def impute_missing_values(
    df: pd.DataFrame,
    strategy: str = "median",
    fill_value: Optional[float] = None,
) -> pd.DataFrame:
    """Impute missing values in a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame with potential missing values.
    strategy : str
        Imputation strategy: 'mean', 'median', 'zero', 'constant', 'min'.
    fill_value : float, optional
        Value to use when strategy is 'constant'.

    Returns
    -------
    pd.DataFrame
        DataFrame with missing values imputed.
    """
    result = df.copy()
    for col in result.columns:
        if result[col].isna().any():
            if strategy == "mean":
                result[col].fillna(result[col].mean(), inplace=True)
            elif strategy == "median":
                result[col].fillna(result[col].median(), inplace=True)
            elif strategy == "zero":
                result[col].fillna(0, inplace=True)
            elif strategy == "min":
                result[col].fillna(result[col].min(), inplace=True)
            elif strategy == "constant":
                result[col].fillna(fill_value if fill_value is not None else 0, inplace=True)
    return result


def scale_features(
    df: pd.DataFrame,
    method: str = "standard",
) -> Tuple[pd.DataFrame, dict]:
    """Scale features using standard or min-max normalization.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    method : str
        Scaling method: 'standard' (z-score) or 'minmax'.

    Returns
    -------
    Tuple[pd.DataFrame, dict]
        Scaled DataFrame and dictionary of scaling parameters.
    """
    params = {}
    result = df.copy()
    for col in result.columns:
        if method == "standard":
            mu = result[col].mean()
            sigma = result[col].std()
            if sigma == 0:
                sigma = 1.0
            result[col] = (result[col] - mu) / sigma
            params[col] = {"mean": mu, "std": sigma}
        elif method == "minmax":
            cmin = result[col].min()
            cmax = result[col].max()
            rng = cmax - cmin
            if rng == 0:
                rng = 1.0
            result[col] = (result[col] - cmin) / rng
            params[col] = {"min": cmin, "max": cmax}
    return result, params


def stratified_train_test_split(
    X: pd.DataFrame,
    y: pd.Series,
    test_size: float = 0.33,
    random_state: int = 42,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """Split data into train and test sets with stratification on labels.

    Parameters
    ----------
    X : pd.DataFrame
        Feature matrix.
    y : pd.Series
        Labels.
    test_size : float
        Fraction of data to use as test set.
    random_state : int
        Random seed for reproducibility.

    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]
        X_train, X_test, y_train, y_test.
    """
    np.random.seed(random_state)
    classes = y.unique()
    train_idx = []
    test_idx = []
    for c in classes:
        c_idx = y[y == c].index.tolist()
        np.random.shuffle(c_idx)
        n_test = max(1, int(len(c_idx) * test_size))
        test_idx.extend(c_idx[:n_test])
        train_idx.extend(c_idx[n_test:])
    return X.loc[train_idx], X.loc[test_idx], y.loc[train_idx], y.loc[test_idx]


def survival_train_test_split(
    X: pd.DataFrame,
    time: pd.Series,
    event: pd.Series,
    test_size: float = 0.33,
    random_state: int = 42,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series, pd.Series, pd.Series]:
    """Split survival data into train and test sets with stratification on event.

    Parameters
    ----------
    X : pd.DataFrame
        Feature matrix.
    time : pd.Series
        Survival times.
    event : pd.Series
        Event indicators (1 = event, 0 = censored).
    test_size : float
        Fraction of data for test.
    random_state : int
        Random seed.

    Returns
    -------
    Tuple
        X_train, X_test, time_train, time_test, event_train, event_test.
    """
    np.random.seed(random_state)
    idx_event = event[event == 1].index.tolist()
    idx_censor = event[event == 0].index.tolist()

    np.random.shuffle(idx_event)
    np.random.shuffle(idx_censor)

    n_test_e = max(1, int(len(idx_event) * test_size))
    n_test_c = max(1, int(len(idx_censor) * test_size))

    test_idx = idx_event[:n_test_e] + idx_censor[:n_test_c]
    train_idx = idx_event[n_test_e:] + idx_censor[n_test_c:]

    return (
        X.loc[train_idx], X.loc[test_idx],
        time.loc[train_idx], time.loc[test_idx],
        event.loc[train_idx], event.loc[test_idx],
    )
