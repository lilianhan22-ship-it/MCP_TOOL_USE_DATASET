"""Data loading and preprocessing utilities for clinical metabolomics data."""

import pandas as pd
import numpy as np
from typing import Optional, Tuple


def load_metabolomics_csv(
    filepath: str,
    transpose: bool = False,
) -> pd.DataFrame:
    """Load a metabolomics CSV file that is stored with rows as samples and
    columns as metabolites.

    The bundled metabolomics CSVs already use samples (first column, e.g.
    ``Batch01_49N``) as the row index and metabolite names as columns, so the
    file is returned as-is (samples x metabolites) by default.

    Parameters
    ----------
    filepath : str
        Path to the CSV file.
    transpose : bool
        Set to True only if the on-disk file is stored as
        metabolites x samples and needs to be transposed to samples x
        metabolites. The bundled files do not require this.

    Returns
    -------
    pd.DataFrame
        DataFrame with samples as rows and metabolites as columns.
    """
    df = pd.read_csv(filepath, index_col=0)
    if transpose:
        df = df.T
    df = df.apply(pd.to_numeric, errors="coerce")
    return df


def load_clinical_csv(filepath: str) -> pd.DataFrame:
    """Load a clinical characteristics CSV file.

    Parameters
    ----------
    filepath : str
        Path to the CSV file.

    Returns
    -------
    pd.DataFrame
        DataFrame with clinical variables.
    """
    df = pd.read_csv(filepath)
    return df


def load_survival_csv(filepath: str) -> pd.DataFrame:
    """Load tidy survival outcomes without model-derived risk scores.

    Parameters
    ----------
    filepath : str
        Path to `survival_outcomes.csv`.

    Returns
    -------
    pd.DataFrame
        DataFrame with Patient_ID, OS_status, OS_months, DFS_status, DFS_months.
    """
    df = pd.read_csv(filepath)
    rename = {
        "patient_id": "Patient_ID",
        "Patient ID": "Patient_ID",
        "OS (months)": "OS_months",
        "DFS (months)": "DFS_months",
    }
    df = df.rename(columns={k: v for k, v in rename.items() if k in df.columns})
    required = ["Patient_ID", "OS_status", "OS_months"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required survival columns: {missing}")
    for col in ["OS_status", "OS_months", "DFS_status", "DFS_months"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    if any("risk" in c.lower() for c in df.columns):
        raise ValueError("Survival outcome inputs must not include model-derived risk scores")
    return df


def load_sample_metadata(filepath: str) -> pd.DataFrame:
    """Load explicit diagnostic/prognostic sample metadata and split fields."""
    df = pd.read_csv(filepath)
    if "sample_id" not in df.columns:
        raise ValueError("sample metadata must contain a sample_id column")
    return df


def extract_sample_labels(sample_ids: pd.Index) -> pd.Series:
    """Extract GC/NGC labels from sample IDs based on naming convention.

    Sample IDs ending with 'N' are non-GC controls (NGC),
    those ending with 'P' are gastric cancer patients (GC).

    Parameters
    ----------
    sample_ids : pd.Index
        Index of sample identifiers.

    Returns
    -------
    pd.Series
        Binary labels: 1 for GC, 0 for NGC.
    """
    labels = []
    for sid in sample_ids:
        sid_str = str(sid).strip()
        # Remove batch prefix if present
        if "_" in sid_str:
            sid_str = sid_str.split("_", 1)[1]
        if sid_str.endswith("N"):
            labels.append(0)
        elif sid_str.endswith("P"):
            labels.append(1)
        else:
            labels.append(np.nan)
    return pd.Series(labels, index=sample_ids, name="label")


def merge_metabolomics_labels(
    metab_df: pd.DataFrame,
    labels: pd.Series,
) -> Tuple[pd.DataFrame, pd.Series]:
    """Merge metabolomics data with sample labels, dropping unlabeled samples.

    Parameters
    ----------
    metab_df : pd.DataFrame
        Metabolomics data (samples x metabolites).
    labels : pd.Series
        Binary labels for each sample.

    Returns
    -------
    Tuple[pd.DataFrame, pd.Series]
        Cleaned data and corresponding labels.
    """
    common = metab_df.index.intersection(labels.index)
    X = metab_df.loc[common].copy()
    y = labels.loc[common].copy()
    mask = y.notna()
    return X[mask], y[mask].astype(int)
