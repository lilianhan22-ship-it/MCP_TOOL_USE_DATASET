"""Plotting utilities for clinical prediction analysis."""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from typing import Optional, List, Tuple


def plot_roc_curve(
    fpr: np.ndarray,
    tpr: np.ndarray,
    auc_score: float,
    ci_lower: Optional[float] = None,
    ci_upper: Optional[float] = None,
    title: str = "ROC Curve",
    save_path: str = "roc_curve.png",
) -> str:
    """Plot ROC curve with AUC and optional confidence interval.

    Parameters
    ----------
    fpr : np.ndarray
        False positive rates.
    tpr : np.ndarray
        True positive rates.
    auc_score : float
        Area under the ROC curve.
    ci_lower, ci_upper : float, optional
        Lower and upper bounds of AUC confidence interval.
    title : str
        Plot title.
    save_path : str
        File path to save the figure.

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(1, 1, figsize=(6, 6))
    label = f"AUROC={auc_score:.3f}"
    if ci_lower is not None and ci_upper is not None:
        label += f"\n95% CI: {ci_lower:.3f} - {ci_upper:.3f}"
    ax.plot(fpr, tpr, color="steelblue", lw=2, label=label)
    ax.plot([0, 1], [0, 1], "k--", lw=1, alpha=0.5)
    ax.set_xlabel("False positive rate", fontsize=12)
    ax.set_ylabel("True positive rate", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(loc="lower right", fontsize=11)
    ax.set_xlim([0, 1])
    ax.set_ylim([0, 1.02])
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_feature_contribution(
    features: List[str],
    contributions: np.ndarray,
    title: str = "Feature Contributions",
    save_path: str = "feature_contributions.png",
) -> str:
    """Plot horizontal bar chart of feature contributions.

    Parameters
    ----------
    features : list of str
        Feature names.
    contributions : np.ndarray
        Contribution values.
    title : str
        Plot title.
    save_path : str
        File path to save the figure.

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(1, 1, figsize=(8, max(4, len(features) * 0.5)))
    y_pos = np.arange(len(features))
    ax.barh(y_pos, contributions, color="steelblue", edgecolor="none")
    ax.set_yticks(y_pos)
    ax.set_yticklabels(features, fontsize=10)
    ax.set_xlabel("Contribution", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.invert_yaxis()
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_volcano(
    volcano_df: pd.DataFrame,
    title: str = "Volcano Plot",
    save_path: str = "volcano_plot.png",
) -> str:
    """Plot a volcano plot of differential metabolites.

    Parameters
    ----------
    volcano_df : pd.DataFrame
        Must contain columns: log2_fc, neg_log10_p, regulation, feature.
    title : str
        Plot title.
    save_path : str
        File path to save the figure.

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(1, 1, figsize=(8, 6))

    colors = {"Up": "#7B2D8E", "Down": "#1B9E77", "Not significant": "#BBBBBB"}
    for reg, color in colors.items():
        mask = volcano_df["regulation"] == reg
        subset = volcano_df[mask]
        ax.scatter(subset["log2_fc"], subset["neg_log10_p"],
                   c=color, s=30, alpha=0.7, label=f"{reg} (n={len(subset)})",
                   edgecolors="none")

    # Label top significant metabolites
    top = volcano_df[volcano_df["regulation"] != "Not significant"].nlargest(10, "neg_log10_p")
    for _, row in top.iterrows():
        ax.annotate(row["feature"], (row["log2_fc"], row["neg_log10_p"]),
                    fontsize=7, ha="center", va="bottom")

    ax.set_xlabel("Log$_2$ (FC, GC/NGC)", fontsize=12)
    ax.set_ylabel("-Log$_{10}$ (Adjusted P value)", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=10)
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_pca_scatter(
    scores: np.ndarray,
    labels: np.ndarray,
    var_explained: np.ndarray,
    class_names: Optional[dict] = None,
    title: str = "PCA",
    save_path: str = "pca_scatter.png",
) -> str:
    """Plot PCA scatter plot colored by group labels.

    Parameters
    ----------
    scores : np.ndarray
        PCA scores (n_samples x 2).
    labels : np.ndarray
        Group labels.
    var_explained : np.ndarray
        Variance explained ratios.
    class_names : dict, optional
        Mapping from label to display name.
    title : str
        Plot title.
    save_path : str
        File path to save the figure.

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(1, 1, figsize=(7, 6))
    colors = ["#7B2D8E", "#1B9E77", "#D95F02", "#E7298A"]

    unique_labels = sorted(np.unique(labels))
    for i, lab in enumerate(unique_labels):
        mask = labels == lab
        name = class_names.get(lab, str(lab)) if class_names else str(lab)
        ax.scatter(scores[mask, 0], scores[mask, 1],
                   c=colors[i % len(colors)], s=30, alpha=0.6,
                   label=name, edgecolors="none")

    ax.set_xlabel(f"PC1 ({var_explained[0]*100:.2f}%)", fontsize=12)
    ax.set_ylabel(f"PC2 ({var_explained[1]*100:.2f}%)", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=10)
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_kaplan_meier(
    time_groups: List[pd.Series],
    event_groups: List[pd.Series],
    group_names: List[str],
    p_value: Optional[float] = None,
    title: str = "Kaplan-Meier Survival Curve",
    ylabel: str = "Survival probability",
    save_path: str = "km_curve.png",
) -> str:
    """Plot Kaplan-Meier survival curves for multiple groups.

    Parameters
    ----------
    time_groups : list of pd.Series
        Survival times for each group.
    event_groups : list of pd.Series
        Event indicators for each group.
    group_names : list of str
        Names for each group.
    p_value : float, optional
        Log-rank test p-value.
    title : str
        Plot title.
    ylabel : str
        Y-axis label.
    save_path : str
        File path to save the figure.

    Returns
    -------
    str
        Path to saved figure.
    """
    from lifelines import KaplanMeierFitter

    fig, ax = plt.subplots(1, 1, figsize=(7, 5))
    colors = ["#1B9E77", "#D95F02", "#E7298A", "#7570B3"]

    for i, (t, e, name) in enumerate(zip(time_groups, event_groups, group_names)):
        kmf = KaplanMeierFitter()
        kmf.fit(t, e, label=name)
        kmf.plot_survival_function(ax=ax, color=colors[i % len(colors)], lw=2)

    if p_value is not None:
        ax.text(0.7, 0.85, f"P = {p_value:.4g}", transform=ax.transAxes,
                fontsize=11, bbox=dict(boxstyle="round", facecolor="white", alpha=0.8))

    ax.set_xlabel("Time (months)", fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=10)
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_forest_hazard_ratios(
    features: List[str],
    hr: np.ndarray,
    lower_ci: np.ndarray,
    upper_ci: np.ndarray,
    p_values: Optional[np.ndarray] = None,
    title: str = "Forest Plot of Hazard Ratios",
    save_path: str = "forest_plot.png",
) -> str:
    """Plot a forest plot of hazard ratios with confidence intervals.

    Parameters
    ----------
    features : list of str
        Feature/variable names.
    hr : np.ndarray
        Hazard ratios.
    lower_ci, upper_ci : np.ndarray
        Lower and upper 95% CI bounds.
    p_values : np.ndarray, optional
        P-values for each feature.
    title : str
        Plot title.
    save_path : str
        File path to save the figure.

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(1, 1, figsize=(8, max(4, len(features) * 0.6)))
    y_pos = np.arange(len(features))

    # Use log10 scale for HRs
    log_hr = np.log10(hr)
    log_lower = np.log10(lower_ci)
    log_upper = np.log10(upper_ci)

    ax.errorbar(log_hr, y_pos, xerr=[log_hr - log_lower, log_upper - log_hr],
                fmt="o", color="steelblue", capsize=3, markersize=6)
    ax.axvline(x=0, color="gray", linestyle="--", lw=1)

    labels = []
    for i, feat in enumerate(features):
        lbl = f"{feat}"
        if p_values is not None:
            lbl += f"  (p={p_values[i]:.3g})"
        labels.append(lbl)

    ax.set_yticks(y_pos)
    ax.set_yticklabels(labels, fontsize=9)
    ax.set_xlabel("Log$_{10}$ (Hazard Ratio)", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.invert_yaxis()
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_calibration_curve(
    mean_predicted: np.ndarray,
    fraction_positives: np.ndarray,
    title: str = "Calibration Curve",
    save_path: str = "calibration_curve.png",
) -> str:
    """Plot calibration curve (observed vs predicted probabilities).

    Parameters
    ----------
    mean_predicted : np.ndarray
        Mean predicted probabilities per bin.
    fraction_positives : np.ndarray
        Fraction of positives per bin.
    title : str
        Plot title.
    save_path : str
        File path to save the figure.

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(1, 1, figsize=(6, 6))
    ax.plot(mean_predicted, fraction_positives, "o-", color="steelblue",
            lw=2, markersize=6, label="Model")
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Perfect calibration")
    ax.set_xlabel("Mean predicted probability", fontsize=12)
    ax.set_ylabel("Fraction of positives", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=10)
    ax.set_xlim([0, 1])
    ax.set_ylim([0, 1])
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_risk_stratification(
    risk_scores: np.ndarray,
    survival_time: pd.Series,
    survival_status: pd.Series,
    cutoff: float = 2.1,
    title: str = "Risk Stratification",
    save_path: str = "risk_stratification.png",
) -> str:
    """Plot risk score vs survival time with stratification cutoff.

    Parameters
    ----------
    risk_scores : np.ndarray
        Predicted risk scores.
    survival_time : pd.Series
        Survival time in months.
    survival_status : pd.Series
        Event status (1=event, 0=censored).
    cutoff : float
        Risk score cutoff for high/low groups.
    title : str
        Plot title.
    save_path : str
        File path to save the figure.

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(1, 1, figsize=(7, 5))

    survived = survival_status == 0
    deceased = survival_status == 1

    ax.scatter(risk_scores[survived], survival_time[survived],
               c="#1B9E77", s=40, alpha=0.7, label="Survived", edgecolors="none")
    ax.scatter(risk_scores[deceased], survival_time[deceased],
               c="#888888", s=40, alpha=0.7, label="Deceased", edgecolors="none")

    ax.axvline(x=cutoff, color="gray", linestyle="--", lw=1.5, alpha=0.7)
    ax.text(cutoff + 0.05, ax.get_ylim()[1] * 0.95, f"cutoff={cutoff}",
            fontsize=10, color="gray")

    ax.set_xlabel("Predicted risk score for GC", fontsize=12)
    ax.set_ylabel("Overall survival (months)", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=10)
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path


def plot_cindex_comparison(
    model_names: List[str],
    cindex_values: List[float],
    ci_lower: Optional[List[float]] = None,
    ci_upper: Optional[List[float]] = None,
    title: str = "C-index Comparison",
    save_path: str = "cindex_comparison.png",
) -> str:
    """Plot horizontal bar chart comparing C-index values across models.

    Parameters
    ----------
    model_names : list of str
        Names of models/clinical factors.
    cindex_values : list of float
        C-index values.
    ci_lower, ci_upper : list of float, optional
        Confidence interval bounds.
    title : str
        Plot title.
    save_path : str
        File path to save the figure.

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(1, 1, figsize=(8, max(3, len(model_names) * 0.6)))
    y_pos = np.arange(len(model_names))

    colors = plt.cm.Set2(np.linspace(0, 1, len(model_names)))

    if ci_lower is not None and ci_upper is not None:
        xerr = [
            [v - l for v, l in zip(cindex_values, ci_lower)],
            [u - v for v, u in zip(cindex_values, ci_upper)],
        ]
        ax.barh(y_pos, cindex_values, xerr=xerr, color=colors,
                edgecolor="none", capsize=3, height=0.6)
    else:
        ax.barh(y_pos, cindex_values, color=colors, edgecolor="none", height=0.6)

    for i, v in enumerate(cindex_values):
        ci_text = f"{v:.3f}"
        if ci_lower is not None and ci_upper is not None:
            ci_text += f" ({ci_lower[i]:.3f}-{ci_upper[i]:.3f})"
        ax.text(max(cindex_values) + 0.02, y_pos[i], ci_text,
                va="center", fontsize=9)

    ax.set_yticks(y_pos)
    ax.set_yticklabels(model_names, fontsize=10)
    ax.set_xlabel("C-index", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.set_xlim([0, 1.0])
    ax.invert_yaxis()
    plt.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return save_path
