"""Survival analysis tools: Cox regression, random survival forest, Kaplan-Meier."""

import numpy as np
import pandas as pd
from typing import Tuple, Optional, Dict, List


def fit_univariate_cox(
    X: pd.DataFrame,
    time: pd.Series,
    event: pd.Series,
) -> pd.DataFrame:
    """Fit univariate Cox proportional hazards models for each feature.

    Parameters
    ----------
    X : pd.DataFrame
        Feature matrix (samples x features).
    time : pd.Series
        Survival time.
    event : pd.Series
        Event indicator (1 = event occurred).

    Returns
    -------
    pd.DataFrame
        Results with columns: feature, coef, hr, p_value, lower_ci, upper_ci.
    """
    from lifelines import CoxPHFitter

    results = []
    for col in X.columns:
        df = pd.DataFrame({
            "T": time.values,
            "E": event.values,
            col: X[col].values,
        }).dropna()
        if len(df) < 10 or df["E"].sum() < 3:
            continue
        try:
            cph = CoxPHFitter()
            cph.fit(df, duration_col="T", event_col="E")
            summary = cph.summary
            results.append({
                "feature": col,
                "coef": summary.loc[col, "coef"],
                "hr": summary.loc[col, "exp(coef)"],
                "p_value": summary.loc[col, "p"],
                "lower_ci": summary.loc[col, "exp(coef) lower 95%"],
                "upper_ci": summary.loc[col, "exp(coef) upper 95%"],
            })
        except Exception:
            continue

    return pd.DataFrame(results)


def fit_multivariate_cox(
    X: pd.DataFrame,
    time: pd.Series,
    event: pd.Series,
    covariates: Optional[List[str]] = None,
) -> Tuple[object, pd.DataFrame]:
    """Fit a multivariate Cox proportional hazards model.

    Parameters
    ----------
    X : pd.DataFrame
        Feature matrix.
    time : pd.Series
        Survival time.
    event : pd.Series
        Event indicator.
    covariates : list of str, optional
        Subset of columns to include. If None, uses all.

    Returns
    -------
    Tuple[object, pd.DataFrame]
        Fitted CoxPHFitter model and summary DataFrame.
    """
    from lifelines import CoxPHFitter

    if covariates is not None:
        X = X[covariates]

    df = pd.concat([
        X.reset_index(drop=True),
        pd.Series(time.values, name="T"),
        pd.Series(event.values, name="E"),
    ], axis=1).dropna()

    cph = CoxPHFitter()
    cph.fit(df, duration_col="T", event_col="E")
    return cph, cph.summary


def fit_random_survival_forest(
    X_train: pd.DataFrame,
    time_train: pd.Series,
    event_train: pd.Series,
    n_estimators: int = 1000,
    max_features: str = "sqrt",
    random_state: int = 42,
) -> object:
    """Fit a random survival forest model.

    Parameters
    ----------
    X_train : pd.DataFrame
        Training feature matrix.
    time_train : pd.Series
        Training survival times.
    event_train : pd.Series
        Training event indicators.
    n_estimators : int
        Number of trees in the forest.
    max_features : str
        Feature subset strategy: 'sqrt', 'log2', or float.
    random_state : int
        Random seed.

    Returns
    -------
    object
        Fitted RandomSurvivalForest model.
    """
    from sksurv.ensemble import RandomSurvivalForest

    y_train = np.array(
        [(bool(e), t) for e, t in zip(event_train, time_train)],
        dtype=[("event", bool), ("time", float)],
    )

    rsf = RandomSurvivalForest(
        n_estimators=n_estimators,
        max_features=max_features,
        random_state=random_state,
        n_jobs=-1,
    )
    rsf.fit(X_train.values, y_train)
    return rsf


def predict_risk_scores(
    model,
    X: pd.DataFrame,
) -> np.ndarray:
    """Predict risk scores from a fitted survival model.

    Parameters
    ----------
    model : fitted model
        A fitted survival model (CoxPH or RSF).
    X : pd.DataFrame
        Feature matrix.

    Returns
    -------
    np.ndarray
        Predicted risk scores (higher = worse prognosis).
    """
    if hasattr(model, "predict"):
        return model.predict(X.values if hasattr(X, "values") else X)
    elif hasattr(model, "predict_partial_hazard"):
        return model.predict_partial_hazard(X).values
    raise ValueError("Model has no predict or predict_partial_hazard method")


def compute_concordance_index(
    time: pd.Series,
    event: pd.Series,
    risk_scores: np.ndarray,
) -> float:
    """Compute Harrell's concordance index (C-index).

    Parameters
    ----------
    time : pd.Series
        Survival times.
    event : pd.Series
        Event indicators.
    risk_scores : np.ndarray
        Predicted risk scores.

    Returns
    -------
    float
        Concordance index value.
    """
    from lifelines.utils import concordance_index

    return concordance_index(time, -risk_scores, event)


def kaplan_meier_estimate(
    time: pd.Series,
    event: pd.Series,
    label: str = "KM",
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Compute Kaplan-Meier survival estimates.

    Parameters
    ----------
    time : pd.Series
        Survival times.
    event : pd.Series
        Event indicators.
    label : str
        Label for the estimate.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]
        timeline, survival_probabilities, lower_ci, upper_ci.
    """
    from lifelines import KaplanMeierFitter

    kmf = KaplanMeierFitter()
    kmf.fit(time, event, label=label)
    ci = kmf.confidence_interval_survival_function_
    return (
        kmf.timeline,
        kmf.survival_function_.values.flatten(),
        ci.iloc[:, 0].values,
        ci.iloc[:, 1].values,
    )


def logrank_test(
    time1: pd.Series,
    event1: pd.Series,
    time2: pd.Series,
    event2: pd.Series,
) -> Tuple[float, float]:
    """Perform log-rank test between two survival curves.

    Parameters
    ----------
    time1, event1 : pd.Series
        Group 1 survival data.
    time2, event2 : pd.Series
        Group 2 survival data.

    Returns
    -------
    Tuple[float, float]
        test statistic and p-value.
    """
    from lifelines.statistics import logrank_test as lr_test

    result = lr_test(time1, time2, event1, event2)
    return result.test_statistic, result.p_value
