"""Classification models: logistic regression, random forest with bootstrap."""

import numpy as np
import pandas as pd
from typing import Tuple, Optional, Dict


def fit_logistic_regression(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    penalty: str = "l2",
    C: float = 1.0,
    max_iter: int = 10000,
    random_state: int = 42,
) -> object:
    """Fit a logistic regression classifier.

    Parameters
    ----------
    X_train : pd.DataFrame
        Training feature matrix.
    y_train : pd.Series
        Training labels.
    penalty : str
        Regularization type: 'l1', 'l2', 'elasticnet', 'none'.
    C : float
        Inverse of regularization strength.
    max_iter : int
        Maximum iterations.
    random_state : int
        Random seed.

    Returns
    -------
    object
        Fitted LogisticRegression model.
    """
    from sklearn.linear_model import LogisticRegression
    import warnings
    warnings.filterwarnings("ignore", category=FutureWarning)

    # Map requested penalty to an sklearn-compatible (penalty, solver, l1_ratio)
    # configuration. The penalty argument is passed explicitly so that L1/
    # elasticnet regularization actually takes effect rather than silently
    # falling back to the LogisticRegression default of "l2".
    if penalty in ("none", None):
        sk_penalty = None
        solver = "lbfgs"
        l1_ratio = None
    elif penalty == "l1":
        sk_penalty = "l1"
        solver = "saga"
        l1_ratio = None
    elif penalty == "elasticnet":
        sk_penalty = "elasticnet"
        solver = "saga"
        l1_ratio = 0.5
    else:  # default / "l2"
        sk_penalty = "l2"
        solver = "lbfgs"
        l1_ratio = None

    model = LogisticRegression(
        penalty=sk_penalty,
        C=C,
        solver=solver,
        max_iter=max_iter,
        random_state=random_state,
        l1_ratio=l1_ratio,
    )
    model.fit(X_train, y_train)
    return model


def fit_random_forest_classifier(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    n_estimators: int = 100,
    max_features: str = "sqrt",
    criterion: str = "gini",
    random_state: int = 42,
    bootstrap: bool = True,
) -> object:
    """Fit a random forest classifier with bootstrap aggregation.

    Parameters
    ----------
    X_train : pd.DataFrame
        Training feature matrix.
    y_train : pd.Series
        Training labels.
    n_estimators : int
        Number of trees.
    max_features : str
        Feature subset strategy: 'sqrt', 'log2', or float.
    criterion : str
        Split criterion: 'gini' or 'entropy'.
    random_state : int
        Random seed.
    bootstrap : bool
        Whether to use bootstrap sampling.

    Returns
    -------
    object
        Fitted RandomForestClassifier model.
    """
    from sklearn.ensemble import RandomForestClassifier

    model = RandomForestClassifier(
        n_estimators=n_estimators,
        max_features=max_features,
        criterion=criterion,
        random_state=random_state,
        bootstrap=bootstrap,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)
    return model


def predict_proba(model, X: pd.DataFrame) -> np.ndarray:
    """Get predicted probabilities from a fitted classifier.

    Parameters
    ----------
    model : fitted classifier
        A fitted model with predict_proba method.
    X : pd.DataFrame
        Feature matrix.

    Returns
    -------
    np.ndarray
        Predicted probabilities for the positive class.
    """
    if hasattr(model, "predict_proba"):
        return model.predict_proba(X)[:, 1]
    return model.predict(X).astype(float)


def get_feature_contributions(
    model,
    feature_names: list,
) -> pd.DataFrame:
    """Extract feature contributions/importances from a fitted model.

    Parameters
    ----------
    model : fitted model
        Fitted classifier (RF or logistic).
    feature_names : list
        List of feature names.

    Returns
    -------
    pd.DataFrame
        DataFrame with feature and importance columns, sorted by importance.
    """
    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
    elif hasattr(model, "coef_"):
        importances = np.abs(model.coef_[0])
    else:
        raise ValueError("Model does not have feature_importances_ or coef_")

    df = pd.DataFrame({
        "feature": feature_names,
        "importance": importances,
    })
    df = df.sort_values("importance", ascending=False).reset_index(drop=True)
    # Normalize to proportions
    total = df["importance"].sum()
    if total > 0:
        df["contribution"] = df["importance"] / total
    else:
        df["contribution"] = 0.0
    return df
