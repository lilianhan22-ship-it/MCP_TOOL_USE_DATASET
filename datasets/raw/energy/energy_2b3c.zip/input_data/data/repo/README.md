# Carbon Footprint Distributions of Lithium-Ion Batteries and Their Materials
#### Leopold Peiseler, Vanessa Schenker, Karin Schatzmann, Stephan Pfister, Vanessa Wood, Tobias Schmidt

#### ETH Zurich, October 2024
<br>
This repository provides the code and database for our study on the Carbon Footprint (CF) of Lithium-Ion Batteries (LIBs) and their materials. We derive emission curves for lithium carbonate, cobalt sulfate, nickel sulfate, and battery-grade graphite. We also run Monte Carlo simulations for NMC811 and LFP batteries using the emission curves and regionally disaggregated battery production capacity announcements.

## Data Access
All Python code and Excel files necessary to reproduce the results and figures presented in this work are contained in this repository.

As described in our methodology, we translate mine costs into CO2 emissions. Because all cost data are proprietary to S&P Global, they had to be excluded from the repository. However, all mine properties in the modelling Excel files (found in `resources/SP CIQ/`) contain unique S&P Global identifiers that allows everybody with access to the S&P Global database to re-populate the cleared data columns.

Similarly, data from Bloomberg New Energy Finance (BNEF) and ecoinvent cannot be made publicly available through this repository. Data are however available from the authors upon reasonable request and with permission of the respective data provider. Instances where files are retained are indicated by `.txt` files in the respective directories. Excel cells/sheets with retained information are stylized accordingly.

### Using Illustrative Cost and Open Source Data
This repository also contains illustrative cost data for 2 lithium mines to ensure code reproducibility (`resources/SP CIQ/Lithium_properties_SP_CIQ_Open_Source.xlsx`). This file uses open source data (`resources/SP CIQ/SP_CIQ_Lookup_File_Open_Source.xlsx`) for data points that are provided by BNEF and ecoinvent in the original analysis. To use the illustrative cost and open source data, set the variable `bool_open_source` in `src/global_variables.py` to `True` and execute `src/notebooks/02a_Create_Emission_Curves.ipynb` cell-by-cell. Make sure to uncomment the correct line for lithium (`commodity, product_short_list = "Lithium", ["Con", "Car"]`).

It is worth mentioning that the inventory used for cell CF modelling (`data/BW databases/battery databases/battery_cell_db_v10.xlsx`) is based on ecoinvent. The ecoinvent LIB dataset, in turn, is almost entirely built on [Crenna et al. (2021)](https://doi.org/10.1016/j.resconrec.2021.105619).

### @Risk as Required Excel Plug-in for Uncertainty Analysis
Please also note that all uncertainty analyses for the material CF modelling in Excel are done using the tool @Risk (https://lumivero.com/products/at-risk/). Free trials for this tool are available as of the date of writing this file. This tool must be installed to view some Excel cells (formulas).

## Getting Started
Recreate the conda environment of this repository from the YAML file by typing `conda env create -f environment.yml` in your terminal. Note that you need to adapt the last line of the YAML file to match your system.

## License
This work is licensed under a
[Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License][cc-by-nc-sa]. The details of the license can be found in the `LICENSE.txt` file.

[![CC BY-NC-SA 4.0][cc-by-nc-sa-image]][cc-by-nc-sa]

[cc-by-nc-sa]: http://creativecommons.org/licenses/by-nc-sa/4.0/
[cc-by-nc-sa-image]: https://licensebuttons.net/l/by-nc-sa/4.0/88x31.png
[cc-by-nc-sa-shield]: https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-lightgrey.svg