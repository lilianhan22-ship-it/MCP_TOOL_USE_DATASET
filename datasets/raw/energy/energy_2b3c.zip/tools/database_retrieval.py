from __future__ import annotations

from pathlib import Path

from pypdf import PdfReader

from data_processing import data_root, package_root


def locate_file(*relative_candidates: str) -> Path:
    base = package_root()
    for rel in relative_candidates:
        candidate = Path(rel)
        if candidate.exists():
            return candidate
        candidate = base / rel
        if candidate.exists():
            return candidate
    raise FileNotFoundError(f"Could not find any of: {relative_candidates}")


def list_public_files() -> list[str]:
    root = data_root()
    return sorted(str(path.relative_to(root)) for path in root.rglob("*") if path.is_file())


def pdf_text(path: Path | str, max_pages: int | None = None) -> str:
    reader = PdfReader(str(path))
    pages = reader.pages if max_pages is None else reader.pages[:max_pages]
    return "\n".join(page.extract_text() or "" for page in pages)


def text_snippet(path: Path | str, needle: str, window: int = 500) -> str:
    txt = pdf_text(path)
    idx = txt.lower().find(needle.lower())
    if idx == -1:
        return ""
    return txt[max(0, idx - window) : idx + window]
