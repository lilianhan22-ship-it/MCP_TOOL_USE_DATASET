#!/usr/bin/env python3

from __future__ import annotations

from pathlib import Path
import re

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def _artifact_path(filename: str) -> Path:
    path = Path(__file__).resolve().parents[1] / "artifacts" / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _read_sheet(path: str, sheet_name: str) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name=sheet_name, header=None)


def _clean_label(value) -> str:
    text = str(value).strip()
    return re.sub(r"\s+", " ", text)


def _find_row_containing(raw: pd.DataFrame, pattern: str) -> int:
    regex = re.compile(pattern, re.IGNORECASE)
    for idx, row in raw.iterrows():
        if any(regex.search(_clean_label(value)) for value in row.tolist()):
            return int(idx)
    raise ValueError(f"Could not locate row matching {pattern!r}")


def _retention_table(path: str, sheet_name: str) -> pd.DataFrame:
    raw = _read_sheet(path, sheet_name)
    header_row = _find_row_containing(raw, r"# of cycle")
    label_row = header_row - 1
    if label_row < 0:
        raise ValueError(f"Could not locate material label row in {sheet_name!r}")
    cycle_col = next(
        (int(col) for col, value in raw.iloc[header_row].items() if "# of cycle" in _clean_label(value).lower()),
        None,
    )
    if cycle_col is None:
        raise ValueError(f"Could not locate cycle column in {sheet_name!r}")
    labels = [_clean_label(v) for v in raw.iloc[label_row, cycle_col + 1 :].tolist()]
    labels = [v for v in labels if v and v != "nan"]
    data = raw.iloc[header_row + 1 :, cycle_col + 1 : cycle_col + 1 + len(labels)].copy()
    data.columns = labels
    data.insert(0, "cycle", pd.to_numeric(raw.iloc[header_row + 1 :, cycle_col], errors="coerce").values)
    for col in data.columns[1:]:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    return data.dropna(subset=["cycle"]).reset_index(drop=True)


def _factor_table(path: str, sheet_name: str) -> pd.DataFrame:
    raw = _read_sheet(path, sheet_name)
    header_row = _find_row_containing(raw, r"surface reaction")
    header = [_clean_label(v) for v in raw.iloc[header_row].tolist()]
    start_col = next((i for i, value in enumerate(header) if "content" in value.lower() or "pressure" in value.lower()), None)
    if start_col is None:
        start_col = next((i for i, value in enumerate(header) if value and value != "nan"), None)
    if start_col is None:
        raise ValueError(f"Could not locate factor-table first column in {sheet_name!r}")
    factor_labels = header[start_col : start_col + 5]
    first = factor_labels[0].lower()
    first_col = "operating_pressure_mpa" if "pressure" in first else "ni_content_mol_pct"
    df = raw.iloc[header_row + 1 :, start_col : start_col + 5].copy()
    df.columns = [first_col, "surface_reaction", "isolation", "detachment", "sum"]
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df.dropna().reset_index(drop=True)


def _require_column(df: pd.DataFrame, column: str, sheet_name: str) -> None:
    if column not in df.columns:
        raise ValueError(f"Column {column!r} not found in {sheet_name!r}; available columns: {list(df.columns)!r}")


def cycling_retention_summary(path: str, sheet_name: str = "Fig. 2a", cycle: int = 100) -> dict:
    df = _retention_table(path, sheet_name)
    nearest = df.iloc[(df["cycle"] - cycle).abs().argsort()[:1]]
    row = nearest.iloc[0]
    return {
        "sheet_name": sheet_name,
        "target_cycle": int(cycle),
        "nearest_cycle": int(row["cycle"]),
        "retention_percent": {k: float(v) for k, v in row.drop(labels=["cycle"]).to_dict().items()},
    }


def modification_gain_summary(path_ni80: str, path_ni95: str, cycle: int = 100) -> dict:
    a = cycling_retention_summary(path_ni80, "Fig. 2a", cycle)
    b = cycling_retention_summary(path_ni95, "Fig. 4a", cycle)
    return {
        "ni80_sm_minus_p": float(a["retention_percent"]["SM-Ni80"] - a["retention_percent"]["P-Ni80"]),
        "ni95_sm_minus_p": float(b["retention_percent"]["SM-Ni95"] - b["retention_percent"]["P-Ni95"]),
        "ni95_sm_minus_sm50": float(b["retention_percent"]["SM-Ni95"] - b["retention_percent"]["SM-Ni50"]),
    }


def fading_factor_summary(path: str, sheet_name: str = "Fig. 4b") -> dict:
    df = _factor_table(path, sheet_name)
    return {
        "sheet_name": sheet_name,
        "factor_fields": ["surface_reaction", "isolation", "detachment"],
        "rows": df.to_dict("records"),
        "largest_total_fading_ni_content": int(df.loc[df["sum"].idxmax(), "ni_content_mol_pct"]),
        "largest_total_fading_value": float(df["sum"].max()),
    }


def pressure_sensitivity_summary(path: str, material: str | None = None, cycle: int = 100, materials: list[str] | None = None) -> dict:
    if materials is None:
        materials = ["P-Ni90", "S-Ni90", "SM-Ni90", "SM-Ni50"]
    summaries = {}
    selected = {}
    mapping = {
        "20 MPa": "Fig. 6a",
        "70 MPa": "Fig. 6b",
        "120 MPa": "Fig. 6c",
    }
    for pressure, sheet in mapping.items():
        df = _retention_table(path, sheet)
        for column in materials:
            _require_column(df, column, sheet)
        row = df.iloc[(df["cycle"] - cycle).abs().argsort()[:1]].iloc[0]
        summaries[pressure] = {column: float(row[column]) for column in materials}
        if material is not None:
            _require_column(df, material, sheet)
            selected[pressure] = float(row[material])
    factor = _factor_table(path, "Fig. 6d")
    return {
        "source_figure": "Supplementary Fig. 19",
        "workbook_sheet_map": mapping,
        "sheet_names_are_workbook_labels": True,
        "factor_sheet": "Fig. 6d",
        "materials": materials,
        "target_cycle": cycle,
        "retention_by_pressure": summaries,
        "selected_material": material,
        "selected_material_retention_by_pressure": selected,
        "fading_factors_by_pressure": factor.to_dict("records"),
        "lowest_total_fading_pressure_mpa": int(factor.loc[factor["sum"].idxmin(), "operating_pressure_mpa"]),
    }


def plot_cycling_comparison(
    path: str,
    sheet_name: str = "Fig. 2a",
    output_filename: str = "cycling_comparison.png",
) -> dict:
    df = _retention_table(path, sheet_name)
    output_path = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for col in df.columns[1:]:
        ax.plot(df["cycle"], df[col], label=col)
    ax.set_xlabel("Cycle")
    ax.set_ylabel("Capacity retention (%)")
    ax.set_title(f"Cycling performance: {sheet_name}")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)
    return {"path": str(output_path), "series": list(df.columns[1:])}


def plot_pressure_effect(
    path: str,
    materials: list[str] | None = None,
    output_filename: str = "pressure_effect.png",
) -> dict:
    if materials is None:
        materials = ["P-Ni90", "S-Ni90", "SM-Ni90", "SM-Ni50"]
    mapping = {"20 MPa": "Fig. 6a", "70 MPa": "Fig. 6b", "120 MPa": "Fig. 6c"}
    output_path = _artifact_path(output_filename)
    fig, axes = plt.subplots(1, 3, figsize=(12, 4.2), sharey=True)
    rows = []
    for ax, (label, sheet) in zip(axes, mapping.items()):
        df = _retention_table(path, sheet)
        for material in materials:
            _require_column(df, material, sheet)
            ax.plot(df["cycle"], df[material], label=material, linewidth=1.8)
            rows.append({"pressure": label, "material": material, "final_retention": float(df[material].iloc[-1])})
        ax.set_title(label)
        ax.set_xlabel("Cycle")
        ax.grid(alpha=0.2)
    axes[0].set_ylabel("Capacity retention (%)")
    axes[-1].legend(fontsize=8, frameon=False, loc="lower left")
    fig.suptitle("Supplementary Fig. 19 pressure dependence")
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)
    return {
        "path": str(output_path),
        "source_figure": "Supplementary Fig. 19",
        "workbook_sheet_map": mapping,
        "sheet_names_are_workbook_labels": True,
        "materials": materials,
        "rows": rows,
    }


def plot_fading_factor_decomposition(
    path: str,
    sheet_name: str = "Fig. 4b",
    output_filename: str = "fading_factor_decomposition.png",
) -> dict:
    df = _factor_table(path, sheet_name)
    output_path = _artifact_path(output_filename)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    bottom = np.zeros(len(df))
    for col, color in [
        ("surface_reaction", "#4C78A8"),
        ("isolation", "#F58518"),
        ("detachment", "#54A24B"),
    ]:
        ax.bar(df["ni_content_mol_pct"].astype(int).astype(str), df[col], bottom=bottom, label=col, color=color)
        bottom += df[col].to_numpy(dtype=float)
    ax.set_xlabel("Ni content (mol %)")
    ax.set_ylabel("Extent of capacity fading")
    ax.set_title("Capacity-fading contributions across Ni content")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)
    return {"path": str(output_path), "rows": df.to_dict("records")}
