Core energy workflow tools for `energy_c4e1`.

- `data_processing.py`: generic file listing and text helpers.
- `database_retrieval.py`: local inventory and PDF-text helpers.
- `energy_tools.py`: geometry-aware thermoelectric performance summaries, FEM response-surface peak analysis, experimental validation contrasts, and artifact generation from released source-data tables.

The task does not require executing the original COMSOL project; it reproduces the public Python-feasible response-surface and validation workflow exposed by the released source data.
