from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd


def _load_fig1c(path: str) -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name="Fig.1c", header=[0, 1])
    df.columns = [
        "temperature_k",
        "cuboid_sim",
        "cuboid_meas",
        "hourglass_sim",
        "hourglass_meas",
        "trunc_sim",
        "trunc_meas",
        "rev_trunc_sim",
        "rev_trunc_meas",
        "y_sim",
        "y_meas",
        "rev_y_sim",
        "rev_y_meas",
        "inv_hourglass_sim",
        "inv_hourglass_meas",
        "multi_hollow_sim",
        "multi_hollow_meas",
    ]
    return df.dropna(subset=["temperature_k"]).copy()


def _load_fig2_sheet(path: str, sheet_name: str = "Fig. 2b") -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name=sheet_name)
    df = df.rename(columns={"Hot_h": "hot_h", "Cold_h": "cold_h"})
    geometry_columns = [c for c in df.columns if c not in {"hot_h", "cold_h"}]
    for col in ["hot_h", "cold_h", *geometry_columns]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df.dropna(subset=["hot_h", "cold_h"]).reset_index(drop=True)


def geometry_power_summary(fig1_path: str) -> dict:
    df = _load_fig1c(fig1_path)
    peak_row = df.loc[df["hourglass_meas"].idxmax()]
    return {
        "temperatures_k": df["temperature_k"].tolist(),
        "peak_hourglass_power_mw": float(df["hourglass_meas"].max()),
        "peak_temperature_k": float(peak_row["temperature_k"]),
        "peak_cuboid_power_mw": float(df["cuboid_meas"].max()),
        "mean_hourglass_to_cuboid_ratio": float((df["hourglass_meas"] / df["cuboid_meas"]).mean()),
        "mean_multi_hollow_to_cuboid_ratio": float((df["multi_hollow_meas"] / df["cuboid_meas"]).mean()),
    }


def geometry_response_surface_summary(fig2_path: str, sheet_name: str = "Fig. 2e") -> dict:
    df = _load_fig2_sheet(fig2_path, sheet_name)
    geometry_columns = [c for c in df.columns if c not in {"hot_h", "cold_h"}]
    peaks = {}
    for col in geometry_columns:
        row = df.loc[df[col].idxmax()]
        peaks[col] = {
            "max_relative_value": float(row[col]),
            "hot_h_at_max": float(row["hot_h"]),
            "cold_h_at_max": float(row["cold_h"]),
            "mean_relative_value": float(df[col].mean()),
        }
    return {
        "sheet_name": sheet_name,
        "response_quantity": "relative_output_power" if sheet_name == "Fig. 2e" else "relative_fem_response",
        "rows": int(len(df)),
        "geometries": geometry_columns,
        "peaks": peaks,
        "best_mean_geometry": max(peaks, key=lambda k: peaks[k]["mean_relative_value"]),
    }


def optimization_surface_peak(fig3_path: str) -> dict:
    df = pd.read_excel(fig3_path, sheet_name="Fig. 3b, c")
    row = df.loc[df["Power [mW]"].idxmax()]
    return {
        "rows": int(len(df)),
        "max_power_mw": float(row["Power [mW]"]),
        "best_height_ratio": float(row["h ratio (upper/bot)"]),
        "best_area_ratio": float(row["area_ratio (outer)/(inner)"]),
    }


def efficiency_gain_summary(fig6_path: str) -> dict:
    df = pd.read_excel(fig6_path, sheet_name="Fig. 6i", header=[0, 1])
    df.columns = [
        "temperature_k",
        "cuboid_sim",
        "cuboid_meas",
        "hourglass_sim",
        "hourglass_meas",
        "trunc_sim",
        "trunc_meas",
        "rev_trunc_sim",
        "rev_trunc_meas",
        "y_sim",
        "y_meas",
        "rev_y_sim",
        "rev_y_meas",
        "inv_hourglass_sim",
        "inv_hourglass_meas",
        "multi_hollow_sim",
        "multi_hollow_meas",
    ]
    df = df.dropna(subset=["temperature_k"]).copy()
    return {
        "peak_hourglass_efficiency": float(df["hourglass_meas"].max()),
        "peak_cuboid_efficiency": float(df["cuboid_meas"].max()),
        "mean_hourglass_gain": float((df["hourglass_meas"] - df["cuboid_meas"]).mean()),
        "mean_multi_hollow_gain": float((df["multi_hollow_meas"] - df["cuboid_meas"]).mean()),
    }


def plot_geometry_power(fig2_path: str, output_path: str, geometry: str = "hourglass", sheet_name: str = "Fig. 2e") -> dict:
    df = _load_fig2_sheet(fig2_path, sheet_name)
    pivot = df.pivot_table(index="hot_h", columns="cold_h", values=geometry, aggfunc="mean")
    plt.figure(figsize=(7, 5))
    plt.imshow(pivot.values, origin="lower", aspect="auto", cmap="magma")
    plt.xticks(range(len(pivot.columns)), [f"{v:g}" for v in pivot.columns], rotation=90)
    plt.yticks(range(len(pivot.index)), [f"{v:g}" for v in pivot.index])
    plt.xlabel("Cold-side convection coefficient h")
    plt.ylabel("Hot-side convection coefficient h")
    plt.title(f"{sheet_name}: relative {geometry} output power")
    cbar = plt.colorbar()
    cbar.set_label("Relative output power vs cuboid")
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), "geometry": geometry, "sheet_name": sheet_name, "response_quantity": "relative_output_power"}


def plot_optimization_heatmap(fig3_path: str, output_path: str) -> dict:
    df = pd.read_excel(fig3_path, sheet_name="Fig. 3b, c")
    pivot = df.pivot_table(
        index="h ratio (upper/bot)",
        columns="area_ratio (outer)/(inner)",
        values="Power [mW]",
        aggfunc="mean",
    )
    plt.figure(figsize=(7, 5))
    plt.imshow(pivot.values, origin="lower", aspect="auto", cmap="viridis")
    plt.xticks(range(len(pivot.columns)), [f"{x:.2f}" for x in pivot.columns], rotation=90)
    plt.yticks(range(len(pivot.index)), [f"{x:.2f}" for x in pivot.index])
    plt.xlabel("Outer/inner area ratio")
    plt.ylabel("Upper/bottom height ratio")
    plt.title("Released optimization surface for thermoelectric power")
    cbar = plt.colorbar()
    cbar.set_label("Power (mW)")
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out)}
def plot_efficiency_gain(fig6_path: str, output_path: str) -> dict:
    df = pd.read_excel(fig6_path, sheet_name="Fig. 6i", header=[0, 1])
    df.columns = [
        "temperature_k",
        "cuboid_sim",
        "cuboid_meas",
        "hourglass_sim",
        "hourglass_meas",
        "trunc_sim",
        "trunc_meas",
        "rev_trunc_sim",
        "rev_trunc_meas",
        "y_sim",
        "y_meas",
        "rev_y_sim",
        "rev_y_meas",
        "inv_hourglass_sim",
        "inv_hourglass_meas",
        "multi_hollow_sim",
        "multi_hollow_meas",
    ]
    df = df.dropna(subset=["temperature_k"]).copy()
    plt.figure(figsize=(7, 4.5))
    for label, col in [
        ("Cuboid", "cuboid_meas"),
        ("Hourglass", "hourglass_meas"),
        ("Truncated pyramid", "trunc_meas"),
        ("Multi hollow rectangle", "multi_hollow_meas"),
    ]:
        plt.plot(df["temperature_k"], df[col], marker="o", label=label)
    plt.xlabel("Hot-side temperature (K)")
    plt.ylabel("Efficiency (%)")
    plt.title("Fig. 6i measured efficiency validation")
    plt.legend(frameon=False, fontsize=8)
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), "series": ["cuboid_meas", "hourglass_meas", "trunc_meas", "multi_hollow_meas"]}
