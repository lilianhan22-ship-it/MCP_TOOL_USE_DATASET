import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import random

random.seed(10)

plt.rc('font', family='Arial', size=12)

ColorArr = ['lightcoral', 'brown', 'firebrick', 'maroon', 'mistyrose', 'orange', 'gold', 'bisque', 'tan', 'olive', 'yellowgreen', 'lightgreen', 'crimson',
                'aquamarine', 'lightseagreen', 'teal', 'slategrey', 'royalblue', 'navy', 'blue', 'darkviolet', 'plum', 'grey', 'indigo', 'steelblue', 'pink']


random1 = random.sample(ColorArr, 26)
random2 = random.sample(ColorArr, 12)
def ReadTrafficVolumeDataByMonth():
    df = pd.ExcelFile('monthly_ship.xlsx', header=0)
    TrafficVolumeData = np.zeros((12, 34))
    print(TrafficVolumeData.shape)
    for t in range(12):
        TrafficVolumeData[t] = df.parse('Sheet1')['month_%s'%(t+1)].values
    print('TrafficVolumeData:', TrafficVolumeData)
    headers = df.columns.tolist()
    print('headers:', headers)

    return TrafficVolumeData,headers

def ReadTrafficVolumeDataByRoute():

    df = pd.ExcelFile('monthly_ship.xlsx')
    TrafficVolumeData = np.zeros((34, 12))
    print(TrafficVolumeData.shape)
    df1 = pd.read_excel('monthly_ship.xlsx')
    headers = df1.columns.tolist()
    print('headers:', headers)
    for t in range(34):
        TrafficVolumeData[t] = df.parse('Sheet1')[headers[t]].values
    print('TrafficVolumeData:', TrafficVolumeData)


    return TrafficVolumeData,headers


def TrafficVolumeByMonth():
    TrafficVolumeData = ReadTrafficVolumeDataByMonth()


    fig = plt.figure(figsize=(20, 12))

    TitleSet = [['Jan', 'Feb', 'Mar', 'Apr'],
                ['May', 'Jun', 'Jul', 'Aug'],
                ['Sep', 'Oct', 'Nov', 'Dec']]

    for i in range(3):
        for j in range(4):
            ax = fig.add_subplot(3, 4, i * 4 + j+1)
            X = np.linspace(1,26,26)
            Y = TrafficVolumeData[i * 4 + j]
            ax.bar(X,Y, color=random1)
            ax.set_title(TitleSet[i][j], y= 0.9)
            ax.set_xlabel('Route')
            ax.set_ylabel('Traffic Volume (trips/month)')
            # ax.set_xticks(range(1,27,1), fontsize=8)
    plt.tight_layout()
    plt.savefig('./TrafficVolumePlotByMonth.png', transparent=True, dpi=600)
    plt.show()

def TrafficVolumeByRoute():
    TrafficVolumeData, headers = ReadTrafficVolumeDataByRoute()

    ColorArr = ['lightcoral', 'brown', 'firebrick', 'maroon', 'mistyrose', 'orange', 'gold', 'bisque', 'tan', 'olive', 'yellowgreen', 'lightgreen', 'crimson',
                'aquamarine', 'lightseagreen', 'teal', 'slategrey', 'royalblue', 'navy', 'blue', 'darkviolet', 'plum', 'grey', 'indigo', 'steelblue', 'pink']
    fig = plt.figure(figsize=(20, 20))

    CourseName = ['Rotterdam-Antwerp', 'Felixstowe-Rotterdam', 'Cristobal-Buenaventura', 'Hamburg-Antwerp',
                  'Shanghai-Busan', 'Basrah-Fujairah', 'Shanghai-Hongkong', 'CapeTown-Durban',
                  'Shanghai-Nagoya', 'Santos-BuenosAries', 'Shanghai-Yokohama', 'Qingdao-Nagoya', 'NewYork-Panama',
                  'NewYork-Panama', 'Ningbo-Singapore', 'Shanghai-Singapore', 'Suez-Rotterdam',
                  'Hedland-Jingtang', 'Santos-Elizabeth', 'Durban-Fujairah', 'Melbourne-Singapore', 'Vancouver-Panama',
                  'Singapore-Durban', 'Singapore-Suez', 'Shanghai-LosAngles', 'Rotterdam-CapeTown']

    for i in range(6):
        for j in range(6):
            if i*6 + j + 1 <= 34:
                ax = fig.add_subplot(6, 6, i * 6 + j+1)
                X = np.linspace(1,12,12)
                Y = TrafficVolumeData[i * 6 + j]
                ax.bar(X,Y, color=random1[random.randint(0,25)])
                ax.set_title(headers[i * 6 + j])
                ax.set_xlabel('Month')
                ax.set_xticks(range(1, 13, 1), fontsize=8)
                ax.set_ylabel('Traffic Volume (trips/month)')
                if max(Y) <= 50:
                    ax.set_ylim(0, 50)
                elif max(Y) <=200:
                    ax.set_ylim(0, 200)
                else:
                    ax.set_ylim(0, 400)


    plt.tight_layout()
    plt.savefig('./TrafficVolumePlotByRoute.pdf', transparent=True, dpi=600)
    plt.show()

# TrafficVolumeByMonth()
TrafficVolumeByRoute()