clear all;clc;

path='Fig.S4.xlsx';%Replace with the path where the Fig.S4.xlsx is located
[dataNum,dataStr]=xlsread(path);

figure(1);
for i=1:1:5
    name(i)=dataStr(2,2*(i-1)+1);
    wind_temp=dataNum(4:end,2*(i-1)+1);
    pv_temp=dataNum(4:end,2*(i-1)+2);

    for j=1:1:length(wind_temp)
        if isnan(wind_temp(j)) == 0
            wind(j)=wind_temp(j);
            pv(j)=pv_temp(j);
        end
    end
    x=0:100/(length(wind)-1):100;
    plot(x,wind,'LineWidth',3);hold on;
    plot(x,pv,'--','LineWidth',3);hold on;
    xlim([0,100]);ylim([0,max(max(dataNum))+500]);
    %legend([char(name)+"+Wind",char(name)+"+PV"]);hold on;
    %legend('Wind','PV');hold on;
    clear("wind");clear("pv");
end
leng=strings(1,2*5);
for k=1:1:5
    leng(2*k-1)=string(name(k))+"+Wind";
    leng(2*k)=string(name(k))+"+PV";
end
legend([leng]);
clear leng;
xlabel("Ship Route(%)");ylabel("Annual Utilization Hours(h)");
title("Wind and Solar Endowment in American's Major Shipping Lanes")


figure(2);
for i=6:1:10
    name(i)=dataStr(2,2*(i-1)+1);
    wind_temp=dataNum(4:end,2*(i-1)+1);
    pv_temp=dataNum(4:end,2*(i-1)+2);

    for j=1:1:length(wind_temp)
        if isnan(wind_temp(j)) == 0
            wind(j)=wind_temp(j);
            pv(j)=pv_temp(j);
        end
    end
    x=0:100/(length(wind)-1):100;
    plot(x,wind,'LineWidth',3);hold on;
    plot(x,pv,'--','LineWidth',3);hold on;
    xlim([0,100]);ylim([0,max(max(dataNum))+500]);
    %legend([char(name)+"+Wind",char(name)+"+PV"]);hold on;
    %legend('Wind','PV');hold on;
    clear("wind");clear("pv");
end
leng=strings(1,2*5);
for k=6:1:10
    leng(2*(k-5)-1)=string(name(k))+"+Wind";
    leng(2*(k-5))=string(name(k))+"+PV";
end
legend([leng]);
clear leng;
xlabel("Ship Route(%)");ylabel("Annual Utilization Hours(h)");
title("Wind and Solar Endowment in Asia-Pacific's Major Shipping Lanes")

figure(3);
for i=11:1:13
    name(i)=dataStr(2,2*(i-1)+1);
    wind_temp=dataNum(4:end,2*(i-1)+1);
    pv_temp=dataNum(4:end,2*(i-1)+2);

    for j=1:1:length(wind_temp)
        if isnan(wind_temp(j)) == 0
            wind(j)=wind_temp(j);
            pv(j)=pv_temp(j);
        end
    end
    x=0:100/(length(wind)-1):100;
    plot(x,wind,'LineWidth',3);hold on;
    plot(x,pv,'--','LineWidth',3);hold on;
    xlim([0,100]);ylim([0,max(max(dataNum))+500]);
    %legend([char(name)+"+Wind",char(name)+"+PV"]);hold on;
    %legend('Wind','PV');hold on;
    clear("wind");clear("pv");
end
leng=strings(1,2*5);
for k=11:1:13
    leng(2*(k-10)-1)=string(name(k))+"+Wind";
    leng(2*(k-10))=string(name(k))+"+PV";
end
legend([leng]);
clear leng;
xlabel("Ship Route(%)");ylabel("Annual Utilization Hours(h)");
title("Wind and Solar Endowment in Cape Town's Major Shipping Lanes")

figure(4);
for i=14:1:18
    name(i)=dataStr(2,2*(i-1)+1);
    wind_temp=dataNum(4:end,2*(i-1)+1);
    pv_temp=dataNum(4:end,2*(i-1)+2);

    for j=1:1:length(wind_temp)
        if isnan(wind_temp(j)) == 0
            wind(j)=wind_temp(j);
            pv(j)=pv_temp(j);
        end
    end
    x=0:100/(length(wind)-1):100;
    plot(x,wind,'LineWidth',3);hold on;
    plot(x,pv,'--','LineWidth',3);hold on;
    xlim([0,100]);ylim([0,max(max(dataNum))+500]);
    %legend([char(name)+"+Wind",char(name)+"+PV"]);hold on;
    %legend('Wind','PV');hold on;
    clear("wind");clear("pv");
end
leng=strings(1,2*5);
for k=14:1:18
    leng(2*(k-13)-1)=string(name(k))+"+Wind";
    leng(2*(k-13))=string(name(k))+"+PV";
end
legend([leng]);
clear leng;
xlabel("Ship Route(%)");ylabel("Annual Utilization Hours(h)");
title("Wind and Solar Endowment in East Asia's Major Shipping Lanes")

figure(5);
for i=19:1:22
    name(i)=dataStr(2,2*(i-1)+1);
    wind_temp=dataNum(4:end,2*(i-1)+1);
    pv_temp=dataNum(4:end,2*(i-1)+2);

    for j=1:1:length(wind_temp)
        if isnan(wind_temp(j)) == 0
            wind(j)=wind_temp(j);
            pv(j)=pv_temp(j);
        end
    end
    x=0:100/(length(wind)-1):100;
    plot(x,wind,'LineWidth',3);hold on;
    plot(x,pv,'--','LineWidth',3);hold on;
    xlim([0,100]);ylim([0,max(max(dataNum))+500]);
    %legend([char(name)+"+Wind",char(name)+"+PV"]);hold on;
    %legend('Wind','PV');hold on;
    clear("wind");clear("pv");
end
leng=strings(1,2*5);
for k=19:1:22
    leng(2*(k-18)-1)=string(name(k))+"+Wind";
    leng(2*(k-18))=string(name(k))+"+PV";
end
legend([leng]);
clear leng;
xlabel("Ship Route(%)");ylabel("Annual Utilization Hours(h)");
title("Wind and Solar Endowment in India Ocean's Major Shipping Lanes")

figure(6);
for i=23:1:26
    name(i)=dataStr(2,2*(i-1)+1);
    wind_temp=dataNum(4:end,2*(i-1)+1);
    pv_temp=dataNum(4:end,2*(i-1)+2);

    for j=1:1:length(wind_temp)
        if isnan(wind_temp(j)) == 0
            wind(j)=wind_temp(j);
            pv(j)=pv_temp(j);
        end
    end
    x=0:100/(length(wind)-1):100;
    plot(x,wind,'LineWidth',3);hold on;
    plot(x,pv,'--','LineWidth',3);hold on;
    xlim([0,100]);ylim([0,max(max(dataNum))+500]);
    %legend([char(name)+"+Wind",char(name)+"+PV"]);hold on;
    %legend('Wind','PV');hold on;
    clear("wind");clear("pv");
end
leng=strings(1,2*5);
for k=23:1:26
    leng(2*(k-22)-1)=string(name(k))+"+Wind";
    leng(2*(k-22))=string(name(k))+"+PV";
end
legend([leng]);
clear leng;
xlabel("Ship Route(%)");ylabel("Annual Utilization Hours(h)");
title("Wind and Solar Endowment in West Europe's Major Shipping Lanes")