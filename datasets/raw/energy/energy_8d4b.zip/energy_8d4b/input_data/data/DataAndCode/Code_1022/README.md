  <h3 align="center">Data and Codes in support of "Accelerating Green Shipping by Spatially Optimized Offshore Charging Stations"</h3>





<details>
  <summary>Table of Contents</summary>
  <ol>
    <li>
      <a href="#about-the-project">About The Project</a>
    <li>
      <a href="#Repo Contents">Repo Contents</a>
    <li>
      <a href="#System Requirements">System Requirements</a>
      <ul>
        <li><a href="#Hardware Requirements">Hardware Requirements</a></li>
        <li><a href="#Software Requirements">Software Requirements</a></li>
      </ul>
    </li>
    <li><a href="#Citation">Citation</a></li>
  </ol>
</details>



## About The Project

The repository contains data and codes to replicate the figures in the manuscript  "Accelerating Green Shipping by Spatially Optimized Offshore Charging Stations" and its supplementary information documentation. Users is recommended to use popular python IDE(such as Pycharm) , Matlab R2021a or above to run the codes.

<p align="right">(<a href="#readme-top">back to top</a>)</p>



## Repo Contents

This is an example of how you may give instructions on setting up your project locally.
To get a local copy up and running follow these simple example steps.

- [.py](./Python): `Python` package code.
- [.xlsx](./Excel File): data and graph processed in excel.
- [.m](./Matlab): Matlab codes.
- [.png](./png): figure files output from the codes.
- [.pdf](./pdf): : figure files output from the codes.

<p align="right">(<a href="#readme-top">back to top</a>)</p>



## System Requirements

### Hardware Requirements

The code is tested on a standard computer with 16GB RAM and AMD Ryzen 7 PRO 4750U CPU. For smooth performance, we recommend a computer with the following specs:

- RAM: 8GB

- CPU: 4+ cores, 1.7+ GHz



### Software Requirements

The codes are tested on Windows operating systems. 

Before setting up the code packages, users should have python development environement, such as Pycharm, Visual Studio, Spyder and so on. To run the .m files, user should have Matlab environment. we recommend software versions of the IDE as follows:

- Matlab: R2021a or above.

- Python: 3.7 or above.

Several 3rd party tools for python should be installed to run the .py codes, we test the codes with the following settings:

- numpy: 1.20.1

- matplotlib: 3.5.1

- pandas: 1.4.2

- openpyxl: 3.0.10

To run the .py files, uses just have to open the files with prefered python IDE and run the codes to get the results. to run the .m files, users have to open the files with Matlab, add the path of the files to the envrionment, and run the code, or set the path of the file as default path manually in the Matlab IDE.



## Citation

H. L, Data and codes in support of “Accelerating Green Shipping by Spatially Optimized Offshore Charging Stations”. Zenodo (2024). doi: [10.5281/zenodo.13985434](https://doi.org/10.5281/zenodo.13309957)



<p align="right">(<a href="#readme-top">back to top</a>)</p>

