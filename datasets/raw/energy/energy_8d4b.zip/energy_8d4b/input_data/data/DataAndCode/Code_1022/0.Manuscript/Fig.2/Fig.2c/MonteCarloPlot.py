
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mps
import matplotlib as mpl
import pandas as pd
import random


mpl.rcParams['font.family'] = 'Arial'
mpl.rcParams['font.size'] = 12

def adjacent_values(vals, q1, q3):
    upper_adjacent_value = q3 + (q3 - q1) * 1.5
    upper_adjacent_value = np.clip(upper_adjacent_value, q3, vals[-1])

    lower_adjacent_value = q1 - (q3 - q1) * 1.5
    lower_adjacent_value = np.clip(lower_adjacent_value, vals[0], q1)
    return lower_adjacent_value, upper_adjacent_value

def set_axis_style(ax, labels):
    ax.set_xticks(np.arange(1, len(labels)+1), labels=labels, )
    ax.set_xlim(0.25, len(labels) + 0.75)
    ax.tick_params(axis='x', rotation=15)

def PLotSensitivityAnalysis():

    NumofCourses = 7
    np.random.seed(4)
    Data_Hamburg_Antwerp = pd.read_excel('./TotalCost.xlsx', sheet_name='Hamburg_Antwerp_2050')
    TotalCost_ESwithOCP_Hamburg_Antwerp = Data_Hamburg_Antwerp.iloc[:, 0].values[:200]
    TotalCost_ES_Hamburg_Antwerp = Data_Hamburg_Antwerp.iloc[:, 1].values[:200]
    TotalCost_HFO_Hamburg_Antwerp = Data_Hamburg_Antwerp.iloc[:, 2].values[:200]

    Data_Shanghai_Busan = pd.read_excel('./TotalCost.xlsx', sheet_name='Shanghai_Busan_2050')
    TotalCost_ESwithOCP_Shanghai_Busan = Data_Shanghai_Busan.iloc[:, 0].values[:200]
    TotalCost_ES_Shanghai_Busan = Data_Shanghai_Busan.iloc[:, 1].values[:200]
    TotalCost_HFO_Shanghai_Busan = Data_Shanghai_Busan.iloc[:, 2].values[:200]

    Data_Basrah_Fujairah = pd.read_excel('./TotalCost.xlsx', sheet_name='Basrah_Fujairah_2050')
    TotalCost_ESwithOCP_Basrah_Fujairah = Data_Basrah_Fujairah.iloc[:, 0].values[:200]
    TotalCost_ES_Basrah_Fujairah = Data_Basrah_Fujairah.iloc[:, 1].values[:200]
    TotalCost_HFO_Basrah_Fujairah = Data_Basrah_Fujairah.iloc[:, 2].values[:200]

    Data_Ningbo_Singapore = pd.read_excel('./TotalCost.xlsx', sheet_name='Ningbo_Singapore_2050')
    TotalCost_ESwithOCP_Ningbo_Singapore = Data_Ningbo_Singapore.iloc[:, 0].values[:200]
    TotalCost_ES_Ningbo_Singapore = Data_Ningbo_Singapore.iloc[:, 1].values[:200]
    TotalCost_HFO_Ningbo_Singapore = Data_Ningbo_Singapore.iloc[:, 2].values[:200]

    Data_Panama_Houston = pd.read_excel('./TotalCost.xlsx', sheet_name='Panama_Houston_2050')
    TotalCost_ESwithOCP_Panama_Houston = Data_Panama_Houston.iloc[:, 0].values[:200]
    TotalCost_ES_Panama_Houston = Data_Panama_Houston.iloc[:, 1].values[:200]
    TotalCost_HFO_Panama_Houston = Data_Panama_Houston.iloc[:, 2].values[:200]

    Data_Melbourne_Singapore = pd.read_excel('./TotalCost.xlsx', sheet_name='Melbourne_Singapore_2050')
    TotalCost_ESwithOCP_Melbourne_Singapore = Data_Melbourne_Singapore.iloc[:, 0].values[:200]
    TotalCost_ES_Melbourne_Singapore = Data_Melbourne_Singapore.iloc[:, 1].values[:200]
    TotalCost_HFO_Melbourne_Singapore = Data_Melbourne_Singapore.iloc[:, 2].values[:200]

    Data_Singapore_Suez = pd.read_excel('./TotalCost.xlsx', sheet_name='Singapore_Suez_2050')
    TotalCost_ESwithOCP_Singapore_Suez  = Data_Singapore_Suez.iloc[:, 0].values[:200]
    TotalCost_ES_Singapore_Suez  = Data_Singapore_Suez.iloc[:, 1].values[:200]
    TotalCost_HFO_Singapore_Suez  = Data_Singapore_Suez.iloc[:, 2].values[:200]

    fig = plt.figure('Violin example', figsize=(8, 8))
    ax = fig.add_subplot()
    data_Hamburg_Antwerp = [TotalCost_ESwithOCP_Hamburg_Antwerp, TotalCost_ES_Hamburg_Antwerp, TotalCost_HFO_Hamburg_Antwerp]
    data_Shanghai_Busan = [TotalCost_ESwithOCP_Shanghai_Busan, TotalCost_ES_Shanghai_Busan, TotalCost_HFO_Shanghai_Busan ]
    data_Ningbo_Singapore = [TotalCost_ESwithOCP_Ningbo_Singapore, TotalCost_ES_Ningbo_Singapore, TotalCost_HFO_Ningbo_Singapore ]
    data_Panama_Houston = [TotalCost_ESwithOCP_Panama_Houston, TotalCost_ES_Panama_Houston, TotalCost_HFO_Panama_Houston ]
    data_Basrah_Fujairah = [TotalCost_ESwithOCP_Basrah_Fujairah, TotalCost_ES_Basrah_Fujairah, TotalCost_HFO_Basrah_Fujairah ]
    data_Melbourne_Singapore = [TotalCost_ESwithOCP_Melbourne_Singapore, TotalCost_ES_Melbourne_Singapore, TotalCost_HFO_Melbourne_Singapore ]
    data_Singapore_Suez = [TotalCost_ESwithOCP_Singapore_Suez , TotalCost_ES_Singapore_Suez , TotalCost_HFO_Singapore_Suez  ]
    SingleCourse1 = ax.violinplot(data_Hamburg_Antwerp, positions=[1, 1, 1], showmeans=False, showmedians=False,showextrema=False, bw_method=0.5)
    SingleCourse2 = ax.violinplot(data_Shanghai_Busan, positions=[2, 2, 2], showmeans=False, showmedians=False,showextrema=False, bw_method=0.5)
    SingleCourse3 = ax.violinplot(data_Basrah_Fujairah, positions=[3, 3, 3], showmeans=False, showmedians=False,showextrema=False, bw_method=0.5)
    SingleCourse4 = ax.violinplot(data_Ningbo_Singapore, positions=[4, 4, 4], showmeans=False, showmedians=False,showextrema=False, bw_method=0.5)
    SingleCourse5 = ax.violinplot(data_Panama_Houston, positions=[5, 5, 5], showmeans=False, showmedians=False,showextrema=False, bw_method=0.5)
    SingleCourse6 = ax.violinplot(data_Melbourne_Singapore, positions=[6, 6, 6], showmeans=False, showmedians=False,showextrema=False, bw_method=0.5)
    SingleCourse7 = ax.violinplot(data_Singapore_Suez, positions=[7, 7, 7], showmeans=False, showmedians=False,showextrema=False, bw_method=0.5)


    Courses = [SingleCourse1, SingleCourse2, SingleCourse3, SingleCourse4, SingleCourse5, SingleCourse6, SingleCourse7]
    colors = ['green', 'lightsteelblue', 'orange']

    for i in range(len(Courses)):
        Courses[i]['bodies'][0].set_facecolor(colors[0])
        Courses[i]['bodies'][0].set_edgecolor('darkgreen')
        Courses[i]['bodies'][1].set_facecolor(colors[1])
        Courses[i]['bodies'][1].set_edgecolor('steelblue')
        Courses[i]['bodies'][2].set_facecolor(colors[2])
        Courses[i]['bodies'][2].set_edgecolor('chocolate')


    SingleCourse_patch1 = mps.Patch(color='green', label='ESwithOCP', alpha=0.3)
    SingleCourse_patch2 = mps.Patch(color='lightsteelblue', label='ES', alpha=0.5)
    SingleCourse_patch3 = mps.Patch(color='orange', label='HFO', alpha=0.3)

    ax.grid(axis='y', linestyle='--', color='lightgrey')
    ax.set_ylabel('AvgProposionCost(USD/km)', fontsize=16)

    data = [data_Hamburg_Antwerp, data_Shanghai_Busan, data_Basrah_Fujairah, data_Ningbo_Singapore, data_Panama_Houston, data_Melbourne_Singapore, data_Singapore_Suez]
    for i in range(NumofCourses):
        quartile1, means, quartile3 = np.percentile(data[i], [25, 50, 75], axis=1)
        whiskers = np.array([
            adjacent_values(sorted_array, q1, q3)
            for sorted_array, q1, q3 in zip(data[i], quartile1, quartile3)])
        whiskers_min, whiskers_max = whiskers[:, 0], whiskers[:, 1]

        inds = [i+1,i+1,i+1]
        mean = ax.scatter(inds, means, marker='o', color=colors, s=30, zorder=3)
        ax.vlines(inds, quartile1, quartile3, color='dimgray', linestyle='-', lw=5)
        ax.vlines(inds, whiskers_min, whiskers_max, color='dimgray', linestyle='-', lw=1)


    labels = ['Hamburg-Antwerp', 'Shanghai-Busan', 'Basrah-Fujairah', 'Ningbo-Singapore', 'Panama-Houston', 'Melbourne-Singapore', 'Singapore-Suez']
    set_axis_style(ax, labels)

    TypicalPoint_HamburgAntwerp =  [474.4285929144771, 253.5933651238837, 35.76764727219401, 62.484322923826895, 99.41727784456847, 95.49968651842585, 122.45088935150851, 102.45504540906671, 109.48965425832952, 91.96300090021069]
    TypicalPoint_ShanghaiBusan =  [87.33569992582991, 65.08836363952129, 64.24620243679256, 53.84258347921976, 55.633439307546844, 54.076373571147734, 69.9031409467511, 58.40438886090504, 58.88241830016908, 51.10960294418739]
    TypicalPoint_PanamaHouston =  [130.0144315881198, 81.29276212822198, 78.9096627329229, 62.70281921269527, 72.78072944612917, 71.53957304598784, 122.70912637074895, 78.19757575812737, 86.21496795029401, 65.79800558278988]
    TypicalPoint_BasrahFujairah =  [98.13355680012991, 58.61515075768854, 56.54807546787655, 41.97610616280711, 50.55997119930265, 50.14092095858902, 84.5473648889361, 53.617617013781995, 70.13426737907034, 46.973639906713686]
    TypicalPoint_NingboSingapore =  [186.7382462920149, 106.99698573579369, 124.59400798306446, 88.49909833235314, 98.8747735591613, 96.56308706175611, 180.39610192390825, 104.36643719896813, 130.93615235117124, 91.12964686917871]
    TypicalPoint_SingaporeSuez =  [278.0552265586706, 120.83184493551852, 217.2942254368724, 98.58647052550845, 110.46084968566547, 109.25559103493049, 314.2541159234031, 125.54195084819585, 181.09533607213973, 93.87636461283113]
    TypicalPoint_MelbourneSingapore =  [235.43868970335336, 140.7237294005337, 160.5495389339588, 104.56412917267629, 123.71607538579133, 122.0164520764821, 243.1190231470025, 137.21558711285792, 152.86920549030958, 108.07227146035203]


    TypicalPoint_All = [TypicalPoint_HamburgAntwerp, TypicalPoint_ShanghaiBusan, TypicalPoint_BasrahFujairah, TypicalPoint_NingboSingapore, TypicalPoint_PanamaHouston, TypicalPoint_MelbourneSingapore, TypicalPoint_SingaporeSuez]

    MinMax_HamburgAntwerp = [29.48, 299.96, 15.82, 519.44, 140.66, 211.99] # ESwithOCS_min, ESwithOCS_max, ES_min, ES_max, HFO_min, HFO_max
    MinMax_ShanghaiBusan = [26.73, 93.77, 24.49, 120.35, 84.65, 132.20] # ESwithOCS_min, ESwithOCS_max, ES_min, ES_max, HFO_min, HFO_max
    MinMax_BasrahFujairah = [30.57, 79.97, 42.05, 13392, 106.82, 167.82] # ESwithOCS_min, ESwithOCS_max, ES_min, ES_max, HFO_min, HFO_max
    MinMax_NingboSingapore = [75.41, 141.56, 97.62, 288.39, 102.58, 148.66] # ESwithOCS_min, ESwithOCS_max, ES_min, ES_max, HFO_min, HFO_max
    MinMax_PanamaHouston = [48.94, 113.64, 56.20, 206.75, 74.72, 118.66] # ESwithOCS_min, ESwithOCS_max, ES_min, ES_max, HFO_min, HFO_max
    MinMax_MelbourneSingapore = [90.22, 207.26, 112.44, 424.38, 87.29, 135.91] # ESwithOCS_min, ESwithOCS_max, ES_min, ES_max, HFO_min, HFO_max
    MinMax_SingaporeSuez = [83.67, 186.32, 146.24, 556.46, 112.60, 166.55] # ESwithOCS_min, ESwithOCS_max, ES_min, ES_max, HFO_min, HFO_max

    MinMax_All = [MinMax_HamburgAntwerp, MinMax_ShanghaiBusan, MinMax_BasrahFujairah, MinMax_NingboSingapore, MinMax_PanamaHouston, MinMax_MelbourneSingapore, MinMax_SingaporeSuez]

    random.seed(1)
    for i in range(1, 7):

        ax.plot(i+1, TypicalPoint_All[i][0], marker='D', color='darkblue', markeredgecolor='black')
        ax.plot(i+1, TypicalPoint_All[i][1], marker='D', color='darkgreen', markeredgecolor='black')
        ax.plot(i+1, TypicalPoint_All[i][2], marker='D', color='lightblue', markeredgecolor='black')
        ax.plot(i+1, TypicalPoint_All[i][3], marker='D', color='lightgreen', markeredgecolor='black')
        ax.plot(i+1, TypicalPoint_All[i][4], marker='D', color='firebrick', markeredgecolor='black')
        ax.plot(i+1, TypicalPoint_All[i][4], marker='D', color='lightcoral', markeredgecolor='black')
        ax.plot(i+1, TypicalPoint_All[i][6], marker='D', color='blueviolet', markeredgecolor='black')
        ax.plot(i+1, TypicalPoint_All[i][7], marker='D', color='chocolate', markeredgecolor='black')
        ax.plot(i+1, TypicalPoint_All[i][8], marker='D', color='plum', markeredgecolor='black')
        ax.plot(i+1, TypicalPoint_All[i][9], marker='D', color='peachpuff', markeredgecolor='black')

    ESwithOCS_min, = ax.plot([1-0.125, 1+0.125], [MinMax_All[0][0], MinMax_All[0][0]], color='green', linestyle='dashed', linewidth=1, label='ESwithOCS_min/max')
    ESwithOCS_max, = ax.plot([1-0.125, 1+0.125], [MinMax_All[0][1], MinMax_All[0][1]], color='green', linestyle='dashed', linewidth=1, label='ESwithOCS_max')
    ES_min, = ax.plot([1-0.125, 1+0.125], [MinMax_All[0][2], MinMax_All[0][2]], color='blue', linestyle='dashed', linewidth=1,label='ES_min/max')
    ES_max, = ax.plot([1-0.125, 1+0.125], [MinMax_All[0][3], MinMax_All[0][3]], color='blue', linestyle='dashed', linewidth=1, label='ES_max')
    HFO_min, = ax.plot([1-0.125, 1+0.125], [MinMax_All[0][4], MinMax_All[0][4]], color='orange', linestyle='dashed', linewidth=1, label='HFO_min/max')
    HFO_max, = ax.plot([1-0.125, 1+0.125], [MinMax_All[0][5], MinMax_All[0][5]], color='orange', linestyle='dashed', linewidth=1, label='HFO_max')
    for i in range(1, 7):
        ax.plot([i+1-0.125, i+1+0.125], [MinMax_All[i][0], MinMax_All[i][0]], color='green', linestyle='dashed', linewidth=1, label='ESwithOCS_min')
        ax.plot([i+1-0.125, i+1+0.125], [MinMax_All[i][1], MinMax_All[i][1]], color='green', linestyle='dashed', linewidth=1, label='ESwithOCS_max')
        ax.plot([i+1-0.125, i+1+0.125], [MinMax_All[i][2], MinMax_All[i][2]], color='blue', linestyle='dashed', linewidth=1,label='ES_min')
        ax.plot([i+1-0.125, i+1+0.125], [MinMax_All[i][3], MinMax_All[i][3]], color='blue', linestyle='dashed', linewidth=1, label='ES_max')
        ax.plot([i+1-0.125, i+1+0.125], [MinMax_All[i][4], MinMax_All[i][4]], color='orange', linestyle='dashed', linewidth=1, label='HFO_min')
        ax.plot([i+1-0.125, i+1+0.125], [MinMax_All[i][5], MinMax_All[i][5]], color='orange', linestyle='dashed', linewidth=1, label='HFO_max')
    
    HighElecPrice_ES, = ax.plot(1, TypicalPoint_All[0][0], marker='D', color='darkblue', markeredgecolor='black', label='HighElecPrice_ES')
    HighElecPrice_ESwithOCP, = ax.plot(1, TypicalPoint_All[0][1], marker='D', color='darkgreen', markeredgecolor='black', label='HighElecPrice_ESwithOCP')
    LowElecPrice_ES, = ax.plot(1, TypicalPoint_All[0][2], marker='D', color='lightblue', markeredgecolor='black', label='LowElecPrice_ES')
    LowElecPrice_ESwithOCP, = ax.plot(1, TypicalPoint_All[0][3], marker='D', color='lightgreen', markeredgecolor='black', label='LowElecPrice_ESwithOCP')
    HighGenPrice_ESwithOCP, = ax.plot(1, TypicalPoint_All[0][4], marker='D', color='firebrick', markeredgecolor='black', label='HighGenPrice_ESwithOCP')
    LowGenPrice_ESwithOCP, = ax.plot(1, TypicalPoint_All[0][5], marker='D', color='lightcoral', markeredgecolor='black', label='LowGenPrice_ESwithOCP')
    HighBattPrice_ES, = ax.plot(1, TypicalPoint_All[0][6], marker='D', color='blueviolet', markeredgecolor='black', label='HighBattPrice_ES')
    HighBattPrice_ESwithOCP, = ax.plot(1, TypicalPoint_All[0][7], marker='D', color='chocolate', markeredgecolor='black', label='HighBattPrice_ESwithOCP')
    LowBattPrice_ES, = ax.plot(1, TypicalPoint_All[0][8], marker='D', color='plum', markeredgecolor='black', label='LowBattPrice_ES')
    LowBattPrice_ESwithOCP, = ax.plot(1, TypicalPoint_All[0][9], marker='D', color='peachpuff', markeredgecolor='black', label='LowBattPrice_ESwithOCP')

    l1 = ax.legend(handles=[HighElecPrice_ES, HighElecPrice_ESwithOCP,LowElecPrice_ES,LowElecPrice_ESwithOCP,HighGenPrice_ESwithOCP,
                            LowGenPrice_ESwithOCP, HighBattPrice_ES,HighBattPrice_ESwithOCP,LowBattPrice_ES,LowBattPrice_ESwithOCP], loc=(0.02, 0.64), frameon=False)


    l2 = ax.legend(handles=[ESwithOCS_min, ES_min, HFO_min,SingleCourse_patch1, SingleCourse_patch2, SingleCourse_patch3], loc=(0.42, 0.88), ncol=2, frameon=False)
    plt.gca().add_artist(l1)

    ax.set_ylim(0, 800)
    plt.tight_layout()
    plt.savefig('./SensitivityAnalysis.pdf',dpi=1000, bbox_inches='tight')
    plt.show()

if __name__=='__main__':
    PLotSensitivityAnalysis()