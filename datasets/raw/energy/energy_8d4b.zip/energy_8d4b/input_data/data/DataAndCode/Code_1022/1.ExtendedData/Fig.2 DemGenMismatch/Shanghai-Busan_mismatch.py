import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def PlotMismatchPower():

    NOCP = 4
    EP = 5
    time = 207
    plt.rc('font', family='Arial', size=16)
    fig = plt.figure(figsize=(25, 10))
    fig.suptitle('GenCharMismatch', fontsize=20)

    P_Char_OCP = np.zeros([EP, NOCP, time])
    P_Gen_OCP = np.zeros([EP, NOCP, time])
    P_BESS = np.zeros([EP, NOCP, time])
    df = pd.ExcelFile('./OCSOpData.xlsx')

    for p in range(EP):
        for i in range(NOCP):
            P_Char_OCP[p][i] = df.parse('P_Char_OCS').loc[i + p * NOCP]
            P_Gen_OCP[p][i] = df.parse('P_Gen_OCS').loc[i + p * NOCP]
            P_BESS[p][i] = df.parse('P_BESS_OCS').loc[i + p * NOCP]

    labels = ['day%s' % (t) for t in range(0, 8)]
    for i in range(NOCP):
        X = np.linspace(1, 168, 168)
        ax1 = plt.subplot(3, 4, i + 1)
        Y1 = P_Gen_OCP[0][i][:168]
        ax1.plot(X, Y1, c='navy', label='Generation Power')

        ax1.set_ylabel('Power/MW')
        ax1.set_title('OCS%s' % (i + 1))
        ax1.legend(loc='upper right')
        ax1.set_xticks(range(0, 192, 24), labels=labels)

        ax2 = plt.subplot(3, 4, i + NOCP + 1)
        Y2 = P_Char_OCP[0][i][:168]
        ax2.plot(X, Y2, c='green', label='Charging Power')

        ax2.set_ylabel('Power/MW')
        ax2.legend(loc='upper right')
        ax2.set_xticks(range(0, 192, 24), labels=labels)

        ax3 = plt.subplot(3, 4, i + 2 * NOCP + 1)
        Y3 = P_BESS[0][i][:168]
        ax3.plot(X, Y3, c='orange', label='BESS Power')
        ax3.set_xlabel('time/h')
        ax3.set_ylabel('Power/MW')
        ax3.legend(loc='upper right')
        ax3.set_xticks(range(0, 192, 24), labels=labels)

        plt.tight_layout()
        plt.savefig('./MismatchFig.pdf', transparent=True, dpi=600)

    plt.show()

if __name__=='__main__':

    PlotMismatchPower()

   
   
   
   
   
   
   

