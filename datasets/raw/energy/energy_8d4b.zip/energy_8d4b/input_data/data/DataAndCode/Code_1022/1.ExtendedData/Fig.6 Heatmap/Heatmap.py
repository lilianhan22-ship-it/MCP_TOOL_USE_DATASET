import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc
rc('font', family='Arial', size=16)

def ReadData_Heatmap():
    df = pd.read_excel('./Heatmap.xlsx', sheet_name='Heatmap_Cargo')
    data_Cargo = np.zeros([16, 32])
    for i in range(16):
        for j in range(32):
            data_Cargo[i][j] = df.values[i+2, j]
    return data_Cargo

def PlotHeatmap_Cargo():
    data_Cargo = ReadData_Heatmap()

    ShipType = ['type1', 'type2', 'type3', 'type4', 'type5', 'type6', 'type7', 'type8',
                'type9', 'type10', 'type11', 'type12', 'type13', 'type14', 'type15', 'type16']

    CourseName =  ['Cristobal-Buenaventura', 'Hamburg-Antwerp',
                  'Shanghai-Busan', 'Basrah-Fujairah', 'Shanghai-Hongkong', 'CapeTown-Durban',
                  'Shanghai-Nagoya', 'Santos-BuenosAries', 'Shanghai-Yokohama', 'Qingdao-Nagoya', 'NewYork-Panama',
                  'NewYork-Panama', 'Ningbo-Singapore', 'Shanghai-Singapore', 'Montreal-Antwerp', 'NewYork-Algeciras',
                  'Singapore-Fujairah', 'Suez-Rotterdam', 'NewYork-Rotterdam', 'Virginia-Antwerp',
                  'Hedland-Jingtang', 'Santos-Elizabeth', 'Durban-Fujairah', 'Melbourne-Singapore', 'Vancouver-Panama',
                  'Houston-Algeciras', 'Singapore-Durban', 'Singapore-Suez',
                  'CorpusChristi-Rotterdam', 'Singapore-CapeTown', 'Shanghai-LosAngles', 'Rotterdam-CapeTown']
    data_Cargo1 = np.array(data_Cargo)
    print('data_Cargo1:', data_Cargo1)

    fig, ax = plt.subplots(figsize=(12,6))



    im = ax.imshow(data_Cargo1)
    cbar = fig.colorbar(im)
    ax.set_xticks(np.arange(len(CourseName)), labels=CourseName, rotation=40, rotation_mode='anchor', ha='right', fontsize=14, font='Arial')
    ax.set_yticks([])
    # plt.title('Heatmap_Cargo')
    ax.set_ylabel('Deadweight', fontsize=16)
    ax.annotate(None, xy=(-0.5,15), xytext=(-0.5,0), arrowprops=dict(facecolor='black', shrink=0.05))
    cbar.set_label('Ratio of extra cargo space \n and total bunker capacity', fontsize=16)

    plt.tight_layout()
    plt.savefig('./Heatmap_Cargo.pdf', dpi=600)
    plt.show()

PlotHeatmap_Cargo()

