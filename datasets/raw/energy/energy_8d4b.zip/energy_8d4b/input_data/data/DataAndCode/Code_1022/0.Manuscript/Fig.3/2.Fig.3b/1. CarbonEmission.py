import numpy as np
import matplotlib.pyplot as plt
from openpyxl import load_workbook

def ReadEmIntData(RouteName):
    workbook = load_workbook('./CarbonEmission.xlsx')
    sheet = workbook[RouteName]
    CarbonEmissionPerDist_ES = np.zeros(8)
    CarbonEmissionPerDist_ESwithOCP = np.zeros(8)
    for col in range(8):
        CarbonEmissionPerDist_ESwithOCP[col] = sheet.cell(row=2, column=2 + col).value
        CarbonEmissionPerDist_ES[col] = sheet.cell(row=3, column=2 + col).value
    CarbonEmissionPerDist_HFO = sheet.cell(row=4, column=2).value
    return CarbonEmissionPerDist_ES, CarbonEmissionPerDist_ESwithOCP, CarbonEmissionPerDist_HFO


def PlotEmission_perDist(RouteName):
    Area = ['EAST ASIA','EUROPE','AFRICA & MIDDLE EAST','AMERICA']
    plt.figure(figsize=(30, 15))
    plt.rc('font', family='Arial')
    for row in range(3):
        for col in range(4):

            print('RouteName = ', RouteName[row][col])
            CarbonEmissionPerDist_ES, CarbonEmissionPerDist_ESwithOCP, CarbonEmissionPerDist_HFO = ReadEmIntData(RouteName[row][col])
            X = np.linspace(2015, 2050, 8)
            Y_ES = CarbonEmissionPerDist_ES
            print('Y_ES = ', Y_ES)
            Y_ESwithOCP = CarbonEmissionPerDist_ESwithOCP
            HFO = CarbonEmissionPerDist_HFO
            ax = plt.subplot(3, 4, row * 4 + col + 1)
            plt.axhline(HFO, linewidth=4, color='orange')
            plt.plot(X, Y_ES, linewidth=4, color='blue', marker='^', markersize=12, markerfacecolor='w', markeredgewidth=2)
            if RouteName[row][col] != 'Rotterdam-Antwerp':
                plt.plot(X, Y_ESwithOCP, linewidth=4, color='green', marker='o', markersize=12, markerfacecolor='w', markeredgewidth=2)
            if row == 0:
                plt.title('%s\n\n%s' % (Area[col],RouteName[row][col]), fontdict={'family': 'Arial', 'size': 22})
            else:
                plt.title('%s'%(RouteName[row][col]), fontdict={'family': 'Arial', 'size': 22})
            if RouteName[row][col] == 'Rotterdam-Antwerp':
                plt.legend(['HFO', 'ES'], frameon=False, fontsize=16)
            else:
                plt.legend(['HFO', 'ES', 'ES+OCP'], frameon=False, fontsize=16)
            if row == 2:
                plt.xlabel('year', fontsize=22, fontdict={'family': 'Arial', 'size': 18})
            plt.xticks(font='Arial', size=18)
            if col == 0 or col == 4 or col == 8:
                plt.ylabel('avgCarbonEmission/km', fontsize=22, fontdict={'family': 'Arial', 'size': 18})
            plt.ticklabel_format(style='sci', scilimits=(-1, 1), axis='y')
            plt.yticks(font='Arial', size=18)
            plt.tight_layout()


    plt.savefig('CarbonEmission.pdf', transparent=True, dpi=1200)
    plt.show()


if __name__=='__main__':
    RouteName = [['Shanghai-Busan', 'Hamburg-Antwerp', 'Basrah-Fujairah','Panama-Houston'],
                 ['Ningbo-Singapore', 'Suez-Rotterdam', 'CapeTown-Durban','NewYork-Panama'],
                 ['Shanghai-Nagoya', 'Rotterdam-Antwerp', 'Durban-Fujairah','Santos-BuenosAries']]

    PlotEmission_perDist(RouteName)
