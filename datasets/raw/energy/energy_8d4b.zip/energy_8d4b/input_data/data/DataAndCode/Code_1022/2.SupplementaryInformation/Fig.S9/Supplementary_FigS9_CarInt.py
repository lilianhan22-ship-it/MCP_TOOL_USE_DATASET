import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import rc

df = pd.ExcelFile('./CarInt_34routes.xlsx')
rc('font', family='Arial', size=12)

RouteName = df.parse('Sheet1')['Course']
ESwithOCS_2020 = df.parse('Sheet1')['ES+OCS'] / 1000
ES_2020 = df.parse('Sheet1')['ES'] / 1000
HFO = df.parse('Sheet1')['HFO'] / 1000

fig, ax = plt.subplots(figsize=(10, 6))
bar_width = 0.35
opacity = 0.8

index = range(len(RouteName))
bar1 = plt.bar(index, ES_2020, bar_width, alpha=opacity, color='navy', label='Carbon Intensity_ES',edgecolor='black')
bar2 = plt.bar([i + bar_width for i in index], ESwithOCS_2020, bar_width, alpha=opacity, color='green', label='Carbon Intensity_ES+OCS',edgecolor='black')

plt.xlabel('Routes')
plt.ylabel('Carbon Emission Intensity (kg/km)')
plt.xticks([i for i in index], RouteName, rotation=75)

plt.legend()

plt.tight_layout()
plt.savefig('Fig.S9.pdf',dpi=600)
plt.show()
