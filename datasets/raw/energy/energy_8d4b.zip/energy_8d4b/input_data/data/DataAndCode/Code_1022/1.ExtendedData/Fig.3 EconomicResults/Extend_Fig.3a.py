import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import rc

df = pd.ExcelFile('./EconomicResults_ExtendedData.xlsx')
rc('font', family='Arial', size=12)

RouteName = df.parse('EconomicResults')['Course']
ESwithOCS_2030 = df.parse('EconomicResults')['2030_ES+OCS']
ES_2030 = df.parse('EconomicResults')['2030_ES']
HFO_2030 = df.parse('EconomicResults')['2030_HFO']

fig, ax = plt.subplots(figsize=(10, 6))
bar_width = 0.35
opacity = 0.8

index = range(len(RouteName))
bar1 = plt.bar(index, ES_2030, bar_width, alpha=opacity, color='green', label='Electric Ships',edgecolor='black')
bar2 = plt.bar([i + bar_width for i in index], HFO_2030, bar_width, alpha=opacity, color='orange', label='HFO-Fueled Ships',edgecolor='black')

plt.xlabel('Routes')
plt.ylabel('Total Cost of Propulsion(USD/Km)')
plt.title('Economic performance of electric and fuel powered ships on 34 routes by 2030')
plt.xticks([i for i in index], RouteName, rotation=75)

plt.legend()
plt.tight_layout()
plt.savefig('Extended Data_Fig.3_2030.pdf',dpi=600)
plt.show()
