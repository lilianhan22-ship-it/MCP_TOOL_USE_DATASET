from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _route_columns_from_header(df: pd.DataFrame, header_row: int = 1) -> list[int]:
    columns = []
    for idx, value in enumerate(df.iloc[header_row].tolist()):
        if idx == 0 or pd.isna(value):
            continue
        text = str(value).strip()
        if text and text.lower() != "nan":
            columns.append(idx)
    return columns


def _rating_table(path: str) -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name="Rating", header=None)
    body = df.iloc[4:38, 1:18].copy()
    body.columns = [
        "route",
        "length_km",
        "ES_cost_2050",
        "AS_cost_2050",
        "HFO_cost_2050",
        "ES_OCS_cost_2050",
        "AS_OAS_cost_2050",
        "ES_ratio_2050",
        "AS_ratio_2050",
        "HFO_ratio_2050",
        "ES_OCS_ratio_2050",
        "AS_OAS_ratio_2050",
        "ES_rating_2050",
        "AS_rating_2050",
        "HFO_rating_2050",
        "ES_OCS_rating_2050",
        "AS_OAS_rating_2050",
    ]
    body = body.dropna(subset=["route"]).reset_index(drop=True)
    for col in [c for c in body.columns if c.endswith("_2050") and "rating" not in c]:
        body[col] = pd.to_numeric(body[col], errors="coerce")
    return body


def electrification_rate_summary(path: str) -> dict:
    df = pd.read_excel(path, sheet_name="ElecRate", header=None)
    route_cols = _route_columns_from_header(df)
    route_names = df.iloc[1, route_cols].astype(str).tolist()
    matrix = df.iloc[3:97, route_cols].apply(pd.to_numeric, errors="coerce")
    route_medians = matrix.median(axis=0, skipna=True).tolist()
    pairs = sorted(zip(route_names, route_medians), key=lambda x: x[1], reverse=True)
    return {
        "routes": len(route_names),
        "highest_route": pairs[0][0],
        "highest_route_median_value": float(pairs[0][1]),
        "lowest_route": pairs[-1][0],
        "lowest_route_median_value": float(pairs[-1][1]),
        "overall_median_value": float(np.nanmedian(matrix.to_numpy(dtype=float))),
    }


def carbon_emission_reduction_summary(path: str) -> dict:
    xls = pd.ExcelFile(path)
    route_reductions = {}
    for sheet in xls.sheet_names:
        df = pd.read_excel(xls, sheet_name=sheet)
        with_ocs = float(df.loc[df.iloc[:, 0] == "ESwithOCS", "CarbonEmissionPerDist_2050"].iloc[0])
        without_ocs = float(df.loc[df.iloc[:, 0] == "ESwithoutOCS", "CarbonEmissionPerDist_2050"].iloc[0])
        route_reductions[sheet] = 1.0 - with_ocs / without_ocs
    best = max(route_reductions.items(), key=lambda x: x[1])
    worst = min(route_reductions.items(), key=lambda x: x[1])
    return {
        "routes": len(route_reductions),
        "mean_reduction_2050": float(np.mean(list(route_reductions.values()))),
        "best_route": best[0],
        "best_reduction_2050": float(best[1]),
        "worst_route": worst[0],
        "worst_reduction_2050": float(worst[1]),
    }


def grace_period_sensitivity(path: str) -> dict:
    df = pd.read_excel(path, sheet_name="Sheet2", header=None)
    grace = df.iloc[0, 1:7].astype(float).tolist()
    obj = df.iloc[1, 1:7].astype(float).tolist()
    return {
        "route_file": Path(path).stem.replace("GracePeriodAnalysis_", ""),
        "grace_periods": grace,
        "objective_values": obj,
        "improvement_from_0_to_0.5": float(obj[0] - obj[-1]),
    }


def cost_rating_summary(path: str) -> dict:
    body = _rating_table(path)
    es_vs_hfo_savings = body["HFO_cost_2050"] - body["ES_cost_2050"]
    ocs_vs_as_savings = body["AS_OAS_cost_2050"] - body["ES_OCS_cost_2050"]
    return {
        "routes": int(len(body)),
        "es_better_than_hfo_2050": int((body["ES_cost_2050"] < body["HFO_cost_2050"]).sum()),
        "es_ocs_better_than_as_oas_2050": int((body["ES_OCS_cost_2050"] < body["AS_OAS_cost_2050"]).sum()),
        "mean_es_vs_hfo_savings_2050": float(es_vs_hfo_savings.mean()),
        "mean_ocs_vs_as_oas_savings_2050": float(ocs_vs_as_savings.mean()),
        "a_rated_es_ocs_routes_2050": int((body["ES_OCS_rating_2050"] == "A").sum()),
        "b_or_better_es_ocs_routes_2050": int(body["ES_OCS_rating_2050"].isin(["A", "B"]).sum()),
    }


def plot_carbon_reduction(path: str, output_path: str) -> dict:
    xls = pd.ExcelFile(path)
    rows = []
    for sheet in xls.sheet_names:
        df = pd.read_excel(xls, sheet_name=sheet)
        with_ocs = float(df.loc[df.iloc[:, 0] == "ESwithOCS", "CarbonEmissionPerDist_2050"].iloc[0])
        without_ocs = float(df.loc[df.iloc[:, 0] == "ESwithoutOCS", "CarbonEmissionPerDist_2050"].iloc[0])
        rows.append((sheet, 1.0 - with_ocs / without_ocs))
    rows = sorted(rows, key=lambda x: x[1], reverse=True)
    plt.figure(figsize=(8, 4))
    plt.bar(range(len(rows)), [r[1] for r in rows])
    plt.xticks(range(len(rows)), [r[0] for r in rows], rotation=90)
    plt.ylabel("2050 carbon reduction")
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": output_path, **carbon_emission_reduction_summary(path)}


def plot_grace_period(path: str, output_path: str) -> dict:
    s = grace_period_sensitivity(path)
    plt.figure(figsize=(6, 4))
    plt.plot(s["grace_periods"], s["objective_values"], marker="o")
    plt.xlabel("Grace period")
    plt.ylabel("Objective value")
    plt.title(s["route_file"])
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": output_path, **s}


def plot_electrification_rate(path: str, output_path: str) -> dict:
    df = pd.read_excel(path, sheet_name="ElecRate", header=None)
    route_cols = _route_columns_from_header(df)
    routes = df.iloc[1, route_cols].astype(str).tolist()
    scenarios = df.iloc[3:97, 0].ffill().astype(str).tolist()
    matrix = df.iloc[3:97, route_cols].apply(pd.to_numeric, errors="coerce")
    plt.figure(figsize=(9, 5.2))
    plt.imshow(matrix.to_numpy(dtype=float), aspect="auto", cmap="viridis")
    plt.colorbar(label="Released electrification/rating value")
    plt.yticks(range(0, len(scenarios), 8), scenarios[::8], fontsize=7)
    plt.xticks(range(len(routes)), routes, rotation=90, fontsize=6)
    plt.title("Route-scenario electrification matrix")
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), **electrification_rate_summary(path)}


def package_smoke_test() -> dict:
    root = Path(__file__).resolve().parents[1]
    base = root / "input_data" / "data" / "DataAndCode" / "Code_1022" / "0.Manuscript"
    art = root / "artifacts"
    er = str(base / "Fig.3" / "3.Fig.3c" / "ElectrificationRate.xlsx")
    carbon = str(base / "Fig.3" / "2.Fig.3b" / "CarbonEmission.xlsx")
    grace = str(base / "Fig.4" / "GracePeriodAnalysis_Shanghai-Busan.xlsx")
    rating = str(base / "Fig.5" / "Fig5.xlsx")
    return {
        "electrification": electrification_rate_summary(er),
        "carbon": carbon_emission_reduction_summary(carbon),
        "grace": grace_period_sensitivity(grace),
        "rating": cost_rating_summary(rating),
        "figures": [
            plot_carbon_reduction(carbon, str(art / "route_carbon_reduction.png")),
            plot_grace_period(grace, str(art / "grace_period_sensitivity.png")),
            plot_electrification_rate(er, str(art / "electrification_rate.png")),
        ],
    }
