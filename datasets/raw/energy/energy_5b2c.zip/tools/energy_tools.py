from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "input_data" / "data"
SOURCE_WORKBOOK = DATA / "41467_2024_54503_MOESM3_ESM.xlsx"


def source_workbook(path: str | Path | None = None) -> Path:
    candidate = Path(path) if path is not None else SOURCE_WORKBOOK
    if not candidate.exists():
        raise FileNotFoundError(f"source workbook not found: {candidate}")
    return candidate


def _sheet(sheet: str, path: str | Path | None = None) -> pd.DataFrame:
    return pd.read_excel(source_workbook(path), sheet_name=sheet, header=None)


def ion_separation_summary(path: str | Path | None = None) -> dict:
    df = _sheet("Fig.3", path)
    ions = df.iloc[2:12, 0:6].copy()
    ions.columns = ["ion", "hydrate_radius_angstrom", "permeance_lmhb", "permeance_error", "rejection_percent", "rejection_error"]
    for col in ions.columns[1:]:
        ions[col] = pd.to_numeric(ions[col], errors="coerce")
    ions = ions.dropna(subset=["ion", "permeance_lmhb", "rejection_percent"])
    ions["charge_class"] = ions["ion"].astype(str).map(lambda x: "divalent" if "2+" in x else "monovalent")

    selectivity = df.iloc[17:20, 0:5].copy()
    selectivity.columns = ["pair", "selectivity_ph7", "selectivity_ph7_error", "selectivity_2m_h2so4", "selectivity_2m_h2so4_error"]
    for col in selectivity.columns[1:]:
        selectivity[col] = pd.to_numeric(selectivity[col], errors="coerce")
    selectivity = selectivity.dropna(subset=["pair"])

    divalent = ions[ions["charge_class"] == "divalent"]
    monovalent = ions[ions["charge_class"] == "monovalent"]
    return {
        "ion_table": ions.to_dict(orient="records"),
        "selectivity_table": selectivity.to_dict(orient="records"),
        "mean_divalent_rejection_percent": float(divalent["rejection_percent"].mean()),
        "mean_monovalent_rejection_percent": float(monovalent["rejection_percent"].mean()),
        "li_rejection_percent": float(ions.loc[ions["ion"].astype(str) == "Li+", "rejection_percent"].iloc[0]),
        "co_li_selectivity_2m_h2so4": float(selectivity.loc[selectivity["pair"].astype(str) == "Co2+/Li+", "selectivity_2m_h2so4"].iloc[0]),
    }


def ph_stability_summary(path: str | Path | None = None) -> dict:
    df = _sheet("Fig.4", path)
    rejection = df.iloc[3:15, 0:6].copy()
    rejection.columns = ["day", "TAD-TBMB", "PEI-TMC", "DK", "NF270", "MPS-34"]
    permeance = df.iloc[3:15, 7:13].copy()
    permeance.columns = ["day", "TAD-TBMB", "PEI-TMC", "DK", "NF270", "MPS-34"]
    for frame in (rejection, permeance):
        for col in frame.columns:
            frame[col] = pd.to_numeric(frame[col], errors="coerce")
    rejection = rejection.dropna(subset=["day"])
    permeance = permeance.dropna(subset=["day"])
    tad_rej = rejection[["day", "TAD-TBMB"]].dropna()
    tad_perm = permeance[["day", "TAD-TBMB"]].dropna()
    return {
        "rejection_table": rejection.to_dict(orient="records"),
        "permeance_table": permeance.to_dict(orient="records"),
        "tad_tbmb_rejection_day0_percent": float(tad_rej.loc[tad_rej["day"] == 0, "TAD-TBMB"].iloc[0]),
        "tad_tbmb_rejection_day70_percent": float(tad_rej.loc[tad_rej["day"] == 70, "TAD-TBMB"].iloc[0]),
        "tad_tbmb_permeance_day0_lmhb": float(tad_perm.loc[tad_perm["day"] == 0, "TAD-TBMB"].iloc[0]),
        "tad_tbmb_permeance_day70_lmhb": float(tad_perm.loc[tad_perm["day"] == 70, "TAD-TBMB"].iloc[0]),
    }


def continuous_filtration_summary(path: str | Path | None = None) -> dict:
    df = _sheet("Fig.5", path)
    tad = df.iloc[2:21, 0:3].copy()
    tad.columns = ["day", "permeance_lmhb", "co_rejection_percent"]
    pei = df.iloc[2:21, 5:8].copy()
    pei.columns = ["day", "permeance_lmhb", "co_rejection_percent"]
    for frame in (tad, pei):
        for col in frame.columns:
            frame[col] = pd.to_numeric(frame[col], errors="coerce")
    tad = tad.dropna(subset=["day"])
    pei = pei.dropna(subset=["day"])
    return {
        "tad_tbmb": tad.to_dict(orient="records"),
        "pei_tmc": pei.to_dict(orient="records"),
        "tad_tbmb_day30_permeance_lmhb": float(tad.loc[tad["day"] == 30, "permeance_lmhb"].iloc[0]),
        "tad_tbmb_day30_co_rejection_percent": float(tad.loc[tad["day"] == 30, "co_rejection_percent"].iloc[0]),
        "pei_tmc_day30_co_rejection_percent": float(pei.loc[pei["day"] == 30, "co_rejection_percent"].iloc[0]),
    }


def lithium_recovery_summary(path: str | Path | None = None) -> dict:
    df = _sheet("Fig.6", path)
    practical = df.iloc[2:6, 0:3].copy()
    practical.columns = ["cathode", "permeance_lmhb", "m2_rejection_percent"]
    ratios = df.iloc[3:7, 4:7].copy()
    ratios.columns = ["cathode", "feed_m2_li_mass_ratio", "permeate_m2_li_mass_ratio"]
    mass = df.iloc[13:16, 0:5].copy()
    mass.columns = ["stream", "ni_percent", "co_percent", "mn_percent", "li_percent"]
    product = df.iloc[[20], 0:5].copy()
    product.columns = ["metric", "li2co3_percent", "coco3_percent", "nico3_percent", "mnco3_percent"]
    for frame in (practical, ratios, mass, product):
        for col in frame.columns[1:]:
            frame[col] = pd.to_numeric(frame[col], errors="coerce")
    return {
        "practical_leachate_table": practical.to_dict(orient="records"),
        "m2_li_mass_ratio_table": ratios.to_dict(orient="records"),
        "permeate_enrichment_table": mass.to_dict(orient="records"),
        "carbonate_product_table": product.to_dict(orient="records"),
        "second_permeate_li_percent": float(mass.loc[mass["stream"].astype(str) == "2nd permeate", "li_percent"].iloc[0]),
        "li2co3_product_purity_percent": float(product["li2co3_percent"].iloc[0]),
    }


def plot_ion_selectivity(output_path: str | Path) -> dict:
    summary = ion_separation_summary()
    ions = pd.DataFrame(summary["ion_table"])
    selectivity = pd.DataFrame(summary["selectivity_table"])
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    colors = ions["charge_class"].map({"divalent": "#4c78a8", "monovalent": "#f58518"})
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.6))
    axes[0].scatter(ions["hydrate_radius_angstrom"], ions["rejection_percent"], c=colors, s=58)
    for _, row in ions.iterrows():
        axes[0].text(row["hydrate_radius_angstrom"], row["rejection_percent"] + 1.2, str(row["ion"]), fontsize=8, ha="center")
    axes[0].set_xlabel("Hydrated ion radius (angstrom)")
    axes[0].set_ylabel("Rejection (%)")
    axes[0].set_title("Ion sieving in Fig. 3a source data")
    x = np.arange(len(selectivity))
    width = 0.36
    axes[1].bar(x - width / 2, selectivity["selectivity_ph7"], width, label="pH 7", color="#54a24b")
    axes[1].bar(x + width / 2, selectivity["selectivity_2m_h2so4"], width, label="2 M H2SO4", color="#e45756")
    axes[1].set_xticks(x); axes[1].set_xticklabels(selectivity["pair"], rotation=20, ha="right")
    axes[1].set_ylabel("M2+/Li+ selectivity")
    axes[1].set_title("Acid-enhanced selectivity in Fig. 3b")
    axes[1].legend(frameon=False)
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), **summary}


def plot_ph_stability(output_path: str | Path) -> dict:
    summary = ph_stability_summary()
    rejection = pd.DataFrame(summary["rejection_table"])
    permeance = pd.DataFrame(summary["permeance_table"])
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5), sharex=True)
    for membrane in ["TAD-TBMB", "PEI-TMC", "DK", "NF270", "MPS-34"]:
        axes[0].plot(rejection["day"], rejection[membrane], marker="o", ms=3, label=membrane)
        axes[1].plot(permeance["day"], permeance[membrane], marker="o", ms=3, label=membrane)
    axes[0].set_ylabel("Co2+ rejection (%)")
    axes[0].set_xlabel("Immersion time (days)")
    axes[0].set_title("70-day pH-resistance rejection")
    axes[1].set_ylabel("Permeance (LMHB)")
    axes[1].set_xlabel("Immersion time (days)")
    axes[1].set_title("Permeance after acid/base immersion")
    axes[1].legend(frameon=False, fontsize=7)
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), **summary}


def plot_lithium_recovery_workflow(output_path: str | Path) -> dict:
    filtration = continuous_filtration_summary()
    recovery = lithium_recovery_summary()
    tad = pd.DataFrame(filtration["tad_tbmb"])
    pei = pd.DataFrame(filtration["pei_tmc"])
    mass = pd.DataFrame(recovery["permeate_enrichment_table"])
    product = pd.DataFrame(recovery["carbonate_product_table"])
    out = Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.4))
    axes[0].plot(tad["day"], tad["co_rejection_percent"], marker="o", label="TAD-TBMB", color="#4c78a8")
    axes[0].plot(pei["day"], pei["co_rejection_percent"], marker="o", label="PEI-TMC", color="#f58518")
    axes[0].set_xlabel("Filtration time (days)")
    axes[0].set_ylabel("Co2+ rejection (%)")
    axes[0].set_title("30-day leachate filtration")
    axes[0].legend(frameon=False, fontsize=8)
    x = np.arange(len(mass))
    axes[1].bar(x, mass["li_percent"], color="#54a24b")
    axes[1].set_xticks(x); axes[1].set_xticklabels(mass["stream"], rotation=25, ha="right")
    axes[1].set_ylabel("Li mass content (%)")
    axes[1].set_title("Lithium enrichment through permeates")
    vals = product.iloc[0][["li2co3_percent", "coco3_percent", "nico3_percent", "mnco3_percent"]]
    axes[2].bar(["Li2CO3", "CoCO3", "NiCO3", "MnCO3"], vals.to_numpy(dtype=float), color=["#4c78a8", "#e45756", "#f58518", "#72b7b2"])
    axes[2].set_ylabel("Mass content (%)")
    axes[2].set_title("Carbonate product purity")
    fig.tight_layout(); fig.savefig(out, dpi=200); plt.close(fig)
    return {"path": str(out), "filtration": filtration, "recovery": recovery}


def package_smoke_test() -> dict:
    return {
        "workbook": str(source_workbook()),
        "ion_separation": ion_separation_summary(),
        "ph_stability": ph_stability_summary(),
        "continuous_filtration": continuous_filtration_summary(),
        "lithium_recovery": lithium_recovery_summary(),
    }
