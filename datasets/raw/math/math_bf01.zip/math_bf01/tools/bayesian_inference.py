"""Bayesian inference primitives: priors, likelihoods, MCMC samplers, and posterior summaries."""

import numpy as np
import pandas as pd
from typing import Callable, Dict, Optional, Tuple, List
from scipy import stats


def specify_prior(name: str, **params) -> Dict:
    """Create a prior distribution specification.

    Parameters
    ----------
    name : str
        Distribution name: 'normal', 'half_cauchy', 'uniform', 'exponential',
        'inv_gamma', 'beta', 'half_normal'.
    **params
        Distribution parameters (e.g., loc=0, scale=1 for normal).

    Returns
    -------
    dict
        Prior specification with 'name' and 'params' keys.
    """
    supported = {'normal', 'half_cauchy', 'uniform', 'exponential',
                 'inv_gamma', 'beta', 'half_normal'}
    if name not in supported:
        raise ValueError(f"Unsupported prior: {name}. Choose from {supported}")
    return {'name': name, 'params': params}


def log_prior(value: float, prior_spec: Dict) -> float:
    """Evaluate the log-prior density at a given value.

    Parameters
    ----------
    value : float or np.ndarray
        Parameter value(s) to evaluate.
    prior_spec : dict
        Prior specification from specify_prior().

    Returns
    -------
    float
        Log-prior density.
    """
    name = prior_spec['name']
    p = prior_spec['params']

    if name == 'normal':
        return stats.norm.logpdf(value, loc=p.get('loc', 0), scale=p.get('scale', 1))
    elif name == 'half_cauchy':
        if np.any(value < 0):
            return -np.inf
        return stats.halfcauchy.logpdf(value, scale=p.get('scale', 1))
    elif name == 'half_normal':
        if np.any(value < 0):
            return -np.inf
        return stats.halfnorm.logpdf(value, scale=p.get('scale', 1))
    elif name == 'uniform':
        return stats.uniform.logpdf(value, loc=p.get('low', 0),
                                     scale=p.get('high', 1) - p.get('low', 0))
    elif name == 'exponential':
        if np.any(value < 0):
            return -np.inf
        return stats.expon.logpdf(value, scale=1.0 / p.get('rate', 1))
    elif name == 'inv_gamma':
        if np.any(value <= 0):
            return -np.inf
        return stats.invgamma.logpdf(value, a=p.get('a', 2), scale=p.get('b', 1))
    elif name == 'beta':
        return stats.beta.logpdf(value, a=p.get('a', 1), b=p.get('b', 1))
    return 0.0


def gaussian_log_likelihood(y: np.ndarray, mu: np.ndarray,
                            sigma: float) -> float:
    """Compute the Gaussian log-likelihood.

    Parameters
    ----------
    y : np.ndarray
        Observed data vector.
    mu : np.ndarray
        Mean vector (model predictions).
    sigma : float
        Standard deviation of the residuals.

    Returns
    -------
    float
        Total log-likelihood.
    """
    return np.sum(stats.norm.logpdf(y, loc=mu, scale=sigma))


def multivariate_normal_log_likelihood(y: np.ndarray, mu: np.ndarray,
                                        cov: np.ndarray) -> float:
    """Compute multivariate normal log-likelihood with a full covariance matrix.

    Parameters
    ----------
    y : np.ndarray
        Observed data vector of length n.
    mu : np.ndarray
        Mean vector of length n.
    cov : np.ndarray
        Covariance matrix of shape (n, n).

    Returns
    -------
    float
        Log-likelihood value.
    """
    try:
        return stats.multivariate_normal.logpdf(y, mean=mu, cov=cov,
                                                 allow_singular=True)
    except np.linalg.LinAlgError:
        return -np.inf


def construct_covariance(sigma2: float, rho: float,
                         proximity_matrix: np.ndarray,
                         nugget: float = 1e-6) -> np.ndarray:
    """Construct a covariance matrix from a proximity matrix and variance parameters.

    Cov = sigma2 * (rho * Proximity + (1-rho) * I) + nugget * I

    Parameters
    ----------
    sigma2 : float
        Total variance.
    rho : float
        Proportion of variance explained by proximity structure, in [0, 1].
    proximity_matrix : np.ndarray
        Proximity/correlation matrix.
    nugget : float
        Small positive value for numerical stability.

    Returns
    -------
    np.ndarray
        Covariance matrix.
    """
    n = proximity_matrix.shape[0]
    I = np.eye(n)
    cov = sigma2 * (rho * proximity_matrix + (1 - rho) * I) + nugget * I
    return cov


def construct_additive_covariance(sigma2: float,
                                  nugget: float = 1e-6,
                                  geo: Optional[np.ndarray] = None,
                                  linguistic: Optional[np.ndarray] = None,
                                  tau_geo2: float = 1.0,
                                  tau_linguistic2: float = 1.0) -> np.ndarray:
    """Construct sigma^2 I + tau_geo^2 K_geo + tau_lang^2 K_lang."""
    base = None
    for K in (geo, linguistic):
        if K is not None:
            base = np.zeros_like(K, dtype=float)
            break
    if base is None:
        raise ValueError("at least one proximity matrix is required")
    n = base.shape[0]
    cov = sigma2 * np.eye(n)
    if geo is not None:
        cov = cov + tau_geo2 * np.asarray(geo, dtype=float)
    if linguistic is not None:
        cov = cov + tau_linguistic2 * np.asarray(linguistic, dtype=float)
    return cov + nugget * np.eye(n)


def metropolis_hastings(log_posterior_fn: Callable,
                        initial_params: np.ndarray,
                        proposal_scale: np.ndarray,
                        n_iterations: int = 10000,
                        burn_in: int = 2000,
                        thin: int = 1,
                        seed: Optional[int] = None) -> Dict:
    """Run the Metropolis-Hastings MCMC sampler.

    Parameters
    ----------
    log_posterior_fn : callable
        Function that takes a parameter vector and returns the log-posterior.
    initial_params : np.ndarray
        Starting parameter values.
    proposal_scale : np.ndarray
        Standard deviations for Gaussian proposal distribution (per parameter).
    n_iterations : int
        Total number of MCMC iterations.
    burn_in : int
        Number of initial samples to discard.
    thin : int
        Thinning interval (keep every thin-th sample).
    seed : int, optional
        Random seed for reproducibility.

    Returns
    -------
    dict
        Keys: 'samples' (np.ndarray of shape (n_kept, p)),
              'acceptance_rate' (float),
              'log_posterior_trace' (np.ndarray).
    """
    if seed is not None:
        np.random.seed(seed)

    n_params = len(initial_params)
    current = initial_params.copy()
    current_lp = log_posterior_fn(current)

    all_samples = []
    all_lp = []
    n_accept = 0

    for i in range(n_iterations):
        proposal = current + np.random.normal(0, proposal_scale)
        proposal_lp = log_posterior_fn(proposal)

        log_alpha = proposal_lp - current_lp
        if np.log(np.random.uniform()) < log_alpha:
            current = proposal
            current_lp = proposal_lp
            n_accept += 1

        all_samples.append(current.copy())
        all_lp.append(current_lp)

    samples = np.array(all_samples)
    lp_trace = np.array(all_lp)

    # Apply burn-in and thinning
    samples = samples[burn_in::thin]
    lp_trace = lp_trace[burn_in::thin]

    return {
        'samples': samples,
        'acceptance_rate': n_accept / n_iterations,
        'log_posterior_trace': lp_trace
    }


def gibbs_sampler(conditional_samplers: List[Callable],
                  initial_params: List[np.ndarray],
                  n_iterations: int = 10000,
                  burn_in: int = 2000,
                  thin: int = 1,
                  seed: Optional[int] = None) -> Dict:
    """Run a Gibbs sampler with user-specified conditional distributions.

    Parameters
    ----------
    conditional_samplers : list of callable
        Each function takes (current_params, index) and returns a new sample
        for the parameter block at that index.
    initial_params : list of np.ndarray
        Starting values for each parameter block.
    n_iterations : int
        Total number of iterations.
    burn_in : int
        Number of initial samples to discard.
    thin : int
        Thinning interval.
    seed : int, optional
        Random seed.

    Returns
    -------
    dict
        Keys: 'samples' (list of np.ndarray arrays, one per parameter block).
    """
    if seed is not None:
        np.random.seed(seed)

    n_blocks = len(initial_params)
    current = [p.copy() for p in initial_params]
    traces = [[] for _ in range(n_blocks)]

    for i in range(n_iterations):
        for j in range(n_blocks):
            current[j] = conditional_samplers[j](current, j)
        for j in range(n_blocks):
            traces[j].append(current[j].copy())

    result = {}
    for j in range(n_blocks):
        arr = np.array(traces[j])
        result[f'block_{j}'] = arr[burn_in::thin]

    return result


def posterior_summary(samples: np.ndarray,
                     param_names: Optional[List[str]] = None,
                     ci_level: float = 0.95) -> pd.DataFrame:
    """Compute summary statistics for posterior samples.

    Parameters
    ----------
    samples : np.ndarray
        Posterior samples of shape (n_samples, n_params) or (n_samples,).
    param_names : list of str, optional
        Parameter names. If None, uses 'param_0', 'param_1', etc.
    ci_level : float
        Credible interval level (default 0.95 for 95% CI).

    Returns
    -------
    pd.DataFrame
        Summary with columns: mean, sd, median, ci_lower, ci_upper.
    """
    if samples.ndim == 1:
        samples = samples.reshape(-1, 1)

    n_params = samples.shape[1]
    if param_names is None:
        param_names = [f'param_{i}' for i in range(n_params)]

    alpha = 1 - ci_level
    rows = []
    for i in range(n_params):
        s = samples[:, i]
        rows.append({
            'parameter': param_names[i],
            'mean': np.mean(s),
            'sd': np.std(s),
            'median': np.median(s),
            'ci_lower': np.percentile(s, 100 * alpha / 2),
            'ci_upper': np.percentile(s, 100 * (1 - alpha / 2)),
        })
    return pd.DataFrame(rows)


def credible_interval(samples: np.ndarray, level: float = 0.95,
                      method: str = "equal_tailed") -> Tuple[float, float]:
    """Compute a credible interval from posterior samples.

    Parameters
    ----------
    samples : np.ndarray
        1D array of posterior samples.
    level : float
        Credible interval level (e.g., 0.95 for 95% CI).
    method : str
        'equal_tailed' for quantile-based, 'hdi' for highest density interval.

    Returns
    -------
    tuple of (float, float)
        Lower and upper bounds of the credible interval.
    """
    alpha = 1 - level
    if method == "equal_tailed":
        return (np.percentile(samples, 100 * alpha / 2),
                np.percentile(samples, 100 * (1 - alpha / 2)))
    elif method == "hdi":
        sorted_s = np.sort(samples)
        n = len(sorted_s)
        ci_size = int(np.ceil(level * n))
        widths = sorted_s[ci_size:] - sorted_s[:n - ci_size]
        best = np.argmin(widths)
        return (sorted_s[best], sorted_s[best + ci_size])
    else:
        raise ValueError(f"Unknown method: {method}")
