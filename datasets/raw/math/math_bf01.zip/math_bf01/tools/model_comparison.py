"""Model comparison metrics: DIC, WAIC, LOO-CV, Bayes factors."""

import numpy as np
from typing import Callable, List, Dict, Optional


def compute_dic(log_likelihood_fn: Callable,
                posterior_samples: np.ndarray,
                data: dict) -> Dict:
    """Compute the Deviance Information Criterion (DIC).

    Parameters
    ----------
    log_likelihood_fn : callable
        Function(params, data) -> log-likelihood.
    posterior_samples : np.ndarray
        Posterior samples of shape (n_samples, n_params).
    data : dict
        Data dictionary passed to log_likelihood_fn.

    Returns
    -------
    dict
        Keys: 'dic', 'p_dic' (effective number of parameters),
              'deviance_mean', 'deviance_at_mean'.
    """
    n_samples = posterior_samples.shape[0]
    deviances = np.array([-2 * log_likelihood_fn(posterior_samples[i], data)
                          for i in range(n_samples)])
    d_bar = np.mean(deviances)

    mean_params = np.mean(posterior_samples, axis=0)
    d_hat = -2 * log_likelihood_fn(mean_params, data)

    p_dic = d_bar - d_hat
    dic = d_hat + 2 * p_dic

    return {'dic': dic, 'p_dic': p_dic,
            'deviance_mean': d_bar, 'deviance_at_mean': d_hat}


def compute_waic(pointwise_log_lik: np.ndarray) -> Dict:
    """Compute the Widely Applicable Information Criterion (WAIC).

    Parameters
    ----------
    pointwise_log_lik : np.ndarray
        Matrix of shape (n_samples, n_observations) where entry (s, i) is
        log p(y_i | theta_s).

    Returns
    -------
    dict
        Keys: 'waic', 'p_waic' (effective number of parameters),
              'lppd' (log pointwise predictive density),
              'se' (standard error of WAIC).
    """
    n_samples, n_obs = pointwise_log_lik.shape

    # Log pointwise predictive density
    max_ll = np.max(pointwise_log_lik, axis=0)
    lppd_i = max_ll + np.log(np.mean(np.exp(pointwise_log_lik - max_ll), axis=0))
    lppd = np.sum(lppd_i)

    # Effective number of parameters
    p_waic_i = np.var(pointwise_log_lik, axis=0, ddof=1)
    p_waic = np.sum(p_waic_i)

    # WAIC
    waic_i = -2 * (lppd_i - p_waic_i)
    waic = np.sum(waic_i)
    se = np.sqrt(n_obs * np.var(waic_i, ddof=1))

    return {'waic': waic, 'p_waic': p_waic, 'lppd': lppd, 'se': se}


def compute_loo_cv(pointwise_log_lik: np.ndarray) -> Dict:
    """Compute approximate leave-one-out cross-validation using PSIS-LOO.

    A simplified version using importance sampling without Pareto smoothing.

    Parameters
    ----------
    pointwise_log_lik : np.ndarray
        Matrix of shape (n_samples, n_observations).

    Returns
    -------
    dict
        Keys: 'loo' (LOO estimate), 'p_loo' (effective parameters),
              'elpd_loo' (expected log pointwise predictive density),
              'se' (standard error).
    """
    n_samples, n_obs = pointwise_log_lik.shape

    elpd_loo_i = np.zeros(n_obs)
    for i in range(n_obs):
        # Importance weights: 1 / p(y_i | theta_s)
        log_ratios = -pointwise_log_lik[:, i]
        max_lr = np.max(log_ratios)
        log_weights = log_ratios - max_lr
        weights = np.exp(log_weights)
        weights /= np.sum(weights)

        # Weighted log predictive density
        log_lik_i = pointwise_log_lik[:, i]
        max_ll = np.max(log_lik_i)
        elpd_loo_i[i] = max_ll + np.log(np.sum(weights * np.exp(log_lik_i - max_ll)))

    elpd_loo = np.sum(elpd_loo_i)
    loo = -2 * elpd_loo

    # LPPD for p_loo calculation
    max_ll = np.max(pointwise_log_lik, axis=0)
    lppd_i = max_ll + np.log(np.mean(np.exp(pointwise_log_lik - max_ll), axis=0))
    p_loo = np.sum(lppd_i) - elpd_loo

    se = np.sqrt(n_obs * np.var(-2 * elpd_loo_i, ddof=1))

    return {'loo': loo, 'p_loo': p_loo, 'elpd_loo': elpd_loo, 'se': se}


def bayes_factor(log_marginal_model1: float,
                 log_marginal_model2: float) -> float:
    """Compute the Bayes factor from log marginal likelihoods.

    Parameters
    ----------
    log_marginal_model1 : float
        Log marginal likelihood of model 1.
    log_marginal_model2 : float
        Log marginal likelihood of model 2.

    Returns
    -------
    float
        Bayes factor BF_12 = p(data|M1) / p(data|M2).
        Values > 1 favour model 1.
    """
    return np.exp(log_marginal_model1 - log_marginal_model2)


def harmonic_mean_estimator(log_likelihoods: np.ndarray) -> float:
    """Estimate the log marginal likelihood using the harmonic mean estimator.

    Note: this estimator can be unstable but is simple to compute.

    Parameters
    ----------
    log_likelihoods : np.ndarray
        Log-likelihood values at each posterior sample.

    Returns
    -------
    float
        Estimated log marginal likelihood.
    """
    max_neg_ll = np.max(-log_likelihoods)
    log_harmonic = -max_neg_ll - np.log(np.mean(np.exp(-log_likelihoods - max_neg_ll)))
    return log_harmonic


def compare_models(model_results: Dict[str, Dict],
                   criterion: str = "waic") -> dict:
    """Compare multiple models by an information criterion.

    Parameters
    ----------
    model_results : dict
        Mapping of model name to dict containing the criterion value
        (e.g., {'model_a': {'waic': 123.4, ...}, ...}).
    criterion : str
        Criterion to compare: 'waic', 'dic', 'loo'.

    Returns
    -------
    dict
        Keys: 'ranking' (list of model names best to worst),
              'delta' (dict of model name -> difference from best),
              'weights' (dict of model name -> Akaike-style weights).
    """
    values = {name: res[criterion] for name, res in model_results.items()}
    best = min(values.values())

    deltas = {name: v - best for name, v in values.items()}
    # Akaike-style weights
    raw_weights = {name: np.exp(-0.5 * d) for name, d in deltas.items()}
    total = sum(raw_weights.values())
    weights = {name: w / total for name, w in raw_weights.items()}

    ranking = sorted(values.keys(), key=lambda k: values[k])

    return {'ranking': ranking, 'delta': deltas, 'weights': weights}
