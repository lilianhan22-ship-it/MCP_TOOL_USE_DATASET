"""Data loading and preprocessing utilities for cross-national analysis."""

import numpy as np
import pandas as pd
from typing import Optional, Tuple


def load_csv(file_path: str) -> pd.DataFrame:
    """Load a CSV file into a pandas DataFrame.

    Parameters
    ----------
    file_path : str
        Path to the CSV file.

    Returns
    -------
    pd.DataFrame
        The loaded data.
    """
    return pd.read_csv(file_path)


def load_distance_matrix(file_path: str) -> Tuple[np.ndarray, list]:
    """Load a distance/proximity matrix from CSV, returning the matrix and labels.

    The first column is treated as row labels matching the column headers.

    Parameters
    ----------
    file_path : str
        Path to the CSV file containing the distance matrix.

    Returns
    -------
    tuple of (np.ndarray, list)
        The distance matrix as a 2D array and the list of nation labels.
    """
    df = pd.read_csv(file_path, index_col=0)
    labels = list(df.index)
    matrix = df.values.astype(float)
    return matrix, labels


def standardise_variables(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """Standardise specified columns to zero mean and unit variance.

    Parameters
    ----------
    df : pd.DataFrame
        Input data.
    columns : list
        Column names to standardise.

    Returns
    -------
    pd.DataFrame
        Copy of df with specified columns standardised.
    """
    result = df.copy()
    for col in columns:
        vals = result[col].dropna()
        result[col] = (result[col] - vals.mean()) / vals.std()
    return result


def merge_datasets(df1: pd.DataFrame, df2: pd.DataFrame,
                   left_on: str, right_on: str,
                   how: str = "inner") -> pd.DataFrame:
    """Merge two DataFrames on specified key columns.

    Parameters
    ----------
    df1 : pd.DataFrame
        Left DataFrame.
    df2 : pd.DataFrame
        Right DataFrame.
    left_on : str
        Column name in df1 to merge on.
    right_on : str
        Column name in df2 to merge on.
    how : str
        Merge type: 'inner', 'left', 'outer'.

    Returns
    -------
    pd.DataFrame
        Merged DataFrame.
    """
    return pd.merge(df1, df2, left_on=left_on, right_on=right_on, how=how)


def compute_geographic_proximity(latitudes: np.ndarray,
                                  longitudes: np.ndarray) -> np.ndarray:
    """Compute geographic proximity matrix from latitude/longitude coordinates.

    Geographic distance is the great-circle distance (Haversine formula).
    Proximity is computed as 1 - (log_distance / max_log_distance), scaled to [0, 1].

    Parameters
    ----------
    latitudes : np.ndarray
        Array of latitudes in degrees.
    longitudes : np.ndarray
        Array of longitudes in degrees.

    Returns
    -------
    np.ndarray
        Symmetric proximity matrix with shape (n, n), values in [0, 1].
    """
    n = len(latitudes)
    R = 6371.0  # Earth radius in km
    lat_rad = np.radians(latitudes)
    lon_rad = np.radians(longitudes)

    dist = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            dlat = lat_rad[j] - lat_rad[i]
            dlon = lon_rad[j] - lon_rad[i]
            a = (np.sin(dlat / 2) ** 2 +
                 np.cos(lat_rad[i]) * np.cos(lat_rad[j]) * np.sin(dlon / 2) ** 2)
            c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))
            dist[i, j] = dist[j, i] = R * c

    # Log-transform and convert to proximity
    log_dist = np.log(dist + 1)
    max_log = np.max(log_dist)
    proximity = 1 - log_dist / max_log
    np.fill_diagonal(proximity, 1.0)
    return proximity


def distance_to_proximity(distance_matrix: np.ndarray,
                          scale: Optional[float] = None,
                          make_psd: bool = True) -> np.ndarray:
    """Convert a pairwise distance matrix to a proximity (correlation-like) matrix.

    The bundled ``geographic_distance_matrix.csv`` and
    ``linguistic_distance_matrix.csv`` store *distances* (larger = more dissimilar,
    zero on the diagonal for geography). The multilevel-model covariance builder
    ``bayesian_inference.construct_covariance`` expects a *proximity* matrix
    (larger = more similar, ~1 on the diagonal, positive semi-definite). This
    helper performs that conversion so the matrix semantics match the model code:

        proximity = exp(-distance / median(nonzero distance))

    with a unit diagonal and an optional eigenvalue clip to guarantee positive
    semi-definiteness for the multivariate-normal likelihood.

    Parameters
    ----------
    distance_matrix : np.ndarray
        Symmetric (n, n) distance matrix.
    scale : float, optional
        Positive denominator for the exponential kernel. If omitted, use the
        median of nonzero distances in the provided matrix.
    make_psd : bool
        If True, clip negative eigenvalues to a small positive value.

    Returns
    -------
    np.ndarray
        Symmetric (n, n) proximity matrix with unit diagonal, values in [0, 1].
    """
    D = np.asarray(distance_matrix, dtype=float)
    D = (D + D.T) / 2.0
    np.fill_diagonal(D, 0.0)
    nonzero = D[np.isfinite(D) & (D > 0)]
    denom = float(scale) if scale is not None else (float(np.median(nonzero)) if nonzero.size else 1.0)
    if not np.isfinite(denom) or denom <= 0:
        raise ValueError("scale must be a positive finite value")
    prox = np.exp(-D / denom)
    np.fill_diagonal(prox, 1.0)
    prox = (prox + prox.T) / 2.0
    if make_psd:
        w, V = np.linalg.eigh(prox)
        w = np.clip(w, 1e-8, None)
        prox = (V * w) @ V.T
        prox = (prox + prox.T) / 2.0
        np.fill_diagonal(prox, 1.0)
    return prox


def subset_proximity_matrix(full_matrix: np.ndarray, full_labels: list,
                            subset_labels: list,
                            return_alignment: bool = True):
    """Extract a sub-matrix from a proximity matrix for a subset of nations.

    Aligns the output to ``subset_labels`` order. Labels in ``subset_labels``
    that are NOT present in ``full_labels`` are filtered OUT — to make this
    behaviour auditable rather than silent the function now returns the
    aligned matrix together with the kept and dropped label lists when
    ``return_alignment=True`` (default).

    Parameters
    ----------
    full_matrix : np.ndarray
        Full proximity matrix of shape (N, N).
    full_labels : list
        Labels for rows/columns of the full matrix.
    subset_labels : list
        Labels for the desired subset, in the requested output order.
    return_alignment : bool, default True
        If True, returns ``(sub_matrix, kept_labels, dropped_labels)``.
        If False, returns only ``sub_matrix`` (legacy behaviour; produces
        the silent-drop pattern flagged by the upstream review).

    Returns
    -------
    np.ndarray or tuple
        When ``return_alignment=False``: the aligned ``sub_matrix`` of
        shape ``(n, n)`` where ``n = len(kept_labels)``.
        When ``return_alignment=True``: the tuple
        ``(sub_matrix, kept_labels, dropped_labels)`` so the caller can
        verify which ISO codes survived the subset filter and which were
        silently dropped because they were absent from ``full_labels``.
    """
    label_to_idx = {lab: i for i, lab in enumerate(full_labels)}
    kept = [lab for lab in subset_labels if lab in label_to_idx]
    dropped = [lab for lab in subset_labels if lab not in label_to_idx]
    indices = [label_to_idx[lab] for lab in kept]
    sub_matrix = full_matrix[np.ix_(indices, indices)]
    if return_alignment:
        return sub_matrix, kept, dropped
    return sub_matrix


def filter_complete_cases(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """Return rows where all specified columns are non-missing.

    Parameters
    ----------
    df : pd.DataFrame
        Input data.
    columns : list
        Columns that must be non-null.

    Returns
    -------
    pd.DataFrame
        Filtered DataFrame.
    """
    return df.dropna(subset=columns).reset_index(drop=True)
