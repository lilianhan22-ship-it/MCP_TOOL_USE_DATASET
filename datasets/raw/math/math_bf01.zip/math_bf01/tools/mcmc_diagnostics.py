"""MCMC convergence diagnostics: Rhat, ESS, trace analysis."""

import numpy as np
from typing import List, Dict, Optional


def compute_rhat(chains: List[np.ndarray]) -> float:
    """Compute the Gelman-Rubin R-hat convergence diagnostic.

    Parameters
    ----------
    chains : list of np.ndarray
        List of 1D arrays, each representing a chain's samples for one parameter.

    Returns
    -------
    float
        R-hat statistic. Values < 1.1 indicate convergence.
    """
    m = len(chains)
    n = min(len(c) for c in chains)

    chain_means = np.array([np.mean(c[:n]) for c in chains])
    grand_mean = np.mean(chain_means)

    # Between-chain variance
    B = n / (m - 1) * np.sum((chain_means - grand_mean) ** 2)

    # Within-chain variance
    chain_vars = np.array([np.var(c[:n], ddof=1) for c in chains])
    W = np.mean(chain_vars)

    # Pooled posterior variance estimate
    var_hat = (1 - 1 / n) * W + (1 / n) * B

    if W == 0:
        return float('inf')
    return np.sqrt(var_hat / W)


def compute_ess(samples: np.ndarray, max_lag: Optional[int] = None) -> float:
    """Compute effective sample size (ESS) from autocorrelation.

    Parameters
    ----------
    samples : np.ndarray
        1D array of MCMC samples.
    max_lag : int, optional
        Maximum lag to consider. Default is min(len(samples)//2, 1000).

    Returns
    -------
    float
        Effective sample size.
    """
    n = len(samples)
    if max_lag is None:
        max_lag = min(n // 2, 1000)

    mean_s = np.mean(samples)
    var_s = np.var(samples, ddof=0)
    if var_s == 0:
        return float(n)

    # Compute autocorrelations
    autocorr_sum = 0.0
    for lag in range(1, max_lag + 1):
        autocov = np.mean((samples[:n - lag] - mean_s) * (samples[lag:] - mean_s))
        rho = autocov / var_s
        if rho < 0.05:
            break
        autocorr_sum += rho

    ess = n / (1 + 2 * autocorr_sum)
    return max(1.0, ess)


def compute_mcse(samples: np.ndarray) -> float:
    """Compute Monte Carlo standard error using batch means.

    Parameters
    ----------
    samples : np.ndarray
        1D array of MCMC samples.

    Returns
    -------
    float
        Monte Carlo standard error of the mean estimate.
    """
    n = len(samples)
    n_batches = int(np.sqrt(n))
    batch_size = n // n_batches

    batch_means = []
    for i in range(n_batches):
        start = i * batch_size
        end = start + batch_size
        batch_means.append(np.mean(samples[start:end]))

    batch_means = np.array(batch_means)
    return np.std(batch_means, ddof=1) / np.sqrt(n_batches)


def diagnose_chains(chains: List[np.ndarray],
                    param_names: Optional[List[str]] = None) -> dict:
    """Run full convergence diagnostics on multiple chains.

    Parameters
    ----------
    chains : list of np.ndarray
        Each chain is shape (n_samples, n_params).
    param_names : list of str, optional
        Names for each parameter.

    Returns
    -------
    dict
        Dictionary with keys 'rhat', 'ess', 'mcse' each mapping parameter
        names to diagnostic values.
    """
    if len(chains) == 0:
        return {}

    n_params = chains[0].shape[1] if chains[0].ndim > 1 else 1
    if param_names is None:
        param_names = [f'param_{i}' for i in range(n_params)]

    results = {'rhat': {}, 'ess': {}, 'mcse': {}}

    for p in range(n_params):
        if chains[0].ndim > 1:
            param_chains = [c[:, p] for c in chains]
        else:
            param_chains = chains

        results['rhat'][param_names[p]] = compute_rhat(param_chains)
        combined = np.concatenate(param_chains)
        results['ess'][param_names[p]] = compute_ess(combined)
        results['mcse'][param_names[p]] = compute_mcse(combined)

    return results


def geweke_test(samples: np.ndarray, first_frac: float = 0.1,
                last_frac: float = 0.5) -> float:
    """Perform Geweke's convergence diagnostic.

    Compares the mean of the first portion to the last portion of the chain.

    Parameters
    ----------
    samples : np.ndarray
        1D array of MCMC samples.
    first_frac : float
        Fraction of samples for the first segment.
    last_frac : float
        Fraction of samples for the last segment.

    Returns
    -------
    float
        Z-score. Values within [-2, 2] suggest convergence.
    """
    n = len(samples)
    n_first = int(first_frac * n)
    n_last = int(last_frac * n)

    first = samples[:n_first]
    last = samples[-n_last:]

    mean_diff = np.mean(first) - np.mean(last)
    se = np.sqrt(np.var(first) / n_first + np.var(last) / n_last)

    if se == 0:
        return 0.0
    return mean_diff / se
