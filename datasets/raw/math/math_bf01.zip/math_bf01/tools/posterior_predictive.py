"""Posterior predictive checks and model adequacy assessment."""

import numpy as np
from typing import Callable, Dict, Optional
from scipy import stats


def posterior_predictive_samples(predict_fn: Callable,
                                 posterior_samples: np.ndarray,
                                 data: dict,
                                 n_pred_samples: int = 1) -> np.ndarray:
    """Generate posterior predictive samples.

    Parameters
    ----------
    predict_fn : callable
        Function(params, data) -> predicted y values (np.ndarray of length n_obs).
    posterior_samples : np.ndarray
        Posterior parameter samples of shape (n_mcmc, n_params).
    data : dict
        Data dictionary passed to predict_fn.
    n_pred_samples : int
        Number of predictive replicates per posterior sample.

    Returns
    -------
    np.ndarray
        Predicted data of shape (n_mcmc * n_pred_samples, n_obs).
    """
    all_preds = []
    for i in range(len(posterior_samples)):
        for _ in range(n_pred_samples):
            pred = predict_fn(posterior_samples[i], data)
            all_preds.append(pred)
    return np.array(all_preds)


def posterior_predictive_pvalue(observed_stat: float,
                                replicated_stats: np.ndarray) -> float:
    """Compute a posterior predictive p-value.

    Parameters
    ----------
    observed_stat : float
        The test statistic computed from the observed data.
    replicated_stats : np.ndarray
        Test statistics computed from posterior predictive replications.

    Returns
    -------
    float
        Proportion of replicated statistics >= observed statistic.
        Values near 0.5 indicate good model fit.
    """
    return np.mean(replicated_stats >= observed_stat)


def compute_residuals(y_observed: np.ndarray,
                      y_predicted: np.ndarray) -> np.ndarray:
    """Compute residuals between observed and predicted values.

    Parameters
    ----------
    y_observed : np.ndarray
        Observed data.
    y_predicted : np.ndarray
        Model predictions (posterior mean or point estimate).

    Returns
    -------
    np.ndarray
        Residuals (observed - predicted).
    """
    return y_observed - y_predicted


def predictive_interval(predictive_samples: np.ndarray,
                        level: float = 0.95) -> tuple:
    """Compute pointwise predictive intervals from posterior predictive samples.

    Parameters
    ----------
    predictive_samples : np.ndarray
        Shape (n_samples, n_obs).
    level : float
        Interval coverage level.

    Returns
    -------
    tuple of (np.ndarray, np.ndarray, np.ndarray)
        (median, lower_bound, upper_bound) each of length n_obs.
    """
    alpha = 1 - level
    median = np.median(predictive_samples, axis=0)
    lower = np.percentile(predictive_samples, 100 * alpha / 2, axis=0)
    upper = np.percentile(predictive_samples, 100 * (1 - alpha / 2), axis=0)
    return median, lower, upper


def coverage_check(y_observed: np.ndarray,
                   lower: np.ndarray,
                   upper: np.ndarray) -> float:
    """Check what fraction of observations fall within predictive intervals.

    Parameters
    ----------
    y_observed : np.ndarray
        Observed data.
    lower : np.ndarray
        Lower bounds of predictive intervals.
    upper : np.ndarray
        Upper bounds of predictive intervals.

    Returns
    -------
    float
        Fraction of observations within the intervals.
    """
    within = (y_observed >= lower) & (y_observed <= upper)
    return np.mean(within)
