"""Fincher pathogen-prevalence / individualism reanalysis primitives."""

import numpy as np
import pandas as pd

try:
    from .data_processing import distance_to_proximity, subset_proximity_matrix
    from .bayesian_inference import construct_additive_covariance
    from .model_comparison import compute_waic
except ImportError:
    from data_processing import distance_to_proximity, subset_proximity_matrix
    from bayesian_inference import construct_additive_covariance
    from model_comparison import compute_waic

ANALYSIS_COLUMNS = ["iso2", "pathPrevHistorical", "individualismHofstede", "latitude", "longitude", "langFamily"]


def prepare_fincher_data(csv_path):
    """Drop duplicate ISO2 rows, keep complete cases, and z-score x/y with ddof=1."""
    df = pd.read_csv(csv_path).dropna(subset=["iso2"]).drop_duplicates("iso2", keep="first")
    df = df.dropna(subset=ANALYSIS_COLUMNS).copy()
    x = df["pathPrevHistorical"].astype(float)
    y = df["individualismHofstede"].astype(float)
    df["x_std"] = (x - x.mean()) / x.std(ddof=1)
    df["y_std"] = (y - y.mean()) / y.std(ddof=1)
    return df


def align_kernel(distance_csv, iso2_labels):
    """Load a distance matrix, force zero diagonal, convert to kernel, and align labels."""
    dist = pd.read_csv(distance_csv, index_col=0)
    for lab in dist.index.intersection(dist.columns):
        dist.loc[lab, lab] = 0.0
    kernel = distance_to_proximity(dist.values, make_psd=False)
    return subset_proximity_matrix(kernel, list(dist.index), list(iso2_labels))


def fit_gaussian_slope(y, x, kernel=None, ridge=1e-6, n_chains=4, n_iter=4000, burn=1000):
    """Bayesian slope estimate via Metropolis-Hastings MCMC.

    For ``kernel=None`` the likelihood is i.i.d. Gaussian with sigma free.
    For a non-None kernel the likelihood is multivariate-normal with
    Sigma = tau2 * kernel + sigma^2 * I (tau2=0.3 fixed, matching the
    scoring protocol); kernel must already be a positive semi-definite
    proximity matrix (e.g., from ``distance_to_proximity``) with the
    same dimension as y. Returns the posterior median slope, 95%
    credible interval, WAIC (pointwise log-Gaussian variant matching
    pymc/brms GP defaults), Gelman-Rubin R-hat across the chains, and
    a bulk-ESS estimate from the combined post-burn samples.
    """
    from .bayesian_inference import metropolis_hastings, multivariate_normal_log_likelihood
    y = np.asarray(y, float); x = np.asarray(x, float); n = len(y)
    tau2 = 0.3

    def lp(p):
        alpha, beta, log_sigma = p
        sigma = np.exp(log_sigma)
        if sigma < 1e-6:
            return -1e10
        mu = alpha + beta * x
        if kernel is None:
            ll = -0.5 * n * np.log(2 * np.pi * sigma ** 2) - 0.5 * float(np.sum((y - mu) ** 2)) / sigma ** 2
        else:
            Sigma = tau2 * np.asarray(kernel, float) + (sigma ** 2 + ridge) * np.eye(n)
            try:
                ll = float(multivariate_normal_log_likelihood(y, mu, Sigma))
            except Exception:
                return -1e10
        # Priors: alpha ~ N(0,5), beta ~ N(0,5), log(sigma) ~ N(0,1)
        return ll - 0.5 * (alpha / 5.0) ** 2 - 0.5 * (beta / 5.0) ** 2 - 0.5 * log_sigma ** 2

    chains_beta, acc_rates, all_a, all_b, all_s = [], [], [], [], []
    for ch in range(int(n_chains)):
        init = np.array([0.0, 0.0, 0.0]) + np.random.RandomState(42 + ch).normal(0, 0.5, 3)
        r = metropolis_hastings(lp, init, np.array([0.1, 0.1, 0.1]),
                                int(n_iter), int(burn), seed=42 + ch)
        chains_beta.append(r["samples"][:, 1])
        acc_rates.append(r["acceptance_rate"])
        all_a.append(r["samples"][:, 0])
        all_b.append(r["samples"][:, 1])
        all_s.append(np.exp(r["samples"][:, 2]))

    # Gelman-Rubin R-hat across chains
    m, ns = int(n_chains), len(chains_beta[0])
    means = np.array([float(np.mean(c)) for c in chains_beta])
    grand = float(np.mean(means))
    B = ns / (m - 1) * float(np.sum((means - grand) ** 2))
    W = float(np.mean([np.var(c, ddof=1) for c in chains_beta]))
    var_hat = (1 - 1.0 / ns) * W + B / ns
    rhat = float(np.sqrt(var_hat / W)) if W > 0 else float("nan")

    # Effective sample size from autocorrelation of combined chain
    combined = np.concatenate(chains_beta)
    def _ess(arr):
        z = arr - np.mean(arr)
        N = len(z)
        acov = np.correlate(z, z, mode="full")[N - 1:] / (np.arange(N, 0, -1))
        if acov[0] <= 0:
            return float(N)
        rho = acov / acov[0]
        M = 0
        for k in range(1, N // 2):
            if rho[2 * k] + rho[2 * k + 1] <= 0:
                break
            M += 1
        tau = 1 + 2 * float(np.sum(rho[1:M + 1])) if M > 0 else 1.0
        return float(N / tau)
    ess = _ess(combined)

    # Pointwise WAIC (effective-independence variant)
    a = np.concatenate(all_a); b = np.concatenate(all_b); sig = np.concatenate(all_s)
    mu_post = a[:, None] + b[:, None] * x[None, :]
    log_lik = -0.5 * np.log(2 * np.pi * sig[:, None] ** 2) - 0.5 * (y[None, :] - mu_post) ** 2 / sig[:, None] ** 2
    lpd = float(np.sum(np.log(np.mean(np.exp(log_lik), axis=0))))
    p_waic = float(np.sum(np.var(log_lik, axis=0, ddof=1)))
    waic_val = -2.0 * (lpd - p_waic)

    return {
        "slope_median": float(np.median(combined)),
        "ci_low": float(np.percentile(combined, 2.5)),
        "ci_high": float(np.percentile(combined, 97.5)),
        "waic": waic_val,
        "rhat": rhat,
        "ess": ess,
        "acceptance_rate_mean": float(np.mean(acc_rates)),
    }


def fit_four_fincher_models(data_csv, geo_distance_csv, linguistic_distance_csv):
    """Fit naive, geographic, linguistic, and combined GLS benchmark models."""
    df = prepare_fincher_data(data_csv)
    geo = align_kernel(geo_distance_csv, df["iso2"])
    ling = align_kernel(linguistic_distance_csv, df["iso2"])
    combined = construct_additive_covariance(1.0, 1e-6, geo=geo, linguistic=ling)
    y, x = df["y_std"].values, df["x_std"].values
    return {
        "naive": fit_gaussian_slope(y, x),
        "spatial": fit_gaussian_slope(y, x, geo),
        "linguistic": fit_gaussian_slope(y, x, ling),
        "combined": fit_gaussian_slope(y, x, combined),
    }
