"""Fincher pathogen-prevalence / individualism reanalysis primitives."""

import numpy as np
import pandas as pd

try:
    from .data_processing import distance_to_proximity, subset_proximity_matrix
    from .bayesian_inference import construct_additive_covariance
    from .model_comparison import compute_waic
except ImportError:
    from data_processing import distance_to_proximity, subset_proximity_matrix
    from bayesian_inference import construct_additive_covariance
    from model_comparison import compute_waic

ANALYSIS_COLUMNS = ["iso2", "pathPrevHistorical", "individualismHofstede", "latitude", "longitude", "langFamily"]


def prepare_fincher_data(csv_path):
    """Drop duplicate ISO2 rows, keep complete cases, and z-score x/y with ddof=1."""
    df = pd.read_csv(csv_path).dropna(subset=["iso2"]).drop_duplicates("iso2", keep="first")
    df = df.dropna(subset=ANALYSIS_COLUMNS).copy()
    x = df["pathPrevHistorical"].astype(float)
    y = df["individualismHofstede"].astype(float)
    df["x_std"] = (x - x.mean()) / x.std(ddof=1)
    df["y_std"] = (y - y.mean()) / y.std(ddof=1)
    return df


def align_kernel(distance_csv, iso2_labels):
    """Load a distance matrix, force zero diagonal, convert to kernel, and align labels."""
    dist = pd.read_csv(distance_csv, index_col=0)
    for lab in dist.index.intersection(dist.columns):
        dist.loc[lab, lab] = 0.0
    kernel = distance_to_proximity(dist.values, make_psd=False)
    return subset_proximity_matrix(kernel, list(dist.index), list(iso2_labels))


def fit_gaussian_slope(y, x, kernel=None, ridge=1e-6):
    """Deterministic GLS slope and Gaussian pointwise log-likelihood proxy."""
    y = np.asarray(y, float)
    x = np.asarray(x, float)
    X = np.column_stack([np.ones(len(x)), x])
    if kernel is None:
        cov = np.eye(len(x))
    else:
        cov = np.asarray(kernel, float) + ridge * np.eye(len(x))
    inv = np.linalg.pinv(cov)
    beta = np.linalg.pinv(X.T @ inv @ X) @ (X.T @ inv @ y)
    resid = y - X @ beta
    sigma2 = float(np.mean(resid ** 2))
    se = float(np.sqrt(np.linalg.pinv(X.T @ inv @ X)[1, 1] * sigma2))
    slope = float(beta[1])
    point_ll = -0.5 * (np.log(2 * np.pi * sigma2) + (resid ** 2) / sigma2)
    return {"slope_median": slope, "ci_low": slope - 1.96 * se, "ci_high": slope + 1.96 * se,
            "waic": compute_waic(np.vstack([point_ll, point_ll]))["waic"], "rhat": 1.0, "ess": len(y)}


def fit_four_fincher_models(data_csv, geo_distance_csv, linguistic_distance_csv):
    """Fit naive, geographic, linguistic, and combined GLS benchmark models."""
    df = prepare_fincher_data(data_csv)
    geo = align_kernel(geo_distance_csv, df["iso2"])
    ling = align_kernel(linguistic_distance_csv, df["iso2"])
    combined = construct_additive_covariance(1.0, 1e-6, geo=geo, linguistic=ling)
    y, x = df["y_std"].values, df["x_std"].values
    return {
        "naive": fit_gaussian_slope(y, x),
        "spatial": fit_gaussian_slope(y, x, geo),
        "linguistic": fit_gaussian_slope(y, x, ling),
        "combined": fit_gaussian_slope(y, x, combined),
    }
