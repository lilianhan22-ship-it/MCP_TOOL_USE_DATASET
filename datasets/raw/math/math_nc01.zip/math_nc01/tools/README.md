# Network Community Detection Tools

## Tool Categories

### network_analysis.py — Domain Primitives
Core network analysis functions for community detection via graph embeddings:
- **Data loading**: `load_network`, `build_adjacency_matrix`
- **Spectral methods**: `compute_normalized_laplacian`, `spectral_embedding`, `modularity_spectral_embedding`, `adjacency_spectral_embedding`
- **Random-walk embeddings**: `random_walk_sequences`, `uniform_walk_ppmi_embedding` (the bundle's node2vec representative — see naming note below), `deepwalk_embedding`, `verify_spectral_equivalence`

  Note on `uniform_walk_ppmi_embedding` (naming): node2vec (Grover & Leskovec 2016) uses *second-order biased* random walks parameterised by `p`/`q`. The bundled function does NOT implement those biased walks — it samples *uniform* (first-order) random walks and factorizes the empirical positive-PMI (PPMI) matrix. This is exactly the `p=q=1` special case of node2vec (also the DeepWalk walk model), and is the embedding the paper's spectral-equivalence theorem is stated for, so the bundle uses it as the node2vec representative. It must be read as the **uniform-walk PPMI approximation of node2vec**, not the full biased-walk node2vec algorithm. In the four-network comparison results and figures it is labelled `node2vec` for consistency with the paper's method name.

  Note on `verify_spectral_equivalence`: this is an EMPIRICAL APPROXIMATION check, not a proof of the paper's theorem. The paper *analytically proves* an exact equivalence between the spectrum of the **expected** node2vec matrix and the normalized Laplacian (`U = D^{1/2} Gamma`, Eq. 9). The tool instead factorizes a node2vec embedding built from a **finite** number of sampled random walks (the realised/empirical PPMI matrix) and reports the subspace overlap (mean absolute canonical correlation) against the `D^{1/2}`-scaled Laplacian embedding (~0.77 on karate). A high score is *consistent with* the theorem and shows the empirical embedding approximates the spectral subspace, but it does NOT establish the exact equivalence — perfect agreement is only expected in the infinite-walk limit, and the score depends on `num_walks`/`walk_length`/`window_size`/`seed`. Keep the empirical PPMI demonstration conceptually distinct from the paper's theoretical node2vec/spectral-equivalence result.
- **Clustering**: `kmeans_clustering` (row-normalizes embeddings by default), `voronoi_clustering`, `estimate_n_clusters_silhouette`
- **Evaluation**: `element_centric_similarity` (baseline-corrected per the paper: `S = (S_raw - E[S_random])/(1 - E[S_random])`, so a random relabelling scores 0 on expectation and `S>0` means better-than-chance; pass `adjusted=False` for the raw Gates-et-al. metric), `normalized_mutual_information`, `adjusted_rand_index`
- **Detectability**: `compute_detectability_limit`, `generate_planted_partition_model`, `sweep_mixing_parameter` (supports `embedding_method` in `spectral`/`modularity`/`adjacency`/`node2vec`/`deepwalk`; `node2vec` uses the uniform-walk PPMI embedding)
- **Network statistics**: `compute_network_statistics`, `compute_community_mixing_matrix`
- **Plotting**: `plot_embedding_2d`, `plot_method_comparison`, `plot_detectability_curves`, `plot_multi_network_comparison` (y-axis keeps negative baseline-corrected S visible), `plot_graph_kernel`
- **Deterministic driver**: `run_four_network_comparison` — fixed-parameter, fixed-seed (seed=42, random-walk embedding C=64, T=10, num_walks=10, walk_length=80, n_perm=200) end-to-end reproduction of the four-network (Football, Karate, Political Books, Political Blog) comparison. Writes `artifacts/four_network_comparison.csv` (result TABLE: corrected/raw ECS per network×method), `artifacts/multi_network_comparison.png` and `artifacts/embedding_2d.png`. The three spectral baselines (L-EigenMap, modularity, adjacency) are run at their **standard C=q dimensionality** (q = number of ground-truth communities), which is the correct setting for spectral community detection — using the full 64-dim spectral embedding would bury the q-dimensional signal in high-frequency eigenvectors and collapse the baselines to ~chance (an unfair/broken baseline, a dimensionality bug, NOT a property of spectral clustering). With C=q the spectral baselines are **competitive** with the random-walk embeddings on most networks, so the comparison is a **fair** bundled reproduction; node2vec/DeepWalk lead by a modest margin and the cross-method ranking follows paper Fig. 3 [PAPER]. The exact per-network paper scores (which additionally use tuned/non-backtracking spectral setups) remain a [PAPER] result, not reproduced digit-for-digit.

### data_processing.py — Shared Data Helpers
- `list_data_files`, `inspect_csv`, `merge_node_edge_data`, `compute_label_permutation_invariant_score`

### database_retrieval.py — Reference Metadata
- `get_benchmark_network_info`: metadata for standard benchmark networks
