#!/usr/bin/env python3
"""Database retrieval stubs for network benchmark datasets.

Provides functions to download standard network benchmark datasets
used in network science research. In practice, the data files are
already provided in input_data/data/.
"""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Network_Database_Retrieval")


@mcp.tool()
def get_benchmark_network_info(network_name: str) -> dict:
    """Return metadata about a standard benchmark network.

    Supported networks: football, polbooks, polblogs, karate.

    Args:
        network_name: Name of the benchmark network.

    Returns:
        dict with ``name``, ``description``, ``n_nodes``, ``n_edges``,
        ``n_communities``, ``source``, ``reference``.
    """
    info = {
        "football": {
            "name": "American College Football",
            "description": "Games between Division IA colleges, Fall 2000 season. "
                           "Conferences serve as ground-truth communities.",
            "n_nodes": 115,
            "n_edges": 613,
            "n_communities": 12,
            "source": "M. Girvan & M. E. J. Newman, PNAS 99, 7821 (2002)",
            "reference": "http://www-personal.umich.edu/~mejn/netdata/",
        },
        "polbooks": {
            "name": "Political Books",
            "description": "Co-purchasing network of US political books around the "
                           "2004 presidential election. Political leaning (liberal, "
                           "neutral, conservative) is the community label.",
            "n_nodes": 105,
            "n_edges": 441,
            "n_communities": 3,
            "source": "V. Krebs, unpublished (http://www.orgnet.com)",
            "reference": "M. E. J. Newman, Phys. Rev. E 74, 036104 (2006)",
        },
        "polblogs": {
            "name": "Political Blogosphere",
            "description": "Hyperlinks between US political blogs around the 2004 "
                           "election. Blogs are classified as liberal or conservative. "
                           "The bundled network is the largest connected component "
                           "treated as undirected (the full directed graph has 1490 "
                           "nodes).",
            "n_nodes": 1222,
            "n_edges": 16714,
            "n_communities": 2,
            "source": "L. A. Adamic & N. Glance, LinkKDD 2005",
            "reference": "http://www-personal.umich.edu/~mejn/netdata/",
        },
        "karate": {
            "name": "Zachary's Karate Club",
            "description": "Social network of 34 members of a university karate club. "
                           "The club split into two factions (Mr. Hi vs Officer).",
            "n_nodes": 34,
            "n_edges": 78,
            "n_communities": 2,
            "source": "W. W. Zachary, J. Anthropol. Res. 33, 452 (1977)",
            "reference": "Built into NetworkX",
        },
    }
    if network_name not in info:
        return {"error": f"Unknown network: {network_name}. "
                         f"Available: {list(info.keys())}"}
    return info[network_name]
