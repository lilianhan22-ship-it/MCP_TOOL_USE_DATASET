#!/usr/bin/env python3
"""Network community detection and graph embedding tools.

Low-level primitives for loading networks from edge/node CSV files,
computing graph embeddings (node2vec, spectral, DeepWalk, LINE),
running community detection via clustering on embeddings, and
evaluating detected communities against ground truth.

Plot helpers produce PNG files and return the absolute path.
"""

from __future__ import annotations

import os
from typing import Any

import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Network_Community_Detection_Tools")


# ---------------------------------------------------------------------------
# Internal helper implementations (used by sweep_mixing_parameter)
# ---------------------------------------------------------------------------

def _build_adjacency_matrix_impl(network):
    node_ids = sorted(network["ground_truth"].keys())
    n = len(node_ids)
    id_to_idx = {nid: i for i, nid in enumerate(node_ids)}
    A = np.zeros((n, n), dtype=float)
    for s, t in network["edges"]:
        si, ti = id_to_idx.get(int(s)), id_to_idx.get(int(t))
        if si is not None and ti is not None:
            A[si, ti] = 1.0
            A[ti, si] = 1.0
    degrees = A.sum(axis=1).tolist()
    return {"n": n, "adjacency": A.tolist(), "degrees": degrees,
            "avg_degree": float(np.mean(degrees)), "node_ids": node_ids}

def _compute_normalized_laplacian_impl(adjacency):
    A = np.array(adjacency["adjacency"])
    d = np.array(adjacency["degrees"])
    d_inv_sqrt = np.where(d > 0, 1.0 / np.sqrt(d), 0.0)
    D_inv_sqrt = np.diag(d_inv_sqrt)
    L = np.eye(len(d)) - D_inv_sqrt @ A @ D_inv_sqrt
    eigenvalues, eigenvectors = np.linalg.eigh(L)
    return {"eigenvalues": eigenvalues.tolist(),
            "eigenvectors": eigenvectors.tolist(), "n": int(len(d))}

def _spectral_embedding_impl(laplacian_result, n_components=64):
    eigvals = np.array(laplacian_result["eigenvalues"])
    eigvecs = np.array(laplacian_result["eigenvectors"])
    n = laplacian_result["n"]
    C = min(n_components, n - 1)
    idx = range(1, 1 + C)
    embedding = eigvecs[:, idx]
    return {"embedding": embedding.tolist(), "used_eigenvalues": eigvals[idx].tolist(),
            "n_nodes": n, "n_components": C}

def _modularity_spectral_embedding_impl(adjacency, n_components=64):
    A = np.array(adjacency["adjacency"])
    d = np.array(adjacency["degrees"])
    m = A.sum() / 2.0
    if m == 0:
        n = len(d)
        return {"embedding": np.zeros((n, n_components)).tolist(),
                "n_nodes": n, "n_components": n_components}
    B = A - np.outer(d, d) / (2.0 * m)
    eigenvalues, eigenvectors = np.linalg.eigh(B)
    n = len(d)
    C = min(n_components, n - 1)
    idx = list(range(n - 1, n - 1 - C, -1))
    embedding = eigenvectors[:, idx]
    return {"embedding": embedding.tolist(), "n_nodes": n, "n_components": C}

def _uniform_walk_ppmi_embedding_impl(adjacency, n_components=64,
                                      window_size=10, num_walks=10,
                                      walk_length=80, neg_samples=1, seed=42):
    res = uniform_walk_ppmi_embedding(adjacency, n_components=n_components,
                                      window_size=window_size,
                                      num_walks=num_walks,
                                      walk_length=walk_length,
                                      neg_samples=neg_samples, seed=seed)
    return {"embedding": res["embedding"], "n_nodes": res["n_nodes"],
            "n_components": res["n_components"]}

def _deepwalk_embedding_impl(adjacency, n_components=64, window_size=10,
                             seed=42):
    res = deepwalk_embedding(adjacency, n_components=n_components,
                             window_size=window_size, seed=seed)
    return {"embedding": res["embedding"], "n_nodes": res["n_nodes"],
            "n_components": res["n_components"]}

def _adjacency_spectral_embedding_impl(adjacency, n_components=64):
    A = np.array(adjacency["adjacency"])
    eigenvalues, eigenvectors = np.linalg.eigh(A)
    n = len(eigenvalues)
    C = min(n_components, n - 1)
    order = np.argsort(-np.abs(eigenvalues))
    idx = order[:C]
    embedding = eigenvectors[:, idx]
    return {"embedding": embedding.tolist(), "n_nodes": n, "n_components": C}

def _kmeans_clustering_impl(embedding, n_clusters=2, seed=42, normalize=True):
    from sklearn.cluster import KMeans
    X = np.array(embedding["embedding"], dtype=float)
    if normalize and X.size:
        X = X / (np.linalg.norm(X, axis=1, keepdims=True) + 1e-12)
    km = KMeans(n_clusters=n_clusters, n_init=10, random_state=seed, max_iter=300)
    km.fit(X)
    return {"labels": km.labels_.tolist(), "inertia": float(km.inertia_),
            "n_clusters": n_clusters}

def _raw_element_centric_similarity(pred, true):
    """Raw (uncorrected) hard-partition element-centric similarity (Gates et
    al. 2019). Returns (overall_mean, per_node_array)."""
    n = len(pred)
    if n == 0:
        return 0.0, np.zeros(0)
    pred_sizes = {c: int((pred == c).sum()) for c in set(pred.tolist())}
    true_sizes = {c: int((true == c).sum()) for c in set(true.tolist())}
    per_node = np.zeros(n)
    for i in range(n):
        cp, ct = pred[i], true[i]
        sp, st = pred_sizes[cp], true_sizes[ct]
        n_both = int(((pred == cp) & (true == ct)).sum())
        l1 = n_both * abs(1.0 / sp - 1.0 / st) \
            + (sp - n_both) / sp + (st - n_both) / st
        per_node[i] = 1.0 - 0.5 * l1
    return float(per_node.mean()), per_node


def _expected_random_ecs(pred, true, n_perm=200, seed=0):
    """Expected raw ECS under random shuffling of the predicted labels,
    estimated by Monte-Carlo permutation. This is the baseline the paper
    subtracts so that a random relabelling scores 0 on expectation."""
    rng = np.random.RandomState(seed)
    pred = np.asarray(pred)
    true = np.asarray(true)
    vals = []
    for _ in range(n_perm):
        s, _pn = _raw_element_centric_similarity(rng.permutation(pred), true)
        vals.append(s)
    return float(np.mean(vals))


def _element_centric_similarity_impl(labels_pred, labels_true,
                                     adjusted=True, n_perm=200, seed=0):
    pred = np.array(labels_pred)
    true = np.array(labels_true)
    n = len(pred)
    if n == 0:
        return {"similarity": 0.0, "n_nodes": 0, "per_node_similarity": []}

    raw, per_node = _raw_element_centric_similarity(pred, true)
    if not adjusted:
        return {"similarity": raw, "n_nodes": n,
                "per_node_similarity": per_node.tolist()}
    # Baseline correction: S_adj = (S_raw - E[S_random]) / (1 - E[S_random])
    # so a random relabelling scores 0 on expectation (Kojaku et al. 2024,
    # Supporting Information Section 1).
    expected = _expected_random_ecs(pred, true, n_perm=n_perm, seed=seed)
    denom = 1.0 - expected
    adj = (raw - expected) / denom if abs(denom) > 1e-12 else 0.0
    return {"similarity": float(adj), "raw_similarity": raw,
            "expected_random": expected, "n_nodes": n,
            "per_node_similarity": per_node.tolist()}


# ---------------------------------------------------------------------------
# 1. Data loading
# ---------------------------------------------------------------------------

@mcp.tool()
def load_network(edges_csv: str, nodes_csv: str) -> dict:
    """Load a network from separate edge-list and node-attribute CSVs.

    The edge CSV must have columns ``source`` and ``target`` (integer node IDs).
    The node CSV must have columns ``node_id``, ``label``, and ``community``
    (ground-truth community assignment, integer).

    Args:
        edges_csv: Path to edge-list CSV.
        nodes_csv: Path to node-attribute CSV.

    Returns:
        dict with ``n_nodes``, ``n_edges``, ``n_communities``,
        ``edges`` (list of [source, target] pairs),
        ``node_labels`` (dict node_id->label),
        ``ground_truth`` (dict node_id->community_int),
        ``community_names`` (sorted list of unique community IDs).
    """
    edf = pd.read_csv(edges_csv)
    ndf = pd.read_csv(nodes_csv)

    edges = edf[["source", "target"]].values.tolist()
    node_labels = dict(zip(ndf["node_id"].astype(int), ndf["label"].astype(str)))
    ground_truth = dict(zip(ndf["node_id"].astype(int), ndf["community"].astype(int)))
    communities = sorted(set(ground_truth.values()))

    return {
        "n_nodes": int(len(ndf)),
        "n_edges": int(len(edf)),
        "n_communities": int(len(communities)),
        "edges": edges,
        "node_labels": node_labels,
        "ground_truth": ground_truth,
        "community_names": communities,
    }


@mcp.tool()
def build_adjacency_matrix(network: dict) -> dict:
    """Build a sparse adjacency matrix from a loaded network.

    Args:
        network: Output of ``load_network``.

    Returns:
        dict with ``adjacency`` (2-D list, dense), ``degrees`` (list),
        ``avg_degree`` (float), ``node_ids`` (sorted list).
    """
    node_ids = sorted(network["ground_truth"].keys())
    n = len(node_ids)
    id_to_idx = {nid: i for i, nid in enumerate(node_ids)}
    A = np.zeros((n, n), dtype=float)
    for s, t in network["edges"]:
        si, ti = id_to_idx.get(int(s)), id_to_idx.get(int(t))
        if si is not None and ti is not None:
            A[si, ti] = 1.0
            A[ti, si] = 1.0
    degrees = A.sum(axis=1).tolist()
    avg_degree = float(np.mean(degrees))
    return {
        "n": n,
        "adjacency": A.tolist(),
        "degrees": degrees,
        "avg_degree": avg_degree,
        "node_ids": node_ids,
    }


# ---------------------------------------------------------------------------
# 2. Normalized Laplacian and spectral tools
# ---------------------------------------------------------------------------

@mcp.tool()
def compute_normalized_laplacian(adjacency: dict) -> dict:
    """Compute the symmetric normalized Laplacian L = I - D^{-1/2} A D^{-1/2}.

    Args:
        adjacency: Output of ``build_adjacency_matrix``.

    Returns:
        dict with ``laplacian`` (2-D list), ``eigenvalues`` (sorted ascending),
        ``eigenvectors`` (2-D list, columns are eigenvectors).
    """
    A = np.array(adjacency["adjacency"])
    d = np.array(adjacency["degrees"])
    d_inv_sqrt = np.where(d > 0, 1.0 / np.sqrt(d), 0.0)
    D_inv_sqrt = np.diag(d_inv_sqrt)
    L = np.eye(len(d)) - D_inv_sqrt @ A @ D_inv_sqrt
    eigenvalues, eigenvectors = np.linalg.eigh(L)
    return {
        "eigenvalues": eigenvalues.tolist(),
        "eigenvectors": eigenvectors.tolist(),
        "n": int(len(d)),
    }


@mcp.tool()
def spectral_embedding(laplacian_result: dict, n_components: int = 64) -> dict:
    """Extract the spectral embedding from the normalized Laplacian.

    Uses the C smallest *non-trivial* eigenvalues (skipping the first
    zero eigenvalue).  Each row of the returned matrix is the embedding
    of one node.

    Args:
        laplacian_result: Output of ``compute_normalized_laplacian``.
        n_components: Embedding dimensionality C (default 64).

    Returns:
        dict with ``embedding`` (n x C list), ``used_eigenvalues`` (list).
    """
    eigvals = np.array(laplacian_result["eigenvalues"])
    eigvecs = np.array(laplacian_result["eigenvectors"])
    n = laplacian_result["n"]
    C = min(n_components, n - 1)
    # Skip the first eigenvalue (should be ~0)
    idx = range(1, 1 + C)
    embedding = eigvecs[:, idx]
    used_evals = eigvals[idx].tolist()
    return {
        "embedding": embedding.tolist(),
        "used_eigenvalues": used_evals,
        "n_nodes": int(n),
        "n_components": int(C),
    }


@mcp.tool()
def modularity_spectral_embedding(adjacency: dict, n_components: int = 64) -> dict:
    """Spectral embedding based on the modularity matrix B = A - k*k^T/(2m).

    Uses leading eigenvectors of B (largest eigenvalues) rather than
    smallest eigenvalues of the Laplacian.

    Args:
        adjacency: Output of ``build_adjacency_matrix``.
        n_components: Embedding dimensionality.

    Returns:
        dict with ``embedding`` (n x C list), ``used_eigenvalues``.
    """
    A = np.array(adjacency["adjacency"])
    d = np.array(adjacency["degrees"])
    m = A.sum() / 2.0
    if m == 0:
        n = len(d)
        return {"embedding": np.zeros((n, n_components)).tolist(),
                "used_eigenvalues": [0.0] * n_components,
                "n_nodes": n, "n_components": n_components}
    B = A - np.outer(d, d) / (2.0 * m)
    eigenvalues, eigenvectors = np.linalg.eigh(B)
    # Largest eigenvalues
    n = len(d)
    C = min(n_components, n - 1)
    idx = list(range(n - 1, n - 1 - C, -1))
    embedding = eigenvectors[:, idx]
    used_evals = eigenvalues[idx].tolist()
    return {
        "embedding": embedding.tolist(),
        "used_eigenvalues": used_evals,
        "n_nodes": n,
        "n_components": C,
    }


@mcp.tool()
def adjacency_spectral_embedding(adjacency: dict, n_components: int = 64) -> dict:
    """Spectral embedding based on leading eigenvectors of the adjacency matrix A.

    Uses the C largest-magnitude eigenvalues.

    Args:
        adjacency: Output of ``build_adjacency_matrix``.
        n_components: Embedding dimensionality.

    Returns:
        dict with ``embedding``, ``used_eigenvalues``.
    """
    A = np.array(adjacency["adjacency"])
    eigenvalues, eigenvectors = np.linalg.eigh(A)
    n = len(eigenvalues)
    C = min(n_components, n - 1)
    # Sort by absolute value descending
    order = np.argsort(-np.abs(eigenvalues))
    idx = order[:C]
    embedding = eigenvectors[:, idx]
    used_evals = eigenvalues[idx].tolist()
    return {
        "embedding": embedding.tolist(),
        "used_eigenvalues": used_evals,
        "n_nodes": n,
        "n_components": C,
    }


# ---------------------------------------------------------------------------
# 3. Random-walk-based embeddings
# ---------------------------------------------------------------------------

@mcp.tool()
def random_walk_sequences(adjacency: dict, walk_length: int = 80,
                          num_walks: int = 10, seed: int = 42) -> dict:
    """Generate random walk sequences from each node.

    Args:
        adjacency: Output of ``build_adjacency_matrix``.
        walk_length: Length of each random walk.
        num_walks: Number of walks per node.
        seed: Random seed.

    Returns:
        dict with ``walks`` (list of lists of node indices).
    """
    rng = np.random.RandomState(seed)
    A = np.array(adjacency["adjacency"])
    n = A.shape[0]
    degrees = A.sum(axis=1)
    walks = []
    for _ in range(num_walks):
        for start in range(n):
            walk = [start]
            current = start
            for step in range(walk_length - 1):
                neighbors = np.where(A[current] > 0)[0]
                if len(neighbors) == 0:
                    break
                current = rng.choice(neighbors)
                walk.append(int(current))
            walks.append(walk)
    return {"walks": walks, "n_walks": len(walks), "walk_length": walk_length}


@mcp.tool()
def uniform_walk_ppmi_embedding(adjacency: dict, n_components: int = 64,
                       window_size: int = 10, num_walks: int = 10,
                       walk_length: int = 80, neg_samples: int = 1,
                       seed: int = 42) -> dict:
    """Compute a UNIFORM-random-walk PPMI embedding -- the unbiased-walk
    approximation of node2vec used throughout this bundle.

    NAMING / SCOPE NOTE. node2vec (Grover & Leskovec 2016) uses *second-order
    biased* random walks controlled by the return parameter ``p`` and in-out
    parameter ``q``. This function does NOT implement those biased walks: it
    samples *uniform* (first-order) random walks (each step picks a neighbour
    uniformly at random) and factorizes the resulting empirical PPMI matrix.
    In the unbiased limit p = q = 1 node2vec reduces exactly to this uniform
    walk, so this is the standard ``p=q=1`` special case of node2vec (which is
    also the DeepWalk walk model); it should be read as the
    *uniform-walk PPMI approximation of node2vec*, not as the full biased-walk
    node2vec algorithm. This is the embedding the paper's spectral-equivalence
    theorem is stated for (the expected matrix of the uniform/unbiased walk),
    which is why the bundle uses it as the node2vec representative.

    Method. Levy & Goldberg (2014) show that skip-gram with negative
    sampling implicitly factorizes the shifted PMI matrix
    ``M_ij = log( p(i,j) / (p(i) p(j)) ) - log(b)`` where the co-occurrence
    statistics p(i,j) are estimated from random walks with a context window
    of size ``window_size`` and ``b`` is the number of negative samples.
    The embedding is the truncated eigen-factorization of the symmetric
    positive-PMI (PPMI) matrix.

    Because the co-occurrence matrix is estimated empirically from sampled
    walks (never from the Laplacian spectrum), comparing the resulting
    embedding to the analytical normalized-Laplacian spectral embedding is a
    genuine, non-circular check of the paper's spectral-equivalence result.

    Args:
        adjacency: Output of ``build_adjacency_matrix``.
        n_components: Embedding dimension C.
        window_size: Skip-gram context window size T.
        num_walks: Number of random walks started from each node.
        walk_length: Length of each random walk.
        neg_samples: Number of negative samples b (PMI shift log(b)).
        seed: Random seed.

    Returns:
        dict with ``embedding`` (n x C list), ``method`` name.
    """
    rng = np.random.RandomState(seed)
    A = np.array(adjacency["adjacency"])
    n = A.shape[0]
    T = window_size

    # Precompute neighbor lists for fast walking.
    neighbors = [np.where(A[i] > 0)[0] for i in range(n)]

    # 1. Sample random walks.
    walks = []
    for _ in range(num_walks):
        for start in range(n):
            if len(neighbors[start]) == 0:
                continue
            walk = [start]
            cur = start
            for _ in range(walk_length - 1):
                nbrs = neighbors[cur]
                if len(nbrs) == 0:
                    break
                cur = int(rng.choice(nbrs))
                walk.append(cur)
            walks.append(walk)

    # 2. Accumulate windowed co-occurrence counts (symmetric).
    cooc = np.zeros((n, n), dtype=float)
    for walk in walks:
        L = len(walk)
        for pos in range(L):
            wc = walk[pos]
            lo = max(0, pos - T)
            hi = min(L, pos + T + 1)
            for ctx in range(lo, hi):
                if ctx == pos:
                    continue
                cooc[wc, walk[ctx]] += 1.0

    cooc = (cooc + cooc.T) / 2.0  # enforce symmetry

    # 3. Build the shifted positive PMI matrix.
    total = cooc.sum()
    if total <= 0:
        C = min(n_components, n - 1)
        return {"embedding": np.zeros((n, C)).tolist(), "n_nodes": n,
                "n_components": int(C), "method": f"uniform_walk_ppmi(T={T})"}
    row = cooc.sum(axis=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        # p(i,j) = cooc_ij / total ; p(i) = row_i / total
        pmi = np.log((cooc * total) / (np.outer(row, row) + 1e-12) + 1e-12)
    pmi = pmi - np.log(max(neg_samples, 1))
    ppmi = np.maximum(pmi, 0.0)  # positive PMI

    # 4. Truncated eigen-factorization of the (symmetric) PPMI matrix.
    eigenvalues, eigenvectors = np.linalg.eigh(ppmi)
    C = min(n_components, n - 1)
    idx = np.argsort(-eigenvalues)[:C]
    pos = eigenvalues[idx].clip(min=0.0)
    embedding = eigenvectors[:, idx] * np.sqrt(pos)[None, :]

    return {
        "embedding": embedding.tolist(),
        "n_nodes": n,
        "n_components": int(C),
        "method": f"uniform_walk_ppmi(T={T})",
        "n_walks": len(walks),
    }


@mcp.tool()
def verify_spectral_equivalence(adjacency: dict, window_size: int = 10,
                                n_components: int = 8, seed: int = 42) -> dict:
    """Empirical APPROXIMATION check of the node2vec / normalized-Laplacian
    equivalence (NOT a proof of the paper's theorem).

    Important scope note. The paper PROVES, analytically, an EXACT equivalence
    between the spectrum of the *expected* node2vec matrix ``R^{n2v}`` and the
    symmetric normalized Laplacian (Eq. 9 below). This function does NOT
    reproduce that proof. Instead it runs a finite, empirical, sampling-based
    sanity check: it (i) builds a node2vec embedding by factorizing the
    empirical PPMI matrix estimated from a *finite* number of sampled random
    walks (so it is the realised/empirical node2vec matrix, not the expected
    one), (ii) builds the analytical normalized-Laplacian spectral embedding,
    and (iii) measures how well the two embedding subspaces align (mean
    absolute canonical correlation of the leading components). A high alignment
    is *consistent with* the paper's theorem and shows the empirical embedding
    approximates the spectral subspace, but it does not establish the exact
    equivalence: perfect alignment would only be expected in the
    infinite-walk limit, and at finite sample sizes / window sizes the score is
    strictly an approximation that depends on ``num_walks``, ``walk_length``,
    ``window_size`` and ``seed``.

    Degree scaling. The paper's Eq. (9) states the exact relationship between
    the eigenvectors of the two operators as ``U = D^{1/2} Gamma`` where ``U``
    are the eigenvectors of the node2vec matrix ``R^{n2v}`` and ``Gamma`` are
    the eigenvectors of the symmetric normalized Laplacian
    ``L = I - D^{-1/2} A D^{-1/2}``. Hence the *eigenvectors of the node2vec
    matrix are the Laplacian eigenvectors rescaled by ``D^{1/2}``* (positive
    half-power), not ``Gamma`` itself. This function therefore left-multiplies
    the Laplacian spectral embedding by ``D^{1/2}`` before the subspace
    comparison, so the analytical Laplacian basis is placed on the same
    footing as the node2vec eigenvectors the theorem predicts. (Without this
    rescaling the alignment is only an approximate check; the boolean
    ``degree_scaled`` flag in the return value records which convention was
    used.) Even with this rescaling, the returned correlation is an empirical
    approximation score, not a verification of the analytical theorem.

    Args:
        adjacency: Output of ``build_adjacency_matrix``.
        window_size: node2vec context window T.
        n_components: Number of leading components to compare.
        seed: Random seed.

    Returns:
        dict with ``mean_canonical_correlation`` and per-component values.
    """
    n2v = uniform_walk_ppmi_embedding(adjacency, n_components=n_components,
                             window_size=window_size, seed=seed)
    lap = compute_normalized_laplacian(adjacency)
    spec = spectral_embedding(lap, n_components=n_components)

    X = np.array(n2v["embedding"])
    Y = np.array(spec["embedding"])

    # Apply the D^{1/2} degree scaling to the Laplacian eigenvectors so that
    # Y matches the node2vec-matrix eigenvectors U = D^{1/2} Gamma (paper Eq. 9).
    d = np.array(adjacency["degrees"], dtype=float)
    d_sqrt = np.sqrt(np.clip(d, 0.0, None))
    Y = Y * d_sqrt[:, None]

    C = min(X.shape[1], Y.shape[1])
    X, Y = X[:, :C], Y[:, :C]

    # Orthonormal bases of each subspace, then principal angles via SVD.
    def orthonormal(M):
        q, _ = np.linalg.qr(M)
        return q
    Qx, Qy = orthonormal(X), orthonormal(Y)
    s = np.linalg.svd(Qx.T @ Qy, compute_uv=False)
    s = np.clip(s, 0.0, 1.0)
    return {
        "mean_canonical_correlation": float(np.mean(s)),
        "canonical_correlations": s.tolist(),
        "n_components": int(C),
        "degree_scaled": True,
    }


@mcp.tool()
def deepwalk_embedding(adjacency: dict, n_components: int = 64,
                       window_size: int = 10, seed: int = 42) -> dict:
    """Compute DeepWalk embedding via matrix factorization.

    DeepWalk (Perozzi et al. 2014) generates uniform random walks and
    trains skip-gram. The paper (Eqs. 10-15) proves DeepWalk factorizes
    R^{DW} = (n/T) sum_{t=1}^{T} (D^{-1}A)^t - 1, whose eigenvectors
    are obtained from those of the normalized Laplacian by D^{1/2} and
    D^{-1/2} scalings. DeepWalk shares the same detectability limit as
    node2vec.

    Args:
        adjacency: Output of ``build_adjacency_matrix``.
        n_components: Embedding dimension.
        window_size: Context window T.
        seed: Random seed.

    Returns:
        dict with ``embedding``, ``method``.
    """
    A = np.array(adjacency["adjacency"])
    n = A.shape[0]
    d = np.array(adjacency["degrees"])

    # Transition matrix P = D^{-1} A
    d_inv = np.where(d > 0, 1.0 / d, 0.0)

    # Compute sum of powers of transition matrix
    T = window_size
    P = np.diag(d_inv) @ A
    P_power = np.eye(n)
    R_sum = np.zeros((n, n))
    for t in range(1, T + 1):
        P_power = P_power @ P
        R_sum += P_power

    R_DW = (float(n) / T) * R_sum - np.ones((n, n))

    # Symmetrize: R_sym = (R + R^T) / 2
    R_sym = (R_DW + R_DW.T) / 2.0

    eigenvalues, eigenvectors = np.linalg.eigh(R_sym)
    C = min(n_components, n - 1)
    # Top C by magnitude (skip trivial)
    idx = np.argsort(-np.abs(eigenvalues))[:C]
    weights = np.sqrt(np.abs(eigenvalues[idx]))
    embedding = eigenvectors[:, idx] * weights[None, :]

    return {
        "embedding": embedding.tolist(),
        "n_nodes": n,
        "n_components": int(C),
        "method": f"DeepWalk(T={window_size})",
    }


# ---------------------------------------------------------------------------
# 4. Clustering
# ---------------------------------------------------------------------------

@mcp.tool()
def kmeans_clustering(embedding: dict, n_clusters: int,
                      n_init: int = 10, seed: int = 42,
                      normalize: bool = True) -> dict:
    """Run K-means clustering on node embeddings.

    By default each embedding row is L2-normalized to the unit sphere before
    clustering (``normalize=True``). This is the standard practice for
    spectral and skip-gram/node2vec embeddings (cf. Ng-Jordan-Weiss spectral
    clustering): community structure is encoded in the *direction* of each
    node vector, while the magnitude reflects degree/centrality, so
    normalizing makes K-means recover the community partition rather than
    splitting by node magnitude. Set ``normalize=False`` to cluster the raw
    embedding.

    Args:
        embedding: dict with ``embedding`` key (n x C nested list).
        n_clusters: Number of clusters K.
        n_init: Number of random restarts.
        seed: Random seed.
        normalize: L2-normalize each embedding row before clustering.

    Returns:
        dict with ``labels`` (list of cluster assignments),
        ``inertia`` (float), ``n_clusters`` (int).
    """
    from sklearn.cluster import KMeans

    X = np.array(embedding["embedding"], dtype=float)
    if normalize and X.size:
        norms = np.linalg.norm(X, axis=1, keepdims=True)
        X = X / (norms + 1e-12)
    km = KMeans(n_clusters=n_clusters, n_init=n_init,
                random_state=seed, max_iter=300)
    km.fit(X)
    return {
        "labels": km.labels_.tolist(),
        "inertia": float(km.inertia_),
        "n_clusters": n_clusters,
    }


@mcp.tool()
def voronoi_clustering(embedding: dict, ground_truth: dict) -> dict:
    """Voronoi clustering: assign each node to the closest ground-truth
    community centroid.

    This is the "best-case" scenario for K-means, where cluster centroids
    are set to the true community centroids. Used to separate the quality
    of the embedding from the quality of the clustering step.

    Args:
        embedding: dict with ``embedding`` (n x C list).
        ground_truth: dict mapping node_id (int) -> community (int).

    Returns:
        dict with ``labels`` (list of cluster assignments).
    """
    X = np.array(embedding["embedding"])
    n = X.shape[0]
    node_ids = sorted(ground_truth.keys())
    gt_array = np.array([ground_truth[nid] for nid in node_ids])
    communities = sorted(set(gt_array))

    # Compute centroids of true communities
    centroids = []
    for c in communities:
        mask = gt_array == c
        centroids.append(X[mask].mean(axis=0))
    centroids = np.array(centroids)

    # Assign each node to closest centroid
    labels = []
    for i in range(n):
        dists = np.linalg.norm(centroids - X[i], axis=1)
        labels.append(int(communities[np.argmin(dists)]))

    return {"labels": labels, "n_clusters": len(communities)}


@mcp.tool()
def estimate_n_clusters_silhouette(embedding: dict, k_range: list = None,
                                   seed: int = 42) -> dict:
    """Estimate optimal number of clusters using silhouette score.

    As described in the paper (ref 77), the silhouette score is used to
    estimate q when the number of communities is unknown.

    Args:
        embedding: dict with ``embedding`` (n x C list).
        k_range: List of K values to try [2..20].
        seed: Random seed.

    Returns:
        dict with ``best_k``, ``scores`` (dict k->score).
    """
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score

    X = np.array(embedding["embedding"])
    if k_range is None:
        k_range = list(range(2, min(21, X.shape[0])))

    scores = {}
    for k in k_range:
        km = KMeans(n_clusters=k, n_init=10, random_state=seed, max_iter=300)
        labels = km.fit_predict(X)
        if len(set(labels)) < 2:
            scores[k] = -1.0
        else:
            scores[k] = float(silhouette_score(X, labels))

    best_k = max(scores, key=scores.get)
    return {"best_k": int(best_k), "scores": {int(k): float(v) for k, v in scores.items()}}


# ---------------------------------------------------------------------------
# 5. Evaluation metrics
# ---------------------------------------------------------------------------

@mcp.tool()
def element_centric_similarity(labels_pred: list, labels_true: list,
                               adjusted: bool = True, n_perm: int = 200,
                               seed: int = 0) -> dict:
    """Compute the (baseline-corrected) element-centric similarity S.

    This is the primary evaluation metric used in the paper (Kojaku et al.
    2024; the underlying metric is Gates et al. 2019, "Element-centric
    clustering comparison").

    For HARD partitions, element i induces a cluster-affinity distribution
    p_i over all elements: p_ij = 1/|C(i)| for j in i's cluster C(i), else 0.
    The per-element *raw* similarity between the predicted and true partitions
    is

        S_i^raw = 1 - (1/2) * sum_j | p_ij - p'_ij |,   S_raw = mean_i S_i^raw.

    S_raw = 1 for identical partitions, but it is strictly positive in
    expectation for two independent random partitions (e.g. ~0.5 for two
    balanced 2-clusterings), so a raw score cannot be compared against a
    "chance = 0" baseline. The paper therefore applies a baseline correction
    (Kojaku et al. 2024, Supporting Information Section 1) so that a *random
    shuffling* of the community memberships yields S = 0 on expectation:

        S = (S_raw - E[S_random]) / (1 - E[S_random]).

    Here E[S_random] is the expected raw ECS under random relabelling,
    estimated by Monte-Carlo permutation of the predicted labels. With this
    correction S = 0 is the trivial/chance baseline and S > 0 means the
    partition recovers community structure better than random guessing.
    Set ``adjusted=False`` to obtain the uncorrected raw ECS instead.

    Args:
        labels_pred: Predicted community labels (list of ints).
        labels_true: True community labels (list of ints).
        adjusted: If True (default) return the baseline-corrected S used by
            the paper; if False return the raw Gates-et-al. ECS.
        n_perm: Number of permutations for estimating E[S_random].
        seed: Random seed for the permutation baseline.

    Returns:
        dict with ``similarity`` (corrected S; <=1, =0 at chance),
        ``raw_similarity`` (uncorrected), ``expected_random`` (baseline),
        ``per_node_similarity``, ``n_nodes``,
        ``n_pred_clusters``, ``n_true_clusters``.
    """
    pred = np.array(labels_pred)
    true = np.array(labels_true)
    n = len(pred)
    if n == 0:
        return {"similarity": 0.0, "raw_similarity": 0.0,
                "expected_random": 0.0, "per_node_similarity": [],
                "n_nodes": 0, "n_pred_clusters": 0, "n_true_clusters": 0}

    res = _element_centric_similarity_impl(labels_pred, labels_true,
                                           adjusted=adjusted, n_perm=n_perm,
                                           seed=seed)
    res["n_pred_clusters"] = int(len(set(pred.tolist())))
    res["n_true_clusters"] = int(len(set(true.tolist())))
    res.setdefault("raw_similarity", res["similarity"])
    res.setdefault("expected_random", 0.0)
    return res


@mcp.tool()
def normalized_mutual_information(labels_pred: list, labels_true: list) -> dict:
    """Compute Normalized Mutual Information (NMI) between two partitions.

    NMI = 2*I(pred;true) / (H(pred) + H(true)), where I is mutual
    information and H is entropy.

    Args:
        labels_pred: Predicted cluster labels.
        labels_true: True cluster labels.

    Returns:
        dict with ``nmi`` (float in [0,1]).
    """
    from sklearn.metrics import normalized_mutual_info_score
    nmi = normalized_mutual_info_score(labels_true, labels_pred, average_method="arithmetic")
    return {"nmi": float(nmi), "n_nodes": len(labels_pred)}


@mcp.tool()
def adjusted_rand_index(labels_pred: list, labels_true: list) -> dict:
    """Compute Adjusted Rand Index (ARI) between two partitions.

    ARI corrects the Rand index for chance. ARI = 1 for perfect
    agreement, ARI ≈ 0 for random partitions.

    Args:
        labels_pred: Predicted cluster labels.
        labels_true: True cluster labels.

    Returns:
        dict with ``ari`` (float).
    """
    from sklearn.metrics import adjusted_rand_score
    ari = adjusted_rand_score(labels_true, labels_pred)
    return {"ari": float(ari), "n_nodes": len(labels_pred)}


# ---------------------------------------------------------------------------
# 6. Detectability analysis
# ---------------------------------------------------------------------------

@mcp.tool()
def compute_detectability_limit(avg_degree: float) -> dict:
    """Compute the information-theoretic detectability limit for the PPM.

    From Eq. (1) in the paper:  mu* = 1 - 1 / sqrt(<k>)

    Communities are detectable (S > 0) for mu < mu*, and undetectable
    (S = 0) for mu >= mu*.

    Args:
        avg_degree: Average degree <k> of the network.

    Returns:
        dict with ``mu_star`` (critical mixing parameter),
        ``interpretation`` (string).
    """
    mu_star = 1.0 - 1.0 / np.sqrt(avg_degree)
    return {
        "mu_star": float(mu_star),
        "avg_degree": float(avg_degree),
        "interpretation": (
            f"For <k>={avg_degree:.1f}, communities are detectable "
            f"when mixing parameter mu < {mu_star:.4f}. "
            f"Above mu*={mu_star:.4f}, communities cannot be "
            f"distinguished from random partitions by any algorithm."
        ),
    }


@mcp.tool()
def generate_planted_partition_model(n: int, q: int, avg_degree: float,
                                     mu: float, seed: int = 42) -> dict:
    """Generate a synthetic network from the Planted Partition Model (PPM).

    The PPM is a special case of the SBM with q equal-sized communities.
    Nodes connect with probability p_in within communities and p_out
    between communities. The mixing parameter mu = n*p_out/<k> controls
    community separation.

    Args:
        n: Number of nodes.
        q: Number of communities.
        avg_degree: Target average degree <k>.
        mu: Mixing parameter (0=well separated, 1=random graph).
        seed: Random seed.

    Returns:
        dict compatible with ``build_adjacency_matrix`` input format,
        plus ``ground_truth``.
    """
    rng = np.random.RandomState(seed)
    community_size = n // q
    ground_truth = {}
    for c in range(q):
        for i in range(c * community_size, (c + 1) * community_size):
            ground_truth[i] = c

    # p_in and p_out from avg_degree and mu
    p_out = mu * avg_degree / n
    p_in = avg_degree / community_size - p_out * (q - 1) * community_size / community_size
    if p_in < 0:
        p_in = 0.0

    edges = []
    for i in range(n):
        for j in range(i + 1, n):
            ci, cj = ground_truth[i], ground_truth[j]
            p = p_in if ci == cj else p_out
            if rng.random() < p:
                edges.append([i, j])

    node_labels = {i: f"node_{i}" for i in range(n)}
    return {
        "n_nodes": n,
        "n_edges": len(edges),
        "n_communities": q,
        "edges": edges,
        "node_labels": node_labels,
        "ground_truth": ground_truth,
        "community_names": list(range(q)),
        "mu": mu,
        "p_in": float(p_in),
        "p_out": float(p_out),
    }


@mcp.tool()
def sweep_mixing_parameter(n: int, q: int, avg_degree: float,
                           mu_values: list, embedding_method: str = "spectral",
                           n_components: int = 64, seed: int = 42) -> dict:
    """Run community detection across a range of mixing parameters.

    For each mu, generate a PPM network, compute the specified embedding,
    cluster with K-means, and evaluate element-centric similarity.

    Args:
        n: Number of nodes per network.
        q: Number of communities.
        avg_degree: Average degree.
        mu_values: List of mu values to test (e.g. [0.0, 0.1, ..., 1.0]).
        embedding_method: One of "spectral", "modularity", "adjacency",
            "node2vec" (the uniform-walk PPMI embedding) or "deepwalk".
        n_components: Embedding dimension.
        seed: Random seed.

    Returns:
        dict with ``mu_values``, ``similarities`` (list of S values),
        ``mu_star`` (theoretical detectability limit).
    """
    mu_star = 1.0 - 1.0 / np.sqrt(avg_degree)
    similarities = []

    for mu in mu_values:
        ppm = generate_planted_partition_model(n, q, avg_degree, mu, seed=seed)
        adj = _build_adjacency_matrix_impl(ppm)

        if embedding_method == "spectral":
            lap = _compute_normalized_laplacian_impl(adj)
            emb = _spectral_embedding_impl(lap, n_components=n_components)
        elif embedding_method == "modularity":
            emb = _modularity_spectral_embedding_impl(adj, n_components=n_components)
        elif embedding_method == "adjacency":
            emb = _adjacency_spectral_embedding_impl(adj, n_components=n_components)
        elif embedding_method == "node2vec":
            # node2vec representative = uniform-walk PPMI embedding (p=q=1).
            emb = _uniform_walk_ppmi_embedding_impl(adj, n_components=n_components,
                                                    seed=seed)
        elif embedding_method == "deepwalk":
            emb = _deepwalk_embedding_impl(adj, n_components=n_components, seed=seed)
        else:
            raise ValueError(f"Unknown method: {embedding_method}")

        clust = _kmeans_clustering_impl(emb, n_clusters=q, seed=seed)

        gt_labels = [ppm["ground_truth"][i] for i in range(n)]
        ecs = _element_centric_similarity_impl(clust["labels"], gt_labels)
        similarities.append(ecs["similarity"])

    return {
        "mu_values": mu_values,
        "similarities": similarities,
        "mu_star": float(mu_star),
        "avg_degree": float(avg_degree),
        "embedding_method": embedding_method,
    }


# ---------------------------------------------------------------------------
# 7. Network statistics
# ---------------------------------------------------------------------------

@mcp.tool()
def compute_network_statistics(adjacency: dict) -> dict:
    """Compute basic network statistics.

    Args:
        adjacency: Output of ``build_adjacency_matrix``.

    Returns:
        dict with ``n_nodes``, ``n_edges``, ``avg_degree``,
        ``degree_std``, ``density``, ``degree_distribution`` (counts).
    """
    A = np.array(adjacency["adjacency"])
    n = A.shape[0]
    degrees = A.sum(axis=1)
    n_edges = int(A.sum() / 2)
    avg_deg = float(degrees.mean())
    std_deg = float(degrees.std())
    density = 2.0 * n_edges / (n * (n - 1)) if n > 1 else 0.0

    unique, counts = np.unique(degrees.astype(int), return_counts=True)
    degree_dist = {int(k): int(v) for k, v in zip(unique, counts)}

    return {
        "n_nodes": n,
        "n_edges": n_edges,
        "avg_degree": avg_deg,
        "degree_std": std_deg,
        "density": density,
        "degree_distribution": degree_dist,
    }


@mcp.tool()
def compute_community_mixing_matrix(network: dict) -> dict:
    """Compute the edge mixing matrix between ground-truth communities.

    Entry (i,j) gives the fraction of edges between community i and j.
    Diagonal entries are within-community edge fractions.

    Args:
        network: Output of ``load_network``.

    Returns:
        dict with ``mixing_matrix`` (2-D list), ``communities`` (list),
        ``within_fraction`` (fraction of edges within communities),
        ``between_fraction`` (fraction of edges between communities).
    """
    gt = network["ground_truth"]
    comms = sorted(set(gt.values()))
    c_to_idx = {c: i for i, c in enumerate(comms)}
    q = len(comms)
    M = np.zeros((q, q))

    for s, t in network["edges"]:
        ci = c_to_idx.get(gt.get(int(s)), None)
        cj = c_to_idx.get(gt.get(int(t)), None)
        if ci is not None and cj is not None:
            M[ci, cj] += 1
            M[cj, ci] += 1

    total = M.sum()
    if total > 0:
        M /= total

    within = float(np.trace(M))
    between = float(1.0 - within)

    return {
        "mixing_matrix": M.tolist(),
        "communities": comms,
        "within_fraction": within,
        "between_fraction": between,
    }


# ---------------------------------------------------------------------------
# 8. Plotting tools
# ---------------------------------------------------------------------------

@mcp.tool()
def plot_embedding_2d(embedding: dict, ground_truth: dict,
                      title: str = "Node Embedding (2D PCA)",
                      output_dir: str = "artifacts") -> dict:
    """Plot 2-D PCA projection of node embeddings, colored by community.

    Args:
        embedding: dict with ``embedding`` (n x C list).
        ground_truth: dict node_id->community.
        title: Plot title.
        output_dir: Directory to save the figure.

    Returns:
        dict with ``path`` to the saved PNG.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.decomposition import PCA

    X = np.array(embedding["embedding"])
    node_ids = sorted(ground_truth.keys())
    labels = np.array([ground_truth[nid] for nid in node_ids])

    if X.shape[1] > 2:
        pca = PCA(n_components=2)
        X2 = pca.fit_transform(X)
    else:
        X2 = X[:, :2]

    communities = sorted(set(labels))
    fig, ax = plt.subplots(figsize=(8, 6))
    for c in communities:
        mask = labels == c
        ax.scatter(X2[mask, 0], X2[mask, 1], s=20, alpha=0.7, label=f"Comm {c}")
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.set_title(title)
    ax.legend(fontsize=8, ncol=2)

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "embedding_2d.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(path)}


@mcp.tool()
def plot_method_comparison(results: dict, network_name: str = "Network",
                           output_dir: str = "artifacts") -> dict:
    """Bar chart comparing element-centric similarity across methods.

    Args:
        results: dict mapping method_name -> similarity score (float).
        network_name: Name for the plot title.
        output_dir: Directory to save the figure.

    Returns:
        dict with ``path`` to the saved PNG.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    methods = list(results.keys())
    scores = [results[m] for m in methods]

    fig, ax = plt.subplots(figsize=(10, 5))
    colors = plt.cm.Set2(np.linspace(0, 1, len(methods)))
    bars = ax.bar(range(len(methods)), scores, color=colors)
    ax.set_xticks(range(len(methods)))
    ax.set_xticklabels(methods, rotation=45, ha="right", fontsize=9)
    ax.set_ylabel("Element-centric Similarity (S)")
    ax.set_title(f"Community Detection Performance: {network_name}")
    ax.set_ylim(0, 1.05)

    for bar, score in zip(bars, scores):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                f"{score:.3f}", ha="center", va="bottom", fontsize=8)

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, f"method_comparison_{network_name.lower().replace(' ', '_')}.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(path)}


@mcp.tool()
def plot_detectability_curves(sweep_results: list,
                              output_dir: str = "artifacts") -> dict:
    """Plot element-centric similarity vs mixing parameter mu for
    multiple embedding methods on PPM networks.

    Includes a vertical dashed line at the theoretical detectability
    limit mu* = 1 - 1/sqrt(<k>).

    Args:
        sweep_results: List of dicts from ``sweep_mixing_parameter``.
        output_dir: Directory to save the figure.

    Returns:
        dict with ``path`` to the saved PNG.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 6))
    colors = plt.cm.tab10(np.linspace(0, 1, len(sweep_results)))

    for i, res in enumerate(sweep_results):
        ax.plot(res["mu_values"], res["similarities"],
                marker="o", markersize=4, color=colors[i],
                label=res.get("embedding_method", f"Method {i}"))

    # Plot detectability limit
    if sweep_results:
        mu_star = sweep_results[0].get("mu_star", 0.5)
        ax.axvline(mu_star, color="gray", linestyle="--", linewidth=1.5,
                   label=f"$\\mu^*$ = {mu_star:.3f}")

    ax.set_xlabel("Mixing parameter $\\mu$")
    ax.set_ylabel("Element-centric similarity (S)")
    ax.set_title("Detectability of Communities on PPM Networks")
    ax.set_xlim(0, 1)
    ax.set_ylim(-0.05, 1.05)
    ax.legend(fontsize=9)

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "detectability_curves.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(path)}


@mcp.tool()
def plot_multi_network_comparison(all_results: dict,
                                  output_dir: str = "artifacts") -> dict:
    """Multi-panel figure comparing methods across multiple empirical networks.

    Args:
        all_results: dict mapping network_name -> {method_name -> score}.
        output_dir: Directory to save the figure.

    Returns:
        dict with ``path`` to the saved PNG.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    networks = list(all_results.keys())
    if not networks:
        return {"path": "", "error": "No results to plot"}

    methods = sorted(set(m for res in all_results.values() for m in res))
    n_nets = len(networks)
    n_methods = len(methods)

    fig, axes = plt.subplots(1, n_nets, figsize=(5 * n_nets, 5), squeeze=False)
    colors = plt.cm.Set2(np.linspace(0, 1, n_methods))

    # Determine a common y-range that keeps any negative baseline-corrected
    # similarities visible (baseline-corrected S can go below 0 when a method
    # performs worse than a random relabelling).
    all_scores = [all_results[net].get(m, 0.0)
                  for net in networks for m in methods]
    y_min = min(0.0, min(all_scores)) if all_scores else 0.0
    y_lo = y_min - 0.05 if y_min < 0 else 0.0

    for col, net in enumerate(networks):
        ax = axes[0, col]
        scores = [all_results[net].get(m, 0) for m in methods]
        bars = ax.bar(range(n_methods), scores, color=colors)
        ax.set_xticks(range(n_methods))
        ax.set_xticklabels(methods, rotation=45, ha="right", fontsize=7)
        ax.set_ylabel("Baseline-corrected Element-centric Similarity")
        ax.set_title(net, fontsize=11)
        ax.set_ylim(y_lo, 1.05)
        ax.axhline(0.0, color="gray", lw=0.7, ls="--")

    fig.suptitle("Community Detection: Method Comparison Across Networks", fontsize=13)
    fig.tight_layout(rect=[0, 0, 1, 0.96])

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "multi_network_comparison.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(path)}


@mcp.tool()
def plot_graph_kernel(eigenvalues: list, window_sizes: list = None,
                      output_dir: str = "artifacts") -> dict:
    """Plot the graph kernel phi(lambda; T) of the node2vec matrix.

    From Eq. (8) in the paper:
    phi(lambda_i) = (2m/T) * sum_{t=1}^{T} (1 - lambda_i)^t
    which is non-negative for 0 < lambda_i <= 1 and monotonically
    decreasing for 1 < lambda_i <= 2.

    Args:
        eigenvalues: Eigenvalues of the normalized Laplacian.
        window_sizes: List of window sizes T to plot. Default [3,5,10,25,50,100].
        output_dir: Directory for output.

    Returns:
        dict with ``path`` to the saved PNG.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if window_sizes is None:
        window_sizes = [3, 5, 10, 25, 50, 100]

    lam = np.array(eigenvalues)
    lam = lam[(lam > 0) & (lam <= 2)]
    lam_sorted = np.sort(lam)

    fig, ax = plt.subplots(figsize=(8, 5))
    for T in window_sizes:
        phi = np.zeros_like(lam_sorted)
        for t in range(1, T + 1):
            phi += (1 - lam_sorted) ** t
        phi *= 2.0 / T  # normalize
        ax.plot(lam_sorted, phi, label=f"T={T}")

    ax.set_xlabel("$\\lambda_i$")
    ax.set_ylabel("$\\phi(\\lambda_i; T)$")
    ax.set_title("Graph kernel of node2vec matrix $\\mathbf{R}^{\\mathrm{n2v}}$")
    ax.legend()
    ax.axhline(0, color="gray", linewidth=0.5)

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "graph_kernel.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return {"path": os.path.abspath(path)}


# ---------------------------------------------------------------------------
# 9. Deterministic end-to-end driver for the four-network comparison
# ---------------------------------------------------------------------------

# Fixed, deterministic experiment configuration for the bundled four-network
# reproduction. Every random operation below is seeded with EXPERIMENT_SEED so
# the result table and figures regenerate bit-for-bit.
EXPERIMENT_SEED = 42
EMBED_DIM = 64
N2V_WINDOW = 10
N2V_NUM_WALKS = 10
N2V_WALK_LENGTH = 80
ECS_N_PERM = 200
FOUR_NETWORKS = ["football", "karate", "polbooks", "polblogs"]
NETWORK_DISPLAY = {
    "football": "Football",
    "karate": "Karate",
    "polbooks": "Political Books",
    "polblogs": "Political Blog",
}


@mcp.tool()
def run_four_network_comparison(data_dir: str = "input_data/data",
                                output_dir: str = "artifacts",
                                seed: int = EXPERIMENT_SEED) -> dict:
    """Deterministic end-to-end driver for the bundled four-network community
    detection comparison (Football, Karate, Political Books, Political Blog).

    This reproduces the headline bundled experiment with FIXED parameters and a
    FIXED random seed so the output table and figures are deterministic:

      * embedding dimension C = 64 for the random-walk embeddings
        (node2vec / DeepWalk)
      * the spectral baselines (L-EigenMap, modularity, adjacency) use the
        leading C = q components (q = number of ground-truth communities),
        which is the standard dimensionality for spectral community detection.
        Using the full 64-dimensional spectral embedding instead drowns the
        q-dimensional community signal in high-frequency eigenvectors and makes
        the spectral baselines collapse to ~chance -- that is an unfair,
        broken baseline, not a property of spectral clustering, so this driver
        does NOT do that.
      * uniform-walk PPMI ("node2vec") and DeepWalk window T = 10,
        num_walks = 10, walk_length = 80
      * K-means with q = number of ground-truth communities, row-normalized
        embeddings, n_init = 10
      * baseline-corrected element-centric similarity (S = 0 at chance),
        n_perm = 200

    Methods compared per network: ``node2vec`` (uniform-walk PPMI embedding),
    ``deepwalk``, ``L-EigenMap`` (normalized-Laplacian spectral), ``modularity``
    and ``adjacency`` spectral. All five methods use a comparable,
    fairly-tuned setup (spectral at its standard C = q dimensionality), so the
    cross-method comparison is a fair [PIPELINE] reproduction. The spectral
    baselines here are NOT a deliberately weakened lower bound; they are
    competitive with the random-walk embeddings on most networks, consistent
    with the paper's qualitative ranking. The exact per-network paper numbers
    (paper Fig. 3, which uses additional tuned/non-backtracking spectral
    setups) remain a [PAPER] result, not something this small driver
    reproduces digit-for-digit.

    Side effects:
      * writes ``four_network_comparison.csv`` (the result TABLE: one row per
        (network, method) with baseline-corrected and raw ECS),
      * writes ``multi_network_comparison.png`` (the comparison bar chart,
        y-axis shows negative corrected S where present),
      * writes ``embedding_2d.png`` (2-D PCA of the football node2vec
        embedding, colored by ground-truth conference).

    Args:
        data_dir: directory containing the ``<name>_edges.csv`` /
            ``<name>_nodes.csv`` files.
        output_dir: directory for the CSV table and PNG figures.
        seed: master random seed (default 42).

    Returns:
        dict with ``results`` (network -> method -> corrected S),
        ``table_path``, ``comparison_path``, ``embedding_path``.
    """
    os.makedirs(output_dir, exist_ok=True)
    methods = ["node2vec", "deepwalk", "L-EigenMap", "modularity", "adjacency"]
    all_results: dict = {}
    table_rows: list = []
    football_n2v_emb = None
    football_gt = None

    for name in FOUR_NETWORKS:
        edges_csv = os.path.join(data_dir, f"{name}_edges.csv")
        nodes_csv = os.path.join(data_dir, f"{name}_nodes.csv")
        net = load_network(edges_csv, nodes_csv)
        adj = build_adjacency_matrix(net)
        q = net["n_communities"]
        node_ids = adj["node_ids"]
        gt_labels = [net["ground_truth"][nid] for nid in node_ids]

        # Build each embedding deterministically.
        embeddings: dict = {}
        embeddings["node2vec"] = uniform_walk_ppmi_embedding(
            adj, n_components=EMBED_DIM, window_size=N2V_WINDOW,
            num_walks=N2V_NUM_WALKS, walk_length=N2V_WALK_LENGTH, seed=seed)
        embeddings["deepwalk"] = deepwalk_embedding(
            adj, n_components=EMBED_DIM, window_size=N2V_WINDOW, seed=seed)
        # Spectral baselines use the standard C = q dimensionality for
        # community detection (NOT the full 64-dim embedding, which would
        # bury the community signal in high-frequency eigenvectors and turn
        # the baselines into an unfair ~chance lower bound).
        lap = compute_normalized_laplacian(adj)
        embeddings["L-EigenMap"] = spectral_embedding(lap, n_components=q)
        embeddings["modularity"] = modularity_spectral_embedding(
            adj, n_components=q)
        embeddings["adjacency"] = adjacency_spectral_embedding(
            adj, n_components=q)

        if name == "football":
            football_n2v_emb = embeddings["node2vec"]
            football_gt = net["ground_truth"]

        net_scores: dict = {}
        for m in methods:
            clust = kmeans_clustering(embeddings[m], n_clusters=q,
                                      seed=seed, normalize=True)
            ecs = element_centric_similarity(clust["labels"], gt_labels,
                                             adjusted=True, n_perm=ECS_N_PERM,
                                             seed=seed)
            net_scores[m] = float(ecs["similarity"])
            table_rows.append({
                "network": NETWORK_DISPLAY[name],
                "method": m,
                "n_nodes": net["n_nodes"],
                "n_communities": q,
                "corrected_S": round(float(ecs["similarity"]), 4),
                "raw_S": round(float(ecs.get("raw_similarity",
                                             ecs["similarity"])), 4),
                "expected_random": round(float(ecs.get("expected_random",
                                                        0.0)), 4),
            })
        all_results[NETWORK_DISPLAY[name]] = net_scores

    # Write the result table.
    import csv as _csv
    table_path = os.path.join(output_dir, "four_network_comparison.csv")
    fieldnames = ["network", "method", "n_nodes", "n_communities",
                  "corrected_S", "raw_S", "expected_random"]
    with open(table_path, "w", newline="") as f:
        w = _csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(table_rows)

    # Comparison figure (y-axis keeps negative corrected S visible).
    comp = plot_multi_network_comparison(all_results, output_dir=output_dir)
    # Football node2vec embedding 2-D projection.
    emb_fig = plot_embedding_2d(
        football_n2v_emb, football_gt,
        title="node2vec (uniform-walk PPMI) embedding of Football (2D PCA)",
        output_dir=output_dir)

    return {
        "results": all_results,
        "table_path": os.path.abspath(table_path),
        "comparison_path": comp.get("path", ""),
        "embedding_path": emb_fig.get("path", ""),
        "config": {
            "seed": seed, "embed_dim": EMBED_DIM, "window": N2V_WINDOW,
            "num_walks": N2V_NUM_WALKS, "walk_length": N2V_WALK_LENGTH,
            "ecs_n_perm": ECS_N_PERM, "kmeans_normalize": True,
        },
    }


if __name__ == "__main__":
    mcp.run()
