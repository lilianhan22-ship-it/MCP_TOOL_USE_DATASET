#!/usr/bin/env python3
"""Data processing utilities for network community detection tasks.

Shared helpers for loading CSVs, converting between network formats,
and preparing data for analysis.
"""

from __future__ import annotations

import os
from typing import Any

import numpy as np
import pandas as pd
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Network_Data_Processing")


@mcp.tool()
def list_data_files(data_dir: str) -> dict:
    """List all CSV files in the data directory.

    Args:
        data_dir: Path to the data directory.

    Returns:
        dict with ``files`` (list of filenames), ``networks`` (list of
        network names extracted from filenames).
    """
    files = sorted(f for f in os.listdir(data_dir) if f.endswith(".csv"))
    # Extract network names: "football_edges.csv" -> "football"
    networks = sorted(set(f.rsplit("_", 1)[0] for f in files))
    return {"files": files, "networks": networks, "data_dir": data_dir}


@mcp.tool()
def inspect_csv(csv_path: str, n_rows: int = 5) -> dict:
    """Preview a CSV file's structure.

    Args:
        csv_path: Path to the CSV file.
        n_rows: Number of rows to preview.

    Returns:
        dict with ``columns``, ``n_rows``, ``dtypes``, ``head`` (first rows).
    """
    df = pd.read_csv(csv_path)
    return {
        "columns": df.columns.tolist(),
        "n_rows": int(len(df)),
        "dtypes": {c: str(df[c].dtype) for c in df.columns},
        "head": df.head(n_rows).to_dict(orient="records"),
    }


@mcp.tool()
def merge_node_edge_data(edges_csv: str, nodes_csv: str) -> dict:
    """Load and validate edge+node CSVs, reporting any inconsistencies.

    Checks that all node IDs in the edge list appear in the node file,
    and reports the community distribution.

    Args:
        edges_csv: Path to edge-list CSV.
        nodes_csv: Path to node-attribute CSV.

    Returns:
        dict with ``n_nodes``, ``n_edges``, ``n_communities``,
        ``community_sizes`` (dict community->count),
        ``orphan_nodes`` (nodes with no edges),
        ``missing_nodes`` (nodes in edges but not in node file).
    """
    edf = pd.read_csv(edges_csv)
    ndf = pd.read_csv(nodes_csv)

    edge_nodes = set(edf["source"].tolist() + edf["target"].tolist())
    node_ids = set(ndf["node_id"].tolist())
    missing = edge_nodes - node_ids
    orphans = node_ids - edge_nodes

    comm_sizes = ndf["community"].value_counts().to_dict()

    return {
        "n_nodes": int(len(ndf)),
        "n_edges": int(len(edf)),
        "n_communities": int(ndf["community"].nunique()),
        "community_sizes": {int(k): int(v) for k, v in comm_sizes.items()},
        "orphan_nodes": sorted(orphans),
        "missing_nodes": sorted(missing),
    }


@mcp.tool()
def compute_label_permutation_invariant_score(labels_a: list,
                                               labels_b: list) -> dict:
    """Find the best label permutation mapping A -> B and compute accuracy.

    Since clustering algorithms produce arbitrary label assignments,
    this finds the permutation of labels_a that maximizes agreement
    with labels_b using the Hungarian algorithm.

    Args:
        labels_a: First set of labels (list of ints).
        labels_b: Second set of labels (list of ints).

    Returns:
        dict with ``accuracy`` (float), ``mapping`` (dict a_label -> b_label).
    """
    from scipy.optimize import linear_sum_assignment

    a = np.array(labels_a)
    b = np.array(labels_b)
    classes_a = sorted(set(a.tolist()))
    classes_b = sorted(set(b.tolist()))

    # Build confusion matrix
    n_a, n_b = len(classes_a), len(classes_b)
    C = np.zeros((n_a, n_b), dtype=int)
    a_map = {c: i for i, c in enumerate(classes_a)}
    b_map = {c: i for i, c in enumerate(classes_b)}

    for ai, bi in zip(a, b):
        C[a_map[ai], b_map[bi]] += 1

    # Hungarian algorithm to maximize total agreement
    row_ind, col_ind = linear_sum_assignment(-C)
    mapping = {}
    for ri, ci in zip(row_ind, col_ind):
        mapping[classes_a[ri]] = classes_b[ci]

    # Apply mapping and compute accuracy
    mapped = np.array([mapping.get(ai, -1) for ai in a])
    accuracy = float((mapped == b).mean())

    return {
        "accuracy": accuracy,
        "mapping": {int(k): int(v) for k, v in mapping.items()},
    }
