"""Visualization tools for causal inference analysis.

Functions for plotting treatment effects, event study diagrams,
coefficient plots, covariate balance, and spatial maps.
"""

from typing import Any


def plot_coefficient_table(coefficients: dict, std_errors: dict,
                           title: str = 'Regression Coefficients',
                           output_path: str = 'artifacts/coef_plot.png',
                           significance_levels: dict = None) -> str:
    """Create a forest-style coefficient plot with confidence intervals.

    Parameters
    ----------
    coefficients : dict
        Variable name -> coefficient value.
    std_errors : dict
        Variable name -> standard error.
    title : str
    output_path : str
    significance_levels : dict or None
        Variable name -> p-value for annotating significance.

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    vars_list = [v for v in coefficients if v != '_intercept']
    coefs = [coefficients[v] for v in vars_list]
    ses = [std_errors[v] for v in vars_list]

    fig, ax = plt.subplots(figsize=(8, max(4, len(vars_list) * 0.4)))
    y_pos = list(range(len(vars_list)))

    ax.errorbar(coefs, y_pos, xerr=[1.96 * s for s in ses],
                fmt='o', color='steelblue', capsize=3, markersize=6)
    ax.axvline(x=0, color='red', linestyle='--', alpha=0.5)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(vars_list, fontsize=9)
    ax.set_xlabel('Coefficient (95% CI)')
    ax.set_title(title)
    ax.invert_yaxis()

    if significance_levels:
        for i, v in enumerate(vars_list):
            p = significance_levels.get(v, 1.0)
            stars = '***' if p < 0.01 else '**' if p < 0.05 else '*' if p < 0.1 else ''
            if stars:
                ax.annotate(stars, (coefs[i], i), textcoords="offset points",
                           xytext=(5, 0), fontsize=10, color='darkred')

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def plot_event_study(event_times: list, coefficients: list,
                     std_errors: list,
                     title: str = 'Event Study',
                     xlabel: str = 'Relative Time to Treatment',
                     ylabel: str = 'Treatment Effect',
                     output_path: str = 'artifacts/event_study.png',
                     reference_period: int = -1) -> str:
    """Plot event study (dynamic treatment effect) diagram.

    Shows point estimates with 95% CI bands for each period
    relative to treatment adoption.

    Parameters
    ----------
    event_times : list
    coefficients : list
    std_errors : list
    title : str
    xlabel : str
    ylabel : str
    output_path : str
    reference_period : int

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    ci_lower = [c - 1.96 * s for c, s in zip(coefficients, std_errors)]
    ci_upper = [c + 1.96 * s for c, s in zip(coefficients, std_errors)]

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.fill_between(event_times, ci_lower, ci_upper, alpha=0.2, color='steelblue')
    ax.plot(event_times, coefficients, 'o-', color='steelblue', markersize=5)
    ax.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
    ax.axvline(x=0, color='red', linestyle='--', alpha=0.5, label='Treatment')

    # Mark reference period
    ref_idx = event_times.index(reference_period) if reference_period in event_times else None
    if ref_idx is not None:
        ax.plot(event_times[ref_idx], coefficients[ref_idx], 'D',
                color='red', markersize=8, label=f'Reference (t={reference_period})')

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def plot_treatment_effects(models: dict,
                           title: str = 'Treatment Effects Across Models',
                           output_path: str = 'artifacts/treatment_effects.png',
                           ci_level: float = 0.95) -> str:
    """Compare treatment effect estimates across multiple model specifications.

    Parameters
    ----------
    models : dict
        Model name -> {'coef': float, 'se': float, 'n_obs': int}.
    title : str
    output_path : str
    ci_level : float
        Confidence level for the error bars (e.g. 0.95 -> 1.96*SE,
        0.90 -> 1.645*SE). Use 0.90 when reproducing the non-RPS subsample
        figure where the paper reports p<0.10 significance, 0.95 elsewhere.

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from math import sqrt
    try:
        from scipy.stats import norm
        z = float(norm.ppf(0.5 + ci_level / 2.0))
    except Exception:
        z = 1.96 if ci_level >= 0.94 else 1.645

    names = list(models.keys())
    coefs = [models[n]['coef'] for n in names]
    ses = [models[n]['se'] for n in names]

    fig, ax = plt.subplots(figsize=(8, max(3, len(names) * 0.5)))
    y_pos = list(range(len(names)))

    ax.errorbar(coefs, y_pos, xerr=[z * s for s in ses],
                fmt='s', color='darkblue', capsize=4, markersize=7)
    ax.axvline(x=0, color='red', linestyle='--', alpha=0.5)

    labels = [f'{n} (n={models[n]["n_obs"]})' for n in names]
    ax.set_yticks(y_pos)
    ax.set_yticklabels(labels, fontsize=9)
    ax.set_xlabel(f'Coefficient ({int(round(ci_level * 100))}% CI)')
    ax.set_title(title)
    ax.invert_yaxis()

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def plot_permutation_distribution(observed: float,
                                  null_distribution: list,
                                  p_value: float,
                                  title: str = 'Permutation Test',
                                  output_path: str = 'artifacts/permutation_test.png') -> str:
    """Plot null distribution from permutation test with observed value.

    Parameters
    ----------
    observed : float
    null_distribution : list
    p_value : float
    title : str
    output_path : str

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(null_distribution, bins=30, alpha=0.6, color='gray',
            edgecolor='black', label='Null Distribution')
    ax.axvline(x=observed, color='red', linewidth=2,
               label=f'Observed = {observed:.4f}')
    ax.set_xlabel('Coefficient')
    ax.set_ylabel('Frequency')
    ax.set_title(f'{title} (p = {p_value:.3f})')
    ax.legend()

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def plot_covariate_balance(balance_result: dict,
                           title: str = 'Covariate Balance',
                           output_path: str = 'artifacts/balance.png') -> str:
    """Plot standardized mean differences for covariate balance check.

    Parameters
    ----------
    balance_result : dict
        Output from covariate_balance_check.
    title : str
    output_path : str

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    covs = list(balance_result.keys())
    smds = [balance_result[c]['smd'] for c in covs]

    fig, ax = plt.subplots(figsize=(8, max(3, len(covs) * 0.4)))
    y_pos = list(range(len(covs)))

    colors = ['red' if abs(s) > 0.25 else 'orange' if abs(s) > 0.1
              else 'green' for s in smds]
    ax.barh(y_pos, smds, color=colors, alpha=0.7, edgecolor='black')
    ax.axvline(x=0, color='black', linewidth=0.5)
    ax.axvline(x=0.1, color='orange', linestyle='--', alpha=0.5)
    ax.axvline(x=-0.1, color='orange', linestyle='--', alpha=0.5)
    ax.axvline(x=0.25, color='red', linestyle='--', alpha=0.5)
    ax.axvline(x=-0.25, color='red', linestyle='--', alpha=0.5)

    ax.set_yticks(y_pos)
    ax.set_yticklabels(covs, fontsize=9)
    ax.set_xlabel('Standardized Mean Difference')
    ax.set_title(title)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def plot_spillover_map(state_values: dict,
                       title: str = 'State-Level Values',
                       output_path: str = 'artifacts/state_map.png',
                       cmap: str = 'RdYlGn') -> str:
    """Create a horizontal bar chart of state-level values, sorted ascending.

    This is NOT a geographic choropleth: the bundle ships no state-boundary
    geometry, so this function renders a colour-graded sorted bar chart
    (state abbreviation on Y-axis, value on X-axis, colour from `cmap`) as a
    practical state-level distribution view. Use it for the "stringency map"
    requirement; for a true choropleth, swap in a downstream library that
    consumes state shapefiles.

    Parameters
    ----------
    state_values : dict
        State abbreviation -> value.
    title : str
    output_path : str
    cmap : str

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.cm as cm

    sorted_states = sorted(state_values.items(), key=lambda x: x[1])
    states = [s[0] for s in sorted_states]
    vals = [s[1] for s in sorted_states]

    norm = plt.Normalize(min(vals), max(vals))
    colormap = cm.get_cmap(cmap)
    colors = [colormap(norm(v)) for v in vals]

    fig, ax = plt.subplots(figsize=(10, max(6, len(states) * 0.25)))
    ax.barh(range(len(states)), vals, color=colors, edgecolor='gray',
            linewidth=0.3)
    ax.set_yticks(range(len(states)))
    ax.set_yticklabels(states, fontsize=7)
    ax.set_xlabel('Value')
    ax.set_title(title)

    sm = plt.cm.ScalarMappable(cmap=colormap, norm=norm)
    sm.set_array([])
    plt.colorbar(sm, ax=ax, shrink=0.6)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def plot_time_series_comparison(time_points: list,
                                 series: dict,
                                 title: str = 'Time Series Comparison',
                                 xlabel: str = 'Year',
                                 ylabel: str = 'Value',
                                 output_path: str = 'artifacts/timeseries.png') -> str:
    """Plot multiple time series for comparison.

    Parameters
    ----------
    time_points : list
        Shared x-axis values.
    series : dict
        Series name -> list of values.
    title : str
    xlabel : str
    ylabel : str
    output_path : str

    Returns
    -------
    str
        Path to saved figure.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10, 5))
    for name, values in series.items():
        ax.plot(time_points[:len(values)], values, 'o-', label=name, markersize=3)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path
