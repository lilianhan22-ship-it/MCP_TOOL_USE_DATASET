"""Causal inference and panel regression tools.

Functions for fixed effects regression, cluster-robust standard errors,
difference-in-differences estimation, event study analysis, placebo tests,
and spatial diagnostics for panel data causal inference.
"""

import math
import random
from typing import Any


def ols_regression(rows: list[dict], y_col: str,
                   x_cols: list[str]) -> dict:
    """Ordinary least squares regression.

    Parameters
    ----------
    rows : list[dict]
    y_col : str
        Dependent variable column.
    x_cols : list[str]
        Independent variable columns.

    Returns
    -------
    dict
        'coefficients': dict mapping variable name -> coefficient,
        'std_errors': dict mapping variable name -> std error,
        'r_squared': float,
        'n_obs': int,
        'residuals': list[float].
    """
    n = len(rows)
    k = len(x_cols) + 1  # +1 for intercept

    # Build matrices manually
    Y = [float(r[y_col]) for r in rows]
    X = [[1.0] + [float(r[c]) for c in x_cols] for r in rows]

    # X'X
    XtX = [[sum(X[i][a] * X[i][b] for i in range(n))
            for b in range(k)] for a in range(k)]
    # X'Y
    XtY = [sum(X[i][a] * Y[i] for i in range(n)) for a in range(k)]

    # Solve via Cholesky or simple Gaussian elimination
    beta = _solve_linear(XtX, XtY)

    # Residuals
    resid = [Y[i] - sum(X[i][j] * beta[j] for j in range(k))
             for i in range(n)]

    # R-squared
    y_mean = sum(Y) / n
    ss_tot = sum((y - y_mean) ** 2 for y in Y)
    ss_res = sum(e ** 2 for e in resid)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

    # Standard errors (homoskedastic)
    s2 = ss_res / max(n - k, 1)
    XtX_inv = _invert_matrix(XtX)
    se = [math.sqrt(max(s2 * XtX_inv[j][j], 0)) for j in range(k)]

    names = ['_intercept'] + x_cols
    coefficients = {names[j]: beta[j] for j in range(k)}
    std_errors = {names[j]: se[j] for j in range(k)}

    return {
        'coefficients': coefficients,
        'std_errors': std_errors,
        'r_squared': r2,
        'n_obs': n,
        'residuals': resid
    }


def fixed_effects_regression(rows: list[dict], y_col: str,
                             x_cols: list[str],
                             fe_cols: list[str]) -> dict:
    """Panel regression with multi-way fixed effects via demeaning.

    Implements the within transformation for each fixed effect dimension.
    Iteratively demeans Y and X by each FE group until convergence.

    Parameters
    ----------
    rows : list[dict]
    y_col : str
        Dependent variable.
    x_cols : list[str]
        Regressors (time-varying).
    fe_cols : list[str]
        Fixed effect group columns (e.g., ['dyadid', 'year']).

    Returns
    -------
    dict
        'coefficients', 'std_errors', 'r_squared', 'n_obs',
        'residuals', 'df_residual'.
    """
    n = len(rows)
    k = len(x_cols)

    # Extract raw data
    Y_raw = [float(r[y_col]) for r in rows]
    X_raw = [[float(r[c]) for c in x_cols] for r in rows]

    # Build FE group indices
    fe_groups = []
    for fc in fe_cols:
        groups = {}
        for i, r in enumerate(rows):
            g = str(r[fc])
            groups.setdefault(g, []).append(i)
        fe_groups.append(groups)

    # Iterative demeaning (alternating-projections / method of alternating
    # means). For multi-way fixed effects a single pass over the FE dimensions
    # does not fully remove all group means, so we sweep until the demeaned
    # values stop changing. Convergence is measured by the largest absolute
    # group mean removed during a full sweep (it tends to 0 as the within
    # transform completes).
    Y_dm = list(Y_raw)
    X_dm = [list(row) for row in X_raw]

    for iteration in range(1000):
        max_change = 0.0
        for groups in fe_groups:
            for g, indices in groups.items():
                m = len(indices)
                # Demean Y by this group's mean.
                mean_y = sum(Y_dm[i] for i in indices) / m
                max_change = max(max_change, abs(mean_y))
                for i in indices:
                    Y_dm[i] -= mean_y
                # Demean each X column by this group's mean.
                for j in range(k):
                    mean_x = sum(X_dm[i][j] for i in indices) / m
                    max_change = max(max_change, abs(mean_x))
                    for i in indices:
                        X_dm[i][j] -= mean_x
        if max_change < 1e-10:
            break

    # OLS on demeaned data (no intercept)
    XtX = [[sum(X_dm[i][a] * X_dm[i][b] for i in range(n))
            for b in range(k)] for a in range(k)]
    XtY = [sum(X_dm[i][a] * Y_dm[i] for i in range(n)) for a in range(k)]

    beta = _solve_linear(XtX, XtY)

    # Residuals
    resid = [Y_dm[i] - sum(X_dm[i][j] * beta[j] for j in range(k))
             for i in range(n)]

    # Count FE parameters
    n_fe = sum(len(g) for g in fe_groups)
    df_resid = max(n - k - n_fe, 1)

    # R-squared (within)
    ss_res = sum(e ** 2 for e in resid)
    ss_tot = sum(y ** 2 for y in Y_dm)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

    # Standard errors
    s2 = ss_res / df_resid
    XtX_inv = _invert_matrix(XtX)
    se = [math.sqrt(max(s2 * XtX_inv[j][j], 0)) for j in range(k)]

    coefficients = {x_cols[j]: beta[j] for j in range(k)}
    std_errors = {x_cols[j]: se[j] for j in range(k)}

    return {
        'coefficients': coefficients,
        'std_errors': std_errors,
        'r_squared': r2,
        'n_obs': n,
        'residuals': resid,
        'df_residual': df_resid
    }


def cluster_robust_se(rows: list[dict], x_cols: list[str],
                      residuals: list[float],
                      cluster_col: str,
                      fe_cols: list[str] = None) -> dict:
    """Compute cluster-robust (Liang-Zeger) standard errors.

    Adjusts variance-covariance matrix for within-cluster correlation.

    Parameters
    ----------
    rows : list[dict]
    x_cols : list[str]
    residuals : list[float]
    cluster_col : str
        Column defining clusters.
    fe_cols : list[str] or None
        If provided, demeans X by these FE groups first.

    Returns
    -------
    dict
        'std_errors': dict mapping variable -> cluster-robust SE,
        'n_clusters': int.
    """
    n = len(rows)
    k = len(x_cols)

    X = [[float(r[c]) for c in x_cols] for r in rows]

    # Demean if FE cols provided
    if fe_cols:
        fe_groups = []
        for fc in fe_cols:
            groups = {}
            for i, r in enumerate(rows):
                groups.setdefault(str(r[fc]), []).append(i)
            fe_groups.append(groups)
        for _ in range(1000):
            max_change = 0.0
            for groups in fe_groups:
                for g, indices in groups.items():
                    for j in range(k):
                        mean_x = sum(X[i][j] for i in indices) / len(indices)
                        max_change = max(max_change, abs(mean_x))
                        for i in indices:
                            X[i][j] -= mean_x
            if max_change < 1e-10:
                break

    # X'X inverse
    XtX = [[sum(X[i][a] * X[i][b] for i in range(n))
            for b in range(k)] for a in range(k)]
    XtX_inv = _invert_matrix(XtX)

    # Cluster the residuals
    clusters = {}
    for i, r in enumerate(rows):
        c = str(r[cluster_col])
        clusters.setdefault(c, []).append(i)
    G = len(clusters)

    # Meat: sum over clusters of (X_g' e_g)(X_g' e_g)'
    meat = [[0.0] * k for _ in range(k)]
    for c, indices in clusters.items():
        Xe = [sum(X[i][j] * residuals[i] for i in indices) for j in range(k)]
        for a in range(k):
            for b in range(k):
                meat[a][b] += Xe[a] * Xe[b]

    # Small-sample correction
    correction = G / max(G - 1, 1) * n / max(n - k, 1)

    # Sandwich: (X'X)^{-1} Meat (X'X)^{-1} * correction
    V = [[0.0] * k for _ in range(k)]
    for a in range(k):
        for b in range(k):
            for p in range(k):
                for q in range(k):
                    V[a][b] += XtX_inv[a][p] * meat[p][q] * XtX_inv[q][b]
            V[a][b] *= correction

    se = {x_cols[j]: math.sqrt(max(V[j][j], 0)) for j in range(k)}

    return {'std_errors': se, 'n_clusters': G}


def event_study_did(rows: list[dict], y_col: str,
                    treat_col: str, time_col: str,
                    unit_col: str,
                    event_time_col: str,
                    pre_periods: int = 5,
                    post_periods: int = 5,
                    control_cols: list[str] = None) -> dict:
    """Estimate event study (dynamic DiD) coefficients.

    Creates indicator variables for each relative time period
    around treatment adoption and estimates their effects via
    fixed effects regression.

    Parameters
    ----------
    rows : list[dict]
    y_col : str
        Outcome variable.
    treat_col : str
        Binary treatment indicator.
    time_col : str
        Calendar time column.
    unit_col : str
        Unit identifier.
    event_time_col : str
        Relative time to treatment (e.g., year - adoption_year).
    pre_periods : int
        Number of pre-treatment periods to estimate.
    post_periods : int
        Number of post-treatment periods to estimate.
    control_cols : list[str] or None
        Additional control variables.

    Returns
    -------
    dict
        'event_time': list of relative periods,
        'coefficients': list of point estimates,
        'std_errors': list of SEs,
        'reference_period': int (omitted period, typically -1).
    """
    # Create event-time dummies
    event_times = list(range(-pre_periods, post_periods + 1))
    ref_period = -1
    event_times_use = [t for t in event_times if t != ref_period]

    x_cols_event = [f'et_{t}' for t in event_times_use]

    augmented = []
    for r in rows:
        r2 = dict(r)
        et = int(float(r[event_time_col]))
        for t in event_times_use:
            r2[f'et_{t}'] = 1.0 if et == t else 0.0
        augmented.append(r2)

    all_x = x_cols_event + (control_cols or [])
    result = fixed_effects_regression(
        augmented, y_col, all_x, [unit_col, time_col]
    )

    event_coefs = []
    event_ses = []
    for t in event_times:
        if t == ref_period:
            event_coefs.append(0.0)
            event_ses.append(0.0)
        else:
            col = f'et_{t}'
            event_coefs.append(result['coefficients'].get(col, 0.0))
            event_ses.append(result['std_errors'].get(col, 0.0))

    return {
        'event_time': event_times,
        'coefficients': event_coefs,
        'std_errors': event_ses,
        'reference_period': ref_period,
        'r_squared': result['r_squared'],
        'n_obs': result['n_obs']
    }


def parallel_trends_test(rows: list[dict], y_col: str,
                         treat_col: str, time_col: str,
                         unit_col: str,
                         pre_treatment_years: list[int]) -> dict:
    """Test for parallel pre-treatment trends between treated and control.

    Estimates a linear trend in Y for treated vs control groups
    over pre-treatment periods and tests if the trends differ.

    Parameters
    ----------
    rows : list[dict]
    y_col : str
    treat_col : str
    time_col : str
    unit_col : str
    pre_treatment_years : list[int]

    Returns
    -------
    dict
        'treat_trend': float, 'control_trend': float,
        'diff_trend': float, 'se_diff': float,
        'p_value': float.
    """
    pre_rows = [r for r in rows
                if int(float(r[time_col])) in pre_treatment_years]

    treat = [r for r in pre_rows if float(r[treat_col]) > 0]
    control = [r for r in pre_rows if float(r[treat_col]) == 0]

    def _trend(subset):
        if len(subset) < 3:
            return 0.0, 1.0
        times = [float(r[time_col]) for r in subset]
        ys = [float(r[y_col]) for r in subset]
        n = len(times)
        mx = sum(times) / n
        my = sum(ys) / n
        sxy = sum((times[i] - mx) * (ys[i] - my) for i in range(n))
        sxx = sum((t - mx) ** 2 for t in times)
        if sxx == 0:
            return 0.0, 1.0
        slope = sxy / sxx
        resid = [ys[i] - my - slope * (times[i] - mx) for i in range(n)]
        s2 = sum(r ** 2 for r in resid) / max(n - 2, 1)
        se = math.sqrt(s2 / sxx) if sxx > 0 else 1.0
        return slope, se

    b_t, se_t = _trend(treat)
    b_c, se_c = _trend(control)
    diff = b_t - b_c
    se_diff = math.sqrt(se_t ** 2 + se_c ** 2)
    t_stat = diff / se_diff if se_diff > 0 else 0.0

    # Two-sided p-value approximation (normal)
    p = 2 * (1 - _normal_cdf(abs(t_stat)))

    return {
        'treat_trend': b_t,
        'control_trend': b_c,
        'diff_trend': diff,
        'se_diff': se_diff,
        't_stat': t_stat,
        'p_value': p
    }


def placebo_permutation_test(rows: list[dict], y_col: str,
                             x_cols: list[str],
                             fe_cols: list[str],
                             treatment_col: str,
                             cluster_col: str,
                             n_permutations: int = 500,
                             seed: int = 42) -> dict:
    """Permutation-based placebo test for treatment effect.

    Randomly permutes treatment assignment across clusters and
    re-estimates the model to build a null distribution.

    Parameters
    ----------
    rows : list[dict]
    y_col : str
    x_cols : list[str]
    fe_cols : list[str]
    treatment_col : str
        The treatment variable in x_cols to permute.
    cluster_col : str
    n_permutations : int
    seed : int

    Returns
    -------
    dict
        'observed_coef': float,
        'null_distribution': list[float],
        'p_value': float (two-sided),
        'n_permutations': int.
    """
    rng = random.Random(seed)

    # Observed coefficient
    result = fixed_effects_regression(rows, y_col, x_cols, fe_cols)
    observed = result['coefficients'][treatment_col]

    # Get unique clusters and their treatment values
    cluster_treat = {}
    for r in rows:
        c = str(r[cluster_col])
        cluster_treat[c] = float(r[treatment_col])

    clusters = list(cluster_treat.keys())
    treat_values = [cluster_treat[c] for c in clusters]

    null_dist = []
    for _ in range(n_permutations):
        # Permute treatment across clusters
        perm = list(treat_values)
        rng.shuffle(perm)
        perm_map = {clusters[i]: perm[i] for i in range(len(clusters))}

        perm_rows = []
        for r in rows:
            r2 = dict(r)
            r2[treatment_col] = perm_map[str(r[cluster_col])]
            perm_rows.append(r2)

        try:
            perm_result = fixed_effects_regression(
                perm_rows, y_col, x_cols, fe_cols)
            null_dist.append(perm_result['coefficients'][treatment_col])
        except Exception:
            continue

    # P-value
    n_extreme = sum(1 for d in null_dist if abs(d) >= abs(observed))
    p_val = (n_extreme + 1) / (len(null_dist) + 1)

    return {
        'observed_coef': observed,
        'null_distribution': null_dist,
        'p_value': p_val,
        'n_permutations': len(null_dist)
    }


def bootstrap_confidence_interval(rows: list[dict], y_col: str,
                                  x_cols: list[str],
                                  fe_cols: list[str],
                                  cluster_col: str,
                                  target_var: str,
                                  n_boot: int = 200,
                                  alpha: float = 0.05,
                                  seed: int = 42) -> dict:
    """Cluster bootstrap confidence interval for a coefficient.

    Resamples clusters with replacement and re-estimates.

    Parameters
    ----------
    rows : list[dict]
    y_col : str
    x_cols : list[str]
    fe_cols : list[str]
    cluster_col : str
    target_var : str
        Variable for which to compute CI.
    n_boot : int
    alpha : float
    seed : int

    Returns
    -------
    dict
        'point_estimate': float,
        'ci_lower': float,
        'ci_upper': float,
        'boot_distribution': list[float].
    """
    rng = random.Random(seed)

    # Original estimate
    orig = fixed_effects_regression(rows, y_col, x_cols, fe_cols)
    point = orig['coefficients'][target_var]

    # Group rows by cluster
    cluster_rows = {}
    for r in rows:
        c = str(r[cluster_col])
        cluster_rows.setdefault(c, []).append(r)
    cluster_ids = list(cluster_rows.keys())
    G = len(cluster_ids)

    boot_coefs = []
    for _ in range(n_boot):
        # Resample clusters
        sampled = rng.choices(cluster_ids, k=G)
        boot_data = []
        for idx, cid in enumerate(sampled):
            for r in cluster_rows[cid]:
                r2 = dict(r)
                # Relabel cluster to avoid duplicate FE issues
                for fc in fe_cols:
                    if fc == cluster_col:
                        r2[fc] = f'{r[fc]}_{idx}'
                boot_data.append(r2)

        try:
            res = fixed_effects_regression(boot_data, y_col, x_cols, fe_cols)
            boot_coefs.append(res['coefficients'][target_var])
        except Exception:
            continue

    boot_coefs.sort()
    n_b = len(boot_coefs)
    lo_idx = max(int(alpha / 2 * n_b), 0)
    hi_idx = min(int((1 - alpha / 2) * n_b), n_b - 1)

    return {
        'point_estimate': point,
        'ci_lower': boot_coefs[lo_idx] if n_b > 0 else point,
        'ci_upper': boot_coefs[hi_idx] if n_b > 0 else point,
        'boot_distribution': boot_coefs
    }


def covariate_balance_check(rows: list[dict],
                            treat_col: str,
                            covariates: list[str]) -> dict:
    """Check covariate balance between treated and control groups.

    Computes standardized mean differences (SMD) for each covariate.

    Parameters
    ----------
    rows : list[dict]
    treat_col : str
    covariates : list[str]

    Returns
    -------
    dict
        For each covariate: 'treat_mean', 'control_mean', 'smd'.
    """
    treat = [r for r in rows if float(r[treat_col]) > 0]
    control = [r for r in rows if float(r[treat_col]) == 0]

    result = {}
    for cov in covariates:
        t_vals = [float(r[cov]) for r in treat if r.get(cov) not in (None, '')]
        c_vals = [float(r[cov]) for r in control if r.get(cov) not in (None, '')]

        t_mean = sum(t_vals) / len(t_vals) if t_vals else 0
        c_mean = sum(c_vals) / len(c_vals) if c_vals else 0

        t_var = sum((v - t_mean) ** 2 for v in t_vals) / max(len(t_vals) - 1, 1) if t_vals else 1
        c_var = sum((v - c_mean) ** 2 for v in c_vals) / max(len(c_vals) - 1, 1) if c_vals else 1

        pooled_sd = math.sqrt((t_var + c_var) / 2)
        smd = (t_mean - c_mean) / pooled_sd if pooled_sd > 0 else 0

        result[cov] = {
            'treat_mean': t_mean,
            'control_mean': c_mean,
            'smd': smd,
            'treat_n': len(t_vals),
            'control_n': len(c_vals)
        }

    return result


def compute_rps_stringency(pct_target: float, pct_current_re: float,
                           pct_load_covered: float) -> float:
    """Compute Renewable Portfolio Standard stringency score.

    Stringency = max(0, %target - %current_RE) * %load_covered / 100

    Parameters
    ----------
    pct_target : float
        RPS target percentage (0-100).
    pct_current_re : float
        Current renewable energy share (0-100).
    pct_load_covered : float
        Percentage of electricity load covered by RPS (0-100).

    Returns
    -------
    float
        Stringency score.
    """
    gap = max(0.0, pct_target - pct_current_re)
    return gap * pct_load_covered / 100.0


def moran_i_test(values: list[float], weights_matrix: list[list[float]]) -> dict:
    """Compute Global Moran's I statistic for spatial autocorrelation.

    Parameters
    ----------
    values : list[float]
        Observed values for each spatial unit.
    weights_matrix : list[list[float]]
        n x n spatial weights matrix (row-standardized).

    Returns
    -------
    dict
        'morans_i': float, 'expected_i': float,
        'z_score': float, 'p_value': float.
    """
    n = len(values)
    mean_v = sum(values) / n
    dev = [v - mean_v for v in values]

    S0 = sum(weights_matrix[i][j] for i in range(n) for j in range(n))
    numerator = sum(weights_matrix[i][j] * dev[i] * dev[j]
                    for i in range(n) for j in range(n))
    denominator = sum(d ** 2 for d in dev)

    I = (n / S0) * (numerator / denominator) if denominator > 0 and S0 > 0 else 0
    E_I = -1.0 / (n - 1) if n > 1 else 0

    # Variance under normality assumption
    S1 = 0.5 * sum((weights_matrix[i][j] + weights_matrix[j][i]) ** 2
                    for i in range(n) for j in range(n))
    S2 = sum((sum(weights_matrix[i][j] for j in range(n)) +
              sum(weights_matrix[j][i] for j in range(n))) ** 2 for i in range(n))

    A = n * ((n ** 2 - 3 * n + 3) * S1 - n * S2 + 3 * S0 ** 2)
    B = (n ** 2 - n) * ((n - 1) * S1 - 2 * n * S2 + 6 * S0 ** 2) if n > 1 else 0
    m4 = sum(d ** 4 for d in dev) / n
    m2 = denominator / n
    D = m4 / (m2 ** 2) if m2 > 0 else 3

    C = ((n - 1) * (n - 2) * (n - 3) * S0 ** 2)
    V_I = (A - D * B) / C - E_I ** 2 if C > 0 else 1.0

    z = (I - E_I) / math.sqrt(abs(V_I)) if V_I > 0 else 0
    p = 2 * (1 - _normal_cdf(abs(z)))

    return {
        'morans_i': I,
        'expected_i': E_I,
        'z_score': z,
        'p_value': p
    }


def interaction_effect(rows: list[dict], var_a: str, var_b: str,
                       interaction_col: str = None) -> list[dict]:
    """Add an interaction term between two variables.

    Parameters
    ----------
    rows : list[dict]
    var_a : str
    var_b : str
    interaction_col : str or None
        Name for the interaction column. Default: '{var_a}_x_{var_b}'.

    Returns
    -------
    list[dict]
        Rows with interaction column added.
    """
    if interaction_col is None:
        interaction_col = f'{var_a}_x_{var_b}'
    out = []
    for r in rows:
        r2 = dict(r)
        r2[interaction_col] = float(r[var_a]) * float(r[var_b])
        out.append(r2)
    return out


def compute_t_stat(coef: float, se: float) -> dict:
    """Compute t-statistic and p-value for a coefficient.

    Parameters
    ----------
    coef : float
    se : float

    Returns
    -------
    dict
        't_stat': float, 'p_value': float (two-sided, normal approx).
    """
    t = coef / se if se > 0 else 0.0
    p = 2 * (1 - _normal_cdf(abs(t)))
    return {'t_stat': t, 'p_value': p, 'significant_05': p < 0.05}


# --- Internal helpers ---

def _solve_linear(A: list[list[float]], b: list[float]) -> list[float]:
    """Solve Ax = b via Gaussian elimination with partial pivoting."""
    n = len(b)
    M = [row[:] + [b[i]] for i, row in enumerate(A)]

    for col in range(n):
        # Partial pivoting
        max_row = max(range(col, n), key=lambda r: abs(M[r][col]))
        M[col], M[max_row] = M[max_row], M[col]

        pivot = M[col][col]
        if abs(pivot) < 1e-14:
            M[col][col] = 1e-14
            pivot = 1e-14

        for row in range(col + 1, n):
            factor = M[row][col] / pivot
            for j in range(col, n + 1):
                M[row][j] -= factor * M[col][j]

    # Back substitution
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        x[i] = (M[i][n] - sum(M[i][j] * x[j] for j in range(i + 1, n)))
        x[i] /= M[i][i] if abs(M[i][i]) > 1e-14 else 1e-14

    return x


def _invert_matrix(A: list[list[float]]) -> list[list[float]]:
    """Invert a matrix using Gauss-Jordan elimination."""
    n = len(A)
    M = [row[:] + [1.0 if i == j else 0.0 for j in range(n)]
         for i, row in enumerate(A)]

    for col in range(n):
        max_row = max(range(col, n), key=lambda r: abs(M[r][col]))
        M[col], M[max_row] = M[max_row], M[col]

        pivot = M[col][col]
        if abs(pivot) < 1e-14:
            pivot = 1e-14
        for j in range(2 * n):
            M[col][j] /= pivot

        for row in range(n):
            if row != col:
                factor = M[row][col]
                for j in range(2 * n):
                    M[row][j] -= factor * M[col][j]

    return [row[n:] for row in M]


def _normal_cdf(x: float) -> float:
    """Approximate standard normal CDF using Abramowitz-Stegun."""
    if x < -8:
        return 0.0
    if x > 8:
        return 1.0
    t = 1.0 / (1.0 + 0.2316419 * abs(x))
    d = 0.3989422804014327
    p = d * math.exp(-x * x / 2.0) * (
        t * (0.319381530 + t * (-0.356563782 + t * (
            1.781477937 + t * (-1.821255978 + t * 1.330274429)))))
    return 1.0 - p if x > 0 else p
