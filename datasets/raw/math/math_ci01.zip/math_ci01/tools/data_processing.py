"""Data loading and panel data processing utilities.

Functions for loading CSV panel datasets, merging, reshaping,
and constructing variables for causal inference analysis.
"""

import csv
import math
from typing import Any


def load_csv(path: str) -> list[dict]:
    """Load a CSV file into a list of dictionaries.

    Each row becomes a dict with column names as keys.

    Parameters
    ----------
    path : str
        Path to the CSV file.

    Returns
    -------
    list[dict]
        Rows as dictionaries.
    """
    with open(path, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def filter_rows(rows: list[dict], column: str, values: list) -> list[dict]:
    """Filter rows to keep only those where column value is in values.

    Parameters
    ----------
    rows : list[dict]
    column : str
    values : list
        Acceptable values (compared as strings).

    Returns
    -------
    list[dict]
    """
    str_values = {str(v) for v in values}
    return [r for r in rows if str(r.get(column, '')) in str_values]


def filter_by_range(rows: list[dict], column: str,
                    low: float, high: float) -> list[dict]:
    """Filter rows where column value falls within [low, high].

    Parameters
    ----------
    rows : list[dict]
    column : str
    low : float
    high : float

    Returns
    -------
    list[dict]
    """
    out = []
    for r in rows:
        v = float(r[column])
        if low <= v <= high:
            out.append(r)
    return out


def add_lag(rows: list[dict], unit_col: str, time_col: str,
            var_col: str, lag: int = 1) -> list[dict]:
    """Add a lagged variable column to panel data.

    Creates a new column '{var_col}_lag{lag}' containing the value
    of var_col from lag periods earlier for the same unit.

    Parameters
    ----------
    rows : list[dict]
    unit_col : str
        Column identifying the panel unit (e.g., dyad ID).
    time_col : str
        Column identifying the time period.
    var_col : str
        Column to lag.
    lag : int
        Number of periods to lag (default 1).

    Returns
    -------
    list[dict]
        Rows with the lagged column added (rows without lag data dropped).
    """
    lookup = {}
    for r in rows:
        key = (str(r[unit_col]), int(float(r[time_col])))
        lookup[key] = r.get(var_col)

    lag_col = f'{var_col}_lag{lag}'
    out = []
    for r in rows:
        unit = str(r[unit_col])
        t = int(float(r[time_col]))
        lagged = lookup.get((unit, t - lag))
        if lagged is not None:
            r2 = dict(r)
            r2[lag_col] = lagged
            out.append(r2)
    return out


def add_log_column(rows: list[dict], col: str,
                   new_col: str = None, offset: float = 1.0) -> list[dict]:
    """Add natural log of a column, with optional offset for zeros.

    Parameters
    ----------
    rows : list[dict]
    col : str
        Source column.
    new_col : str or None
        Name for log column. Defaults to 'log_{col}'.
    offset : float
        Added to value before log (default 1.0 to handle zeros).

    Returns
    -------
    list[dict]
    """
    if new_col is None:
        new_col = f'log_{col}'
    out = []
    for r in rows:
        v = float(r[col]) + offset
        if v > 0:
            r2 = dict(r)
            r2[new_col] = math.log(v)
            out.append(r2)
    return out


def merge_panels(left: list[dict], right: list[dict],
                 on: list[str]) -> list[dict]:
    """Inner join two list-of-dict panels on specified key columns.

    Parameters
    ----------
    left : list[dict]
    right : list[dict]
    on : list[str]
        Key column names.

    Returns
    -------
    list[dict]
    """
    right_index = {}
    for r in right:
        key = tuple(str(r[k]) for k in on)
        right_index.setdefault(key, []).append(r)

    out = []
    for lr in left:
        key = tuple(str(lr[k]) for k in on)
        for rr in right_index.get(key, []):
            merged = dict(lr)
            for k, v in rr.items():
                if k not in merged:
                    merged[k] = v
            out.append(merged)
    return out


def compute_group_mean(rows: list[dict], group_col: str,
                       value_col: str) -> dict:
    """Compute the mean of value_col within each group.

    Parameters
    ----------
    rows : list[dict]
    group_col : str
    value_col : str

    Returns
    -------
    dict
        Mapping group -> mean value.
    """
    sums = {}
    counts = {}
    for r in rows:
        g = str(r[group_col])
        v = float(r[value_col])
        sums[g] = sums.get(g, 0.0) + v
        counts[g] = counts.get(g, 0) + 1
    return {g: sums[g] / counts[g] for g in sums}


def summary_stats(rows: list[dict], columns: list[str]) -> dict:
    """Compute summary statistics for specified columns.

    Parameters
    ----------
    rows : list[dict]
    columns : list[str]

    Returns
    -------
    dict
        For each column: count, mean, std, min, max.
    """
    import math
    result = {}
    for col in columns:
        vals = [float(r[col]) for r in rows if r.get(col) not in (None, '', 'nan')]
        n = len(vals)
        if n == 0:
            result[col] = {'count': 0}
            continue
        mean = sum(vals) / n
        var = sum((v - mean) ** 2 for v in vals) / max(n - 1, 1)
        result[col] = {
            'count': n,
            'mean': mean,
            'std': math.sqrt(var),
            'min': min(vals),
            'max': max(vals)
        }
    return result


def add_lags_batch(rows: list[dict], unit_col: str, time_col: str,
                   var_cols: list[str], lag: int = 1) -> list[dict]:
    """Add lagged versions of multiple variables in a single pass.

    Safer than calling :func:`add_lag` sequentially per variable: a single
    pre-pass builds a per-(unit, year) lookup of every requested var, and a
    single post-pass appends each '_lag<lag>' column. Rows whose
    (unit, year - lag) lookup does not exist for ANY var_col are dropped
    exactly once (not cascade-dropped across calls). For a 1991-2021 panel
    this drops only the 1991 rows on a lag=1 call, leaving the remaining
    years intact.
    """
    lookup = {var: {} for var in var_cols}
    for r in rows:
        key = (str(r[unit_col]), int(float(r[time_col])))
        for var in var_cols:
            lookup[var][key] = r.get(var)
    out = []
    for r in rows:
        unit = str(r[unit_col])
        t = int(float(r[time_col]))
        key_lag = (unit, t - lag)
        vals = {var: lookup[var].get(key_lag) for var in var_cols}
        if all(v is not None for v in vals.values()):
            r2 = dict(r)
            for var in var_cols:
                r2[f"{var}_lag{lag}"] = vals[var]
            out.append(r2)
    return out

