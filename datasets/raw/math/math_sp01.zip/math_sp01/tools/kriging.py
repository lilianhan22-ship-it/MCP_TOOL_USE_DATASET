"""Kriging and spatial interpolation tools."""

import numpy as np
from typing import Dict, Optional, Tuple


def ordinary_kriging(
    known_lats: np.ndarray,
    known_lons: np.ndarray,
    known_values: np.ndarray,
    pred_lats: np.ndarray,
    pred_lons: np.ndarray,
    variogram_params: Dict[str, float],
    variogram_model: str = "spherical",
) -> Dict[str, np.ndarray]:
    """Perform ordinary kriging interpolation.

    Args:
        known_lats: Latitudes of known points.
        known_lons: Longitudes of known points.
        known_values: Observed values at known points.
        pred_lats: Latitudes of prediction points.
        pred_lons: Longitudes of prediction points.
        variogram_params: Dict with 'nugget', 'sill', 'range' keys.
        variogram_model: Model type - 'spherical', 'exponential', or 'gaussian'.

    Returns:
        Dictionary with 'predictions' and 'variances' arrays.
    """
    try:
        from .variogram import spherical_model, exponential_model, gaussian_model
    except ImportError:
        try:
            from tools.variogram import spherical_model, exponential_model, gaussian_model
        except ImportError:
            from variogram import spherical_model, exponential_model, gaussian_model

    model_funcs = {
        "spherical": spherical_model,
        "exponential": exponential_model,
        "gaussian": gaussian_model,
    }
    vfunc = model_funcs[variogram_model]
    nugget = variogram_params["nugget"]
    sill = variogram_params["sill"]
    range_p = variogram_params["range"]

    n = len(known_lats)
    known_coords = np.column_stack([known_lats, known_lons])

    # Build covariance matrix C (sill - gamma)
    dists_known = np.sqrt(
        np.sum((known_coords[:, np.newaxis, :] - known_coords[np.newaxis, :, :]) ** 2, axis=2)
    )
    gamma_known = vfunc(dists_known, nugget, sill, range_p)
    C = sill - gamma_known
    np.fill_diagonal(C, sill)

    # Add Lagrange multiplier row/column
    C_ext = np.ones((n + 1, n + 1))
    C_ext[:n, :n] = C
    C_ext[n, n] = 0

    predictions = np.zeros(len(pred_lats))
    variances = np.zeros(len(pred_lats))

    for i in range(len(pred_lats)):
        pred_coord = np.array([pred_lats[i], pred_lons[i]])
        dists_pred = np.sqrt(np.sum((known_coords - pred_coord) ** 2, axis=1))
        gamma_pred = vfunc(dists_pred, nugget, sill, range_p)
        c0 = sill - gamma_pred

        # Right-hand side with Lagrange constraint
        rhs = np.ones(n + 1)
        rhs[:n] = c0

        try:
            weights = np.linalg.solve(C_ext, rhs)
            predictions[i] = np.dot(weights[:n], known_values)
            variances[i] = sill - np.dot(weights[:n], c0) - weights[n]
        except np.linalg.LinAlgError:
            predictions[i] = known_values.mean()
            variances[i] = known_values.var()

    return {"predictions": predictions, "variances": variances}


def idw_interpolation(
    known_lats: np.ndarray,
    known_lons: np.ndarray,
    known_values: np.ndarray,
    pred_lats: np.ndarray,
    pred_lons: np.ndarray,
    power: float = 2.0,
    n_neighbors: Optional[int] = None,
) -> np.ndarray:
    """Perform Inverse Distance Weighting (IDW) interpolation.

    Args:
        known_lats: Latitudes of known points.
        known_lons: Longitudes of known points.
        known_values: Observed values at known points.
        pred_lats: Latitudes of prediction points.
        pred_lons: Longitudes of prediction points.
        power: Power parameter for distance weighting.
        n_neighbors: Number of nearest neighbors to use. None uses all.

    Returns:
        Array of predicted values at prediction points.
    """
    from scipy.spatial import cKDTree

    known_coords = np.column_stack([known_lats, known_lons])
    pred_coords = np.column_stack([pred_lats, pred_lons])

    if n_neighbors is None:
        n_neighbors = len(known_lats)

    tree = cKDTree(known_coords)
    dists, indices = tree.query(pred_coords, k=min(n_neighbors, len(known_lats)))

    predictions = np.zeros(len(pred_lats))
    for i in range(len(pred_lats)):
        d = dists[i] if dists.ndim > 1 else np.array([dists[i]])
        idx = indices[i] if indices.ndim > 1 else np.array([indices[i]])
        if np.any(d == 0):
            predictions[i] = known_values[idx[d == 0][0]]
        else:
            w = 1.0 / d ** power
            predictions[i] = np.sum(w * known_values[idx]) / np.sum(w)

    return predictions
