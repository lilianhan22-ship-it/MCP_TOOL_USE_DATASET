"""Plotting tools for spatial data visualization."""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from typing import Optional, Dict, Tuple


def plot_spatial_map(
    lats: np.ndarray,
    lons: np.ndarray,
    values: np.ndarray,
    title: str = "Spatial Map",
    colorbar_label: str = "Value",
    cmap: str = "viridis",
    save_path: str = "artifacts/spatial_map.png",
    figsize: Tuple[int, int] = (12, 6),
    vmin: Optional[float] = None,
    vmax: Optional[float] = None,
) -> str:
    """Plot a spatial map of values at geographic coordinates.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        values: Array of values to plot.
        title: Plot title.
        colorbar_label: Label for the colorbar.
        cmap: Matplotlib colormap name.
        save_path: Path to save the figure.
        figsize: Figure size.
        vmin: Minimum value for color scale.
        vmax: Maximum value for color scale.

    Returns:
        Path to the saved figure.
    """
    fig, ax = plt.subplots(figsize=figsize)
    sc = ax.scatter(lons, lats, c=values, cmap=cmap, s=2, alpha=0.7, vmin=vmin, vmax=vmax)
    plt.colorbar(sc, ax=ax, label=colorbar_label)
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title(title)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return save_path


def plot_variogram(
    lag: np.ndarray,
    semivariance: np.ndarray,
    fitted_params: Optional[Dict[str, float]] = None,
    fitted_model: str = "spherical",
    title: str = "Empirical and Fitted Variogram",
    save_path: str = "artifacts/variogram.png",
) -> str:
    """Plot empirical variogram with optional fitted model overlay.

    Args:
        lag: Lag distances.
        semivariance: Empirical semivariance values.
        fitted_params: Dict with 'nugget', 'sill', 'range' for fitted model line.
        fitted_model: Model type ('spherical', 'exponential', 'gaussian').
        title: Plot title.
        save_path: Path to save the figure.

    Returns:
        Path to the saved figure.
    """
    try:
        from .variogram import spherical_model, exponential_model, gaussian_model
    except ImportError:
        try:
            from tools.variogram import spherical_model, exponential_model, gaussian_model
        except ImportError:
            from variogram import spherical_model, exponential_model, gaussian_model

    fig, ax = plt.subplots(figsize=(8, 5))
    mask = semivariance > 0
    ax.scatter(lag[mask], semivariance[mask], color="steelblue", s=40, zorder=3, label="Empirical")

    if fitted_params is not None:
        model_funcs = {
            "spherical": spherical_model,
            "exponential": exponential_model,
            "gaussian": gaussian_model,
        }
        func = model_funcs[fitted_model]
        h_smooth = np.linspace(0, lag[mask].max() * 1.1, 200)
        gamma_smooth = func(h_smooth, fitted_params["nugget"], fitted_params["sill"], fitted_params["range"])
        ax.plot(h_smooth, gamma_smooth, "r-", linewidth=2, label=f"{fitted_model.capitalize()} model")

        ax.axhline(y=fitted_params["sill"], color="gray", linestyle="--", alpha=0.5, label=f"Sill = {fitted_params['sill']:.2f}")
        ax.axvline(x=fitted_params["range"], color="gray", linestyle=":", alpha=0.5, label=f"Range = {fitted_params['range']:.2f}")

    ax.set_xlabel("Lag Distance")
    ax.set_ylabel("Semivariance")
    ax.set_title(title)
    ax.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return save_path


def plot_moran_scatterplot(
    values: np.ndarray,
    W: np.ndarray,
    title: str = "Moran's I Scatterplot",
    xlabel: str = "Standardized Value",
    ylabel: str = "Spatial Lag",
    save_path: str = "artifacts/moran_scatter.png",
) -> str:
    """Plot Moran's I scatterplot (spatial lag vs. standardized value).

    Args:
        values: Array of observed values.
        W: Row-standardized spatial weights matrix.
        title: Plot title.
        xlabel: X-axis label.
        ylabel: Y-axis label.
        save_path: Path to save the figure.

    Returns:
        Path to the saved figure.
    """
    z = (values - values.mean()) / values.std()
    spatial_lag = W @ z

    fig, ax = plt.subplots(figsize=(7, 7))
    ax.scatter(z, spatial_lag, alpha=0.3, s=5, color="steelblue")
    ax.axhline(0, color="black", linewidth=0.5)
    ax.axvline(0, color="black", linewidth=0.5)

    # Regression line
    slope = np.polyfit(z, spatial_lag, 1)[0]
    x_line = np.linspace(z.min(), z.max(), 100)
    ax.plot(x_line, slope * x_line, "r-", linewidth=2, label=f"slope = {slope:.3f}")

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return save_path


def plot_lisa_map(
    lats: np.ndarray,
    lons: np.ndarray,
    quadrants: np.ndarray,
    p_values: np.ndarray,
    significance_level: float = 0.05,
    title: str = "LISA Cluster Map",
    save_path: str = "artifacts/lisa_map.png",
) -> str:
    """Plot LISA cluster map showing statistically significant clusters.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        quadrants: Array of LISA quadrant labels ('HH', 'LL', 'HL', 'LH').
        p_values: Array of pseudo p-values.
        significance_level: Threshold for statistical significance.
        title: Plot title.
        save_path: Path to save the figure.

    Returns:
        Path to the saved figure.
    """
    colors = {"HH": "red", "LL": "blue", "HL": "lightcoral", "LH": "lightblue", "NS": "lightgray"}
    labels = {"HH": "High-High", "LL": "Low-Low", "HL": "High-Low", "LH": "Low-High", "NS": "Not Significant"}

    fig, ax = plt.subplots(figsize=(12, 6))
    sig_mask = p_values <= significance_level

    # Plot non-significant first
    ns_mask = ~sig_mask
    ax.scatter(lons[ns_mask], lats[ns_mask], c=colors["NS"], s=2, alpha=0.3, label=labels["NS"])

    # Plot significant clusters
    for q in ["HH", "LL", "HL", "LH"]:
        q_mask = (quadrants == q) & sig_mask
        if q_mask.sum() > 0:
            ax.scatter(lons[q_mask], lats[q_mask], c=colors[q], s=4, alpha=0.7, label=f"{labels[q]} (n={q_mask.sum()})")

    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title(title)
    ax.legend(markerscale=3, fontsize=8)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return save_path


def plot_richness_by_realm(
    df,
    realm_col: str = "REALM",
    richness_col: str = "Richness",
    diversity_col: str = "Shannon",
    title: str = "Bird Richness vs Land-use Diversity by Realm",
    save_path: str = "artifacts/richness_by_realm.png",
) -> str:
    """Plot bird richness vs land-use diversity faceted by biogeographic realm.

    Args:
        df: DataFrame with realm, richness, and diversity columns.
        realm_col: Column name for biogeographic realm.
        richness_col: Column name for species richness.
        diversity_col: Column name for land-use diversity (Shannon index).
        title: Plot title.
        save_path: Path to save the figure.

    Returns:
        Path to the saved figure.
    """
    realms = sorted(df[realm_col].dropna().unique())
    n_realms = len(realms)
    ncols = 3
    nrows = (n_realms + ncols - 1) // ncols

    fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 4 * nrows))
    axes = axes.flatten()

    for i, realm in enumerate(realms):
        ax = axes[i]
        sub = df[df[realm_col] == realm]
        ax.scatter(sub[diversity_col], sub[richness_col], s=3, alpha=0.3, color="steelblue")
        ax.set_title(f"{realm} (n={len(sub)})")
        ax.set_xlabel("Land-use diversity (Shannon)")
        ax.set_ylabel("Taxonomic richness")

        # Fit and plot lowess-like trend
        try:
            z = np.polyfit(sub[diversity_col].values, sub[richness_col].values, 2)
            x_s = np.linspace(sub[diversity_col].min(), sub[diversity_col].max(), 100)
            ax.plot(x_s, np.polyval(z, x_s), "r-", linewidth=2)
        except Exception:
            pass

    for j in range(i + 1, len(axes)):
        axes[j].set_visible(False)

    fig.suptitle(title, fontsize=14, y=1.02)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return save_path
