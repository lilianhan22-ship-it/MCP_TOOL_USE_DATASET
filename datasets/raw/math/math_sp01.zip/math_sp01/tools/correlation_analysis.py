"""Correlation and association analysis tools."""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional
from scipy import stats


def pearson_correlation(x: np.ndarray, y: np.ndarray) -> Dict[str, float]:
    """Compute Pearson correlation coefficient with p-value.

    Args:
        x: First variable array.
        y: Second variable array.

    Returns:
        Dictionary with 'r', 'p_value'.
    """
    r, p = stats.pearsonr(x, y)
    return {"r": float(r), "p_value": float(p)}


def spearman_correlation(x: np.ndarray, y: np.ndarray) -> Dict[str, float]:
    """Compute Spearman rank correlation coefficient with p-value.

    Args:
        x: First variable array.
        y: Second variable array.

    Returns:
        Dictionary with 'rho', 'p_value'.
    """
    rho, p = stats.spearmanr(x, y)
    return {"rho": float(rho), "p_value": float(p)}


def correlation_matrix(
    df: pd.DataFrame,
    columns: List[str],
    method: str = "pearson",
) -> pd.DataFrame:
    """Compute pairwise correlation matrix.

    Args:
        df: Input DataFrame.
        columns: List of column names.
        method: Correlation method ('pearson' or 'spearman').

    Returns:
        Correlation matrix as DataFrame.
    """
    return df[columns].corr(method=method)


def partial_correlation(
    x: np.ndarray,
    y: np.ndarray,
    covariates: np.ndarray,
) -> Dict[str, float]:
    """Compute partial correlation between x and y controlling for covariates.

    Args:
        x: First variable array.
        y: Second variable array.
        covariates: Matrix of confounding variables to control for (n, k).

    Returns:
        Dictionary with 'r_partial', 'p_value'.
    """
    if covariates.ndim == 1:
        covariates = covariates.reshape(-1, 1)

    # Residualize x and y on covariates
    C = np.column_stack([np.ones(len(x)), covariates])
    beta_x = np.linalg.lstsq(C, x, rcond=None)[0]
    beta_y = np.linalg.lstsq(C, y, rcond=None)[0]
    res_x = x - C @ beta_x
    res_y = y - C @ beta_y

    r, p = stats.pearsonr(res_x, res_y)
    return {"r_partial": float(r), "p_value": float(p)}


def residual_spatial_autocorrelation(
    residuals: np.ndarray,
    lats: np.ndarray,
    lons: np.ndarray,
    k: int = 8,
    permutations: int = 199,
) -> Dict[str, float]:
    """Test for residual spatial autocorrelation with Global Moran's I.

    Builds a row-standardized k-nearest-neighbour spatial weights matrix from the
    point coordinates and evaluates Global Moran's I on the model residuals using
    a permutation-based pseudo p-value. This is a proper spatial-weights diagnostic
    (a value near the expected -1/(n-1) with a non-significant p-value indicates no
    residual spatial structure), unlike a residual-vs-coordinate correlation.

    The weights matrix is sparse, so memory scales as O(n*k) and the test runs on
    tens of thousands of grid cells.

    Args:
        residuals: Model residuals array (n,).
        lats: Latitude array (n,).
        lons: Longitude array (n,).
        k: Number of nearest neighbours used to build the weights matrix.
        permutations: Number of random permutations for the pseudo p-value.

    Returns:
        Dictionary with 'morans_i', 'expected_i', 'z_score', 'p_value'.
    """
    try:
        from .distance_matrix import knn_weights_sparse
        from .spatial_autocorrelation import global_morans_i
    except ImportError:
        try:
            from distance_matrix import knn_weights_sparse
            from spatial_autocorrelation import global_morans_i
        except ImportError:
            from tools.distance_matrix import knn_weights_sparse
            from tools.spatial_autocorrelation import global_morans_i

    residuals = np.asarray(residuals, dtype=float)
    lats = np.asarray(lats, dtype=float)
    lons = np.asarray(lons, dtype=float)
    W = knn_weights_sparse(lats, lons, k=k)
    res = global_morans_i(residuals, W, permutations=permutations)
    return {
        "morans_i": float(res["I"]),
        "expected_i": float(res["expected_I"]),
        "z_score": float(res["z_score"]),
        "p_value": float(res["p_value"]),
    }
