"""Bootstrap confidence interval estimation tools."""

import numpy as np
from typing import Callable, Dict, Optional, Tuple


def bootstrap_ci(
    data: np.ndarray,
    statistic_func: Callable,
    n_bootstrap: int = 1000,
    confidence_level: float = 0.95,
    seed: Optional[int] = None,
) -> Dict[str, float]:
    """Compute bootstrap confidence intervals for a statistic.

    Args:
        data: Input data array.
        statistic_func: Function that takes an array and returns a scalar statistic.
        n_bootstrap: Number of bootstrap resamples.
        confidence_level: Confidence level (e.g., 0.95 for 95% CI).
        seed: Random seed for reproducibility.

    Returns:
        Dictionary with 'estimate', 'ci_lower', 'ci_upper', 'std_error'.
    """
    if seed is not None:
        np.random.seed(seed)

    estimate = float(statistic_func(data))
    boot_stats = np.zeros(n_bootstrap)

    for i in range(n_bootstrap):
        resample = np.random.choice(data, size=len(data), replace=True)
        boot_stats[i] = statistic_func(resample)

    alpha = 1 - confidence_level
    ci_lower = float(np.percentile(boot_stats, 100 * alpha / 2))
    ci_upper = float(np.percentile(boot_stats, 100 * (1 - alpha / 2)))
    std_error = float(boot_stats.std())

    return {
        "estimate": estimate,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "std_error": std_error,
    }


def bootstrap_correlation_ci(
    x: np.ndarray,
    y: np.ndarray,
    n_bootstrap: int = 1000,
    confidence_level: float = 0.95,
    method: str = "pearson",
    seed: Optional[int] = None,
) -> Dict[str, float]:
    """Compute bootstrap confidence interval for a correlation coefficient.

    Args:
        x: First variable array.
        y: Second variable array.
        n_bootstrap: Number of bootstrap resamples.
        confidence_level: Confidence level.
        method: Correlation method - 'pearson' or 'spearman'.
        seed: Random seed.

    Returns:
        Dictionary with 'correlation', 'ci_lower', 'ci_upper', 'p_value'.
    """
    from scipy import stats

    if seed is not None:
        np.random.seed(seed)

    if method == "pearson":
        corr_func = lambda a, b: stats.pearsonr(a, b)[0]
        r, p = stats.pearsonr(x, y)
    else:
        corr_func = lambda a, b: stats.spearmanr(a, b)[0]
        r, p = stats.spearmanr(x, y)

    boot_corrs = np.zeros(n_bootstrap)
    n = len(x)
    for i in range(n_bootstrap):
        idx = np.random.choice(n, size=n, replace=True)
        boot_corrs[i] = corr_func(x[idx], y[idx])

    alpha = 1 - confidence_level
    ci_lower = float(np.percentile(boot_corrs, 100 * alpha / 2))
    ci_upper = float(np.percentile(boot_corrs, 100 * (1 - alpha / 2)))

    return {
        "correlation": float(r),
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "p_value": float(p),
    }


def bootstrap_regression_ci(
    X: np.ndarray,
    y: np.ndarray,
    n_bootstrap: int = 1000,
    confidence_level: float = 0.95,
    seed: Optional[int] = None,
) -> Dict[str, object]:
    """Compute bootstrap confidence intervals for regression coefficients.

    Args:
        X: Predictor matrix (n, p).
        y: Response vector (n,).
        n_bootstrap: Number of bootstrap resamples.
        confidence_level: Confidence level.
        seed: Random seed.

    Returns:
        Dictionary with 'coefficients', 'ci_lower', 'ci_upper' arrays.
    """
    if seed is not None:
        np.random.seed(seed)

    X_full = np.column_stack([np.ones(len(y)), X])
    n, p = X_full.shape
    boot_coefs = np.zeros((n_bootstrap, p))

    for i in range(n_bootstrap):
        idx = np.random.choice(n, size=n, replace=True)
        beta = np.linalg.lstsq(X_full[idx], y[idx], rcond=None)[0]
        boot_coefs[i] = beta

    alpha = 1 - confidence_level
    coefs = np.linalg.lstsq(X_full, y, rcond=None)[0]
    ci_lower = np.percentile(boot_coefs, 100 * alpha / 2, axis=0)
    ci_upper = np.percentile(boot_coefs, 100 * (1 - alpha / 2), axis=0)

    return {
        "coefficients": coefs,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
    }
