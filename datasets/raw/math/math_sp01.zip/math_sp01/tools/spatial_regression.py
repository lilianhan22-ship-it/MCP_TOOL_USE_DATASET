"""Spatial regression tools: OLS, GAM, spatial lag, and spatial error models."""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple


def ols_regression(
    X: np.ndarray,
    y: np.ndarray,
    add_intercept: bool = True,
) -> Dict[str, object]:
    """Fit an ordinary least squares regression.

    Args:
        X: Predictor matrix (n, p).
        y: Response vector (n,).
        add_intercept: Whether to add an intercept column.

    Returns:
        Dictionary with 'coefficients', 'residuals', 'r_squared', 'aic',
        'fitted_values', 'rss', 'tss'.
    """
    if add_intercept:
        X = np.column_stack([np.ones(len(y)), X])
    n, p = X.shape
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    fitted = X @ beta
    residuals = y - fitted
    rss = np.sum(residuals ** 2)
    tss = np.sum((y - y.mean()) ** 2)
    r_squared = 1 - rss / tss if tss > 0 else 0.0
    # AIC: n * ln(RSS/n) + 2p
    aic = n * np.log(rss / n) + 2 * p

    return {
        "coefficients": beta,
        "residuals": residuals,
        "r_squared": float(r_squared),
        "aic": float(aic),
        "fitted_values": fitted,
        "rss": float(rss),
        "tss": float(tss),
    }


def spatial_lag_model(
    X: np.ndarray,
    y: np.ndarray,
    W: np.ndarray,
    max_iter: int = 100,
    tol: float = 1e-6,
) -> Dict[str, object]:
    """Fit a spatial lag model: y = rho*Wy + X*beta + epsilon.

    Uses iterative feasible GLS (two-stage least squares approximation).

    Args:
        X: Predictor matrix (n, p).
        y: Response vector (n,).
        W: Row-standardized spatial weights matrix (n, n).
        max_iter: Maximum iterations.
        tol: Convergence tolerance.

    Returns:
        Dictionary with 'rho', 'coefficients', 'residuals', 'r_squared',
        'aic', 'fitted_values'.
    """
    n = len(y)
    Wy = W @ y
    X_aug = np.column_stack([np.ones(n), X, Wy])
    beta_aug = np.linalg.lstsq(X_aug, y, rcond=None)[0]
    rho = beta_aug[-1]
    beta = beta_aug[:-1]

    fitted = X_aug @ beta_aug
    residuals = y - fitted
    rss = np.sum(residuals ** 2)
    tss = np.sum((y - y.mean()) ** 2)
    r_squared = 1 - rss / tss if tss > 0 else 0.0
    p = X_aug.shape[1]
    aic = n * np.log(rss / n) + 2 * p

    return {
        "rho": float(rho),
        "coefficients": beta,
        "residuals": residuals,
        "r_squared": float(r_squared),
        "aic": float(aic),
        "fitted_values": fitted,
    }


def spatial_error_model(
    X: np.ndarray,
    y: np.ndarray,
    W: np.ndarray,
    max_iter: int = 50,
) -> Dict[str, object]:
    """Fit a spatial error model: y = X*beta + u, u = lambda*Wu + epsilon.

    Uses iterative Cochrane-Orcutt-type estimation.

    Args:
        X: Predictor matrix (n, p).
        y: Response vector (n,).
        W: Row-standardized spatial weights matrix (n, n).
        max_iter: Maximum iterations.

    Returns:
        Dictionary with 'lambda_', 'coefficients', 'residuals', 'r_squared',
        'aic', 'fitted_values'.
    """
    n = len(y)
    X_full = np.column_stack([np.ones(n), X])

    # Step 1: OLS
    beta = np.linalg.lstsq(X_full, y, rcond=None)[0]
    residuals = y - X_full @ beta

    # Step 2: Estimate lambda from residuals
    Wu = W @ residuals
    lambda_ = float(np.dot(Wu, residuals) / np.dot(Wu, Wu)) if np.dot(Wu, Wu) > 0 else 0.0
    lambda_ = np.clip(lambda_, -0.99, 0.99)

    # Step 3: Filtered regression
    for _ in range(max_iter):
        y_filt = y - lambda_ * W @ y
        X_filt = X_full - lambda_ * (W @ X_full)
        beta = np.linalg.lstsq(X_filt, y_filt, rcond=None)[0]
        residuals = y - X_full @ beta
        Wu = W @ residuals
        denom = np.dot(Wu, Wu)
        new_lambda = float(np.dot(Wu, residuals) / denom) if denom > 0 else 0.0
        new_lambda = np.clip(new_lambda, -0.99, 0.99)
        if abs(new_lambda - lambda_) < 1e-6:
            break
        lambda_ = new_lambda

    fitted = X_full @ beta
    residuals = y - fitted
    rss = np.sum(residuals ** 2)
    tss = np.sum((y - y.mean()) ** 2)
    r_squared = 1 - rss / tss if tss > 0 else 0.0
    p = X_full.shape[1] + 1
    aic = n * np.log(rss / n) + 2 * p

    return {
        "lambda_": float(lambda_),
        "coefficients": beta,
        "residuals": residuals,
        "r_squared": float(r_squared),
        "aic": float(aic),
        "fitted_values": fitted,
    }


def gam_smooth_fit(
    df: pd.DataFrame,
    response_col: str,
    predictor_cols: List[str],
    coord_cols: Tuple[str, str] = ("lat", "lon"),
) -> Dict[str, object]:
    """Fit a GAM-like model with a CUBIC POLYNOMIAL coordinate basis (NOT a true
    thin-plate regression spline) plus linear terms for the supplied predictors.

    The (lat, lon) smoother is implemented as a degree-3 polynomial in lat,
    lon, lat*lon, lat^2, lon^2, lat^2*lon, lat*lon^2, lat^3, lon^3 — this is
    a cheap stand-in for the paper's mgcv thin-plate spline; it captures
    coarse spatial trend but leaves residual spatial autocorrelation that
    a true thin-plate spline would absorb. Use the function's output for
    bundled approximate AIC / deviance-explained comparisons; the absolute
    numbers will not match a true mgcv fit.

    Args:
        df: Input DataFrame.
        response_col: Name of response variable column.
        predictor_cols: List of predictor column names.
        coord_cols: Tuple of (latitude, longitude) column names.

    Returns:
        Dictionary with 'coefficients', 'residuals', 'deviance_explained',
        'aic', 'fitted_values'.
    """
    y = df[response_col].values
    lat = df[coord_cols[0]].values
    lon = df[coord_cols[1]].values

    # Build design matrix with polynomial spatial terms (degree 3)
    spatial_terms = np.column_stack([
        lat, lon, lat ** 2, lon ** 2, lat * lon,
        lat ** 3, lon ** 3, lat ** 2 * lon, lat * lon ** 2,
    ])

    X_pred = df[predictor_cols].values
    X = np.column_stack([np.ones(len(y)), X_pred, spatial_terms])

    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    fitted = X @ beta
    residuals = y - fitted
    rss = np.sum(residuals ** 2)
    tss = np.sum((y - y.mean()) ** 2)
    deviance_explained = 1 - rss / tss if tss > 0 else 0.0
    p = X.shape[1]
    n = len(y)
    aic = n * np.log(rss / n) + 2 * p

    return {
        "coefficients": beta,
        "residuals": residuals,
        "deviance_explained": float(deviance_explained),
        "aic": float(aic),
        "fitted_values": fitted,
    }


def compare_models_aic(models: Dict[str, Dict]) -> pd.DataFrame:
    """Compare multiple fitted models by AIC and R-squared/deviance explained.

    Args:
        models: Dictionary mapping model name to model result dict
                (each must have 'aic' key, optionally 'r_squared' or 'deviance_explained').

    Returns:
        DataFrame sorted by AIC with columns: model, AIC, delta_AIC, metric.
    """
    rows = []
    for name, result in models.items():
        metric = result.get("r_squared", result.get("deviance_explained", None))
        rows.append({"model": name, "AIC": result["aic"], "metric": metric})
    df = pd.DataFrame(rows).sort_values("AIC")
    df["delta_AIC"] = df["AIC"] - df["AIC"].min()
    return df.reset_index(drop=True)
