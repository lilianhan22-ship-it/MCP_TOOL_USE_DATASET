"""Spatial autocorrelation analysis tools: Global and Local Moran's I, Geary's C."""

import numpy as np
from typing import Tuple, Dict


def _is_sparse(W) -> bool:
    try:
        import scipy.sparse as sp
        return sp.issparse(W)
    except Exception:
        return False


def _W_total(W) -> float:
    """Sum of all weights S0, for dense or sparse W."""
    if _is_sparse(W):
        return float(W.sum())
    return float(np.sum(W))


def _Wz(W, z) -> np.ndarray:
    """Matrix-vector product W @ z, for dense or sparse W."""
    return np.asarray(W @ z).ravel()


def global_morans_i(
    values: np.ndarray,
    W,
    permutations: int = 999,
    seed: int = 42,
) -> Dict[str, float]:
    """Compute Global Moran's I statistic with permutation-based inference.

    Computes the numerator z' W z via a matrix-vector product so the n x n
    outer product is never materialized; accepts dense or scipy.sparse W and
    therefore scales to tens of thousands of observations when W is sparse.

    Args:
        values: Array of observed values (n,).
        W: Row-standardized spatial weights matrix (n, n), dense or sparse.
        permutations: Number of random permutations for pseudo p-value.

    Returns:
        Dictionary with keys: 'I', 'expected_I', 'z_score', 'p_value'.
    """
    values = np.asarray(values, dtype=float)
    n = len(values)
    z = values - values.mean()
    denominator = float(np.sum(z ** 2))
    S0 = _W_total(W)
    numerator = float(z @ _Wz(W, z))
    I = (n / S0) * (numerator / denominator)
    EI = -1.0 / (n - 1)

    if permutations > 0:
        rng = np.random.default_rng(int(seed))
        sim_I = np.zeros(permutations)
        for p in range(permutations):
            zp = rng.permutation(z)
            num_p = float(zp @ _Wz(W, zp))
            sim_I[p] = (n / S0) * (num_p / denominator)
        mean_sim = sim_I.mean()
        std_sim = sim_I.std()
        z_score = (I - mean_sim) / std_sim if std_sim > 0 else 0.0
        p_value = (np.sum(np.abs(sim_I) >= np.abs(I)) + 1) / (permutations + 1)
    else:
        z_score = 0.0
        p_value = 1.0

    return {"I": float(I), "expected_I": float(EI), "z_score": float(z_score), "p_value": float(p_value)}


def local_morans_i(
    values: np.ndarray,
    W,
    permutations: int = 999,
) -> Dict[str, np.ndarray]:
    """Compute Local Moran's I (LISA) for each observation.

    Args:
        values: Array of observed values (n,).
        W: Row-standardized spatial weights matrix (n, n).
        permutations: Number of random permutations for pseudo p-values.

    Returns:
        Dictionary with keys:
            'Ii': local Moran's I values (n,),
            'p_values': pseudo p-values (n,),
            'quadrant': LISA quadrant labels (n,) - 'HH', 'LL', 'HL', 'LH'.
    """
    values = np.asarray(values, dtype=float)
    n = len(values)
    z = values - values.mean()
    m2 = np.sum(z ** 2) / n
    Wz = _Wz(W, z)
    Ii = (z / m2) * Wz

    # Quadrant assignment
    quadrant = np.empty(n, dtype="U2")
    quadrant[(z > 0) & (Wz > 0)] = "HH"
    quadrant[(z < 0) & (Wz < 0)] = "LL"
    quadrant[(z > 0) & (Wz < 0)] = "HL"
    quadrant[(z < 0) & (Wz > 0)] = "LH"

    # Permutation inference
    p_values = np.ones(n)
    if permutations > 0:
        sim_Ii = np.zeros((permutations, n))
        for p in range(permutations):
            zp = np.random.permutation(z)
            m2p = np.sum(zp ** 2) / n
            Wzp = _Wz(W, zp)
            sim_Ii[p, :] = (zp / m2p) * Wzp
        for i in range(n):
            p_values[i] = (np.sum(np.abs(sim_Ii[:, i]) >= np.abs(Ii[i])) + 1) / (permutations + 1)

    return {"Ii": Ii, "p_values": p_values, "quadrant": quadrant}


def gearys_c(
    values: np.ndarray,
    W: np.ndarray,
) -> Dict[str, float]:
    """Compute Geary's C statistic for spatial autocorrelation.

    Args:
        values: Array of observed values (n,).
        W: Spatial weights matrix (n, n), not necessarily row-standardized.

    Returns:
        Dictionary with keys: 'C', 'expected_C'.
    """
    n = len(values)
    z = values - values.mean()
    S0 = np.sum(W)
    diff_sq = (values[:, np.newaxis] - values[np.newaxis, :]) ** 2
    numerator = (n - 1) * np.sum(W * diff_sq)
    denominator = 2 * S0 * np.sum(z ** 2)
    C = numerator / denominator if denominator > 0 else 1.0
    return {"C": float(C), "expected_C": 1.0}


def getis_ord_gi_star(
    values: np.ndarray,
    W: np.ndarray,
) -> np.ndarray:
    """Compute Getis-Ord Gi* statistic for hotspot analysis.

    Args:
        values: Array of observed values (n,).
        W: Spatial weights matrix (n, n), including self-weights on diagonal.

    Returns:
        Array of Gi* z-scores (n,).
    """
    n = len(values)
    x_bar = values.mean()
    s = values.std()
    Wi = W.sum(axis=1)
    W2i = (W ** 2).sum(axis=1)
    numerator = W @ values - x_bar * Wi
    denominator = s * np.sqrt((n * W2i - Wi ** 2) / (n - 1))
    denominator[denominator == 0] = 1e-10
    return numerator / denominator
