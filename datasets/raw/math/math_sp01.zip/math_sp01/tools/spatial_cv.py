"""Spatial cross-validation tools for evaluating spatial prediction models."""

import numpy as np
from typing import Dict, List, Tuple, Callable, Optional


def spatial_block_cv(
    lats: np.ndarray,
    lons: np.ndarray,
    values: np.ndarray,
    n_folds: int = 5,
    block_size: Optional[float] = None,
) -> List[Tuple[np.ndarray, np.ndarray]]:
    """Create spatially blocked cross-validation folds.

    Divides the study area into spatial blocks to ensure training and test
    data are spatially separated, avoiding optimistic performance estimates.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        values: Array of values (not used in splitting, but kept for interface consistency).
        n_folds: Number of CV folds.
        block_size: Size of spatial blocks in coordinate units.
                    Defaults to range/sqrt(n_folds).

    Returns:
        List of (train_indices, test_indices) tuples.
    """
    n = len(lats)
    if block_size is None:
        lat_range = lats.max() - lats.min()
        lon_range = lons.max() - lons.min()
        block_size = max(lat_range, lon_range) / np.sqrt(n_folds * 2)

    # Assign each point to a block
    lat_blocks = ((lats - lats.min()) / block_size).astype(int)
    lon_blocks = ((lons - lons.min()) / block_size).astype(int)
    block_ids = lat_blocks * 10000 + lon_blocks

    unique_blocks = np.unique(block_ids)
    np.random.shuffle(unique_blocks)

    # Assign blocks to folds
    fold_assignments = np.zeros(n, dtype=int)
    for i, block in enumerate(unique_blocks):
        fold_assignments[block_ids == block] = i % n_folds

    folds = []
    for f in range(n_folds):
        test_idx = np.where(fold_assignments == f)[0]
        train_idx = np.where(fold_assignments != f)[0]
        folds.append((train_idx, test_idx))

    return folds


def leave_one_out_cv(
    X: np.ndarray,
    y: np.ndarray,
) -> Dict[str, float]:
    """Perform leave-one-out cross-validation for OLS regression.

    Args:
        X: Predictor matrix (n, p).
        y: Response vector (n,).

    Returns:
        Dictionary with 'rmse', 'mae', 'r_squared'.
    """
    n = len(y)
    X_full = np.column_stack([np.ones(n), X])
    predictions = np.zeros(n)

    # Use hat matrix for efficiency
    try:
        H = X_full @ np.linalg.inv(X_full.T @ X_full) @ X_full.T
        beta = np.linalg.lstsq(X_full, y, rcond=None)[0]
        y_hat = X_full @ beta
        residuals = y - y_hat
        h_diag = np.diag(H)
        loo_residuals = residuals / (1 - h_diag)
        predictions = y - loo_residuals
    except np.linalg.LinAlgError:
        for i in range(n):
            mask = np.ones(n, dtype=bool)
            mask[i] = False
            beta_i = np.linalg.lstsq(X_full[mask], y[mask], rcond=None)[0]
            predictions[i] = X_full[i] @ beta_i

    errors = y - predictions
    rmse = float(np.sqrt(np.mean(errors ** 2)))
    mae = float(np.mean(np.abs(errors)))
    ss_res = np.sum(errors ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r_squared = float(1 - ss_res / ss_tot) if ss_tot > 0 else 0.0

    return {"rmse": rmse, "mae": mae, "r_squared": r_squared}


def compute_cv_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> Dict[str, float]:
    """Compute cross-validation performance metrics.

    Args:
        y_true: True values.
        y_pred: Predicted values.

    Returns:
        Dictionary with 'rmse', 'mae', 'r_squared', 'mape'.
    """
    errors = y_true - y_pred
    rmse = float(np.sqrt(np.mean(errors ** 2)))
    mae = float(np.mean(np.abs(errors)))
    ss_res = np.sum(errors ** 2)
    ss_tot = np.sum((y_true - y_true.mean()) ** 2)
    r_squared = float(1 - ss_res / ss_tot) if ss_tot > 0 else 0.0
    mask = y_true != 0
    mape = float(np.mean(np.abs(errors[mask] / y_true[mask])) * 100) if mask.sum() > 0 else np.nan

    return {"rmse": rmse, "mae": mae, "r_squared": r_squared, "mape": mape}
