"""Spatial cluster detection tools: DBSCAN, hotspot analysis, and richness classification."""

import numpy as np
from typing import Dict, Optional, Tuple


def dbscan_clustering(
    lats: np.ndarray,
    lons: np.ndarray,
    values: np.ndarray,
    eps: float = 2.0,
    min_samples: int = 5,
    value_threshold: Optional[float] = None,
) -> Dict[str, object]:
    """Perform DBSCAN spatial clustering on high-value points.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        values: Array of values used to filter points before clustering.
        eps: Maximum distance between two points in a cluster.
        min_samples: Minimum number of points to form a dense region.
        value_threshold: Only cluster points with values above this threshold.
                         Defaults to the 75th percentile.

    Returns:
        Dictionary with 'labels' (cluster assignments, -1=noise),
        'n_clusters', 'cluster_sizes', 'cluster_centers'.
    """
    from sklearn.cluster import DBSCAN

    if value_threshold is None:
        value_threshold = np.percentile(values, 75)

    mask = values >= value_threshold
    coords = np.column_stack([lats[mask], lons[mask]])

    clustering = DBSCAN(eps=eps, min_samples=min_samples).fit(coords)
    labels = clustering.labels_
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)

    # Full labels array
    full_labels = np.full(len(lats), -2)  # -2 = below threshold
    full_labels[mask] = labels

    # Cluster centers and sizes
    cluster_sizes = {}
    cluster_centers = {}
    for c in range(n_clusters):
        c_mask = labels == c
        cluster_sizes[c] = int(c_mask.sum())
        cluster_centers[c] = (float(coords[c_mask, 0].mean()), float(coords[c_mask, 1].mean()))

    return {
        "labels": full_labels,
        "n_clusters": n_clusters,
        "cluster_sizes": cluster_sizes,
        "cluster_centers": cluster_centers,
    }


def hotspot_classification(
    gi_star_scores: np.ndarray,
    confidence_levels: Tuple[float, ...] = (1.645, 1.96, 2.576),
) -> np.ndarray:
    """Classify points as hotspots/coldspots based on Gi* z-scores.

    Args:
        gi_star_scores: Array of Getis-Ord Gi* z-scores.
        confidence_levels: Z-score thresholds for 90%, 95%, 99% confidence.

    Returns:
        Array of classification labels:
            3 = hot spot (99%), 2 = hot spot (95%), 1 = hot spot (90%),
            0 = not significant,
            -1 = cold spot (90%), -2 = cold spot (95%), -3 = cold spot (99%).
    """
    n = len(gi_star_scores)
    classes = np.zeros(n, dtype=int)
    for i, threshold in enumerate(confidence_levels):
        classes[gi_star_scores >= threshold] = i + 1
        classes[gi_star_scores <= -threshold] = -(i + 1)
    return classes


def identify_biodiversity_hotspots(
    lats: np.ndarray,
    lons: np.ndarray,
    richness: np.ndarray,
    percentile_threshold: float = 90,
) -> Dict[str, object]:
    """Identify grid cells that qualify as biodiversity hotspots.

    Args:
        lats: Array of latitudes.
        lons: Array of longitudes.
        richness: Array of species richness values.
        percentile_threshold: Percentile above which cells are hotspots.

    Returns:
        Dictionary with 'hotspot_mask', 'threshold_value', 'n_hotspots',
        'hotspot_coords' (lat, lon pairs).
    """
    threshold = np.percentile(richness, percentile_threshold)
    mask = richness >= threshold
    hotspot_coords = np.column_stack([lats[mask], lons[mask]])

    return {
        "hotspot_mask": mask,
        "threshold_value": float(threshold),
        "n_hotspots": int(mask.sum()),
        "hotspot_coords": hotspot_coords,
    }


def eight_neighbor_hotspot_clusters(
    lats: np.ndarray,
    lons: np.ndarray,
    richness: np.ndarray,
    percentile_threshold: float = 90,
    min_cluster_size: int = 5,
) -> Dict[str, object]:
    """Find connected hotspot clusters on the bundled one-degree grid.

    Hotspots are cells at or above the richness percentile threshold. Connectivity
    uses the eight neighbouring grid positions around each cell in the sorted
    latitude/longitude grid. Clusters smaller than ``min_cluster_size`` are
    removed from the reported labels and summaries.
    """
    lats = np.asarray(lats, dtype=float)
    lons = np.asarray(lons, dtype=float)
    richness = np.asarray(richness, dtype=float)
    if not (len(lats) == len(lons) == len(richness)):
        raise ValueError("lats, lons and richness must have the same length")

    threshold = float(np.percentile(richness, percentile_threshold))
    hotspot = richness >= threshold

    lat_vals = {v: i for i, v in enumerate(sorted(np.unique(lats)))}
    lon_vals = {v: i for i, v in enumerate(sorted(np.unique(lons)))}
    grid_to_index = {(lat_vals[lat], lon_vals[lon]): i for i, (lat, lon) in enumerate(zip(lats, lons))}

    labels = np.full(len(richness), -1, dtype=int)
    raw_clusters = []
    visited = np.zeros(len(richness), dtype=bool)

    for start in np.where(hotspot)[0]:
        if visited[start]:
            continue
        stack = [int(start)]
        visited[start] = True
        members = []
        while stack:
            idx = stack.pop()
            members.append(idx)
            r, c = lat_vals[lats[idx]], lon_vals[lons[idx]]
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    if dr == 0 and dc == 0:
                        continue
                    j = grid_to_index.get((r + dr, c + dc))
                    if j is not None and hotspot[j] and not visited[j]:
                        visited[j] = True
                        stack.append(j)
        raw_clusters.append(members)

    kept = [m for m in raw_clusters if len(m) >= min_cluster_size]
    cluster_sizes = {}
    cluster_centers = {}
    for cid, members in enumerate(kept):
        labels[members] = cid
        cluster_sizes[cid] = int(len(members))
        cluster_centers[cid] = (float(lats[members].mean()), float(lons[members].mean()))

    return {
        "labels": labels,
        "threshold_value": threshold,
        "n_hotspots": int(hotspot.sum()),
        "n_clusters": int(len(kept)),
        "cluster_sizes": cluster_sizes,
        "cluster_centers": cluster_centers,
        "min_cluster_size": int(min_cluster_size),
        "percentile_threshold": float(percentile_threshold),
    }
