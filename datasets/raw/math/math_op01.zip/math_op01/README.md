# math_op01

This task is a derived low-budget return-target benchmark for bundled OR-Library portfolio instances. It is not a reproduction of the reference paper's fixed-risk-aversion result tables.

Scored standard tables are generated from the local input CSV files, fixed solver budgets, seed 7, strict exactly-K feasibility checks, and the pointwise metric in `tools/frontier_metrics.py`. The point table records 0-based row indices, 1-based asset ids, and weights for independent feasibility checks.

Standard artifacts:
- `tools.standard_artifacts.generate_standard_artifacts(task_root=".", output_dir="artifacts")` is the canonical deterministic entry point for regenerating `artifacts/Fig_1_efficient_frontiers.png`, `artifacts/Fig_2_algorithm_comparison.png`, and `artifacts/Fig_3_cardinality_sensitivity.png`.
- The generator uses the bundled auditable CSV tables and Hang Seng reference frontier; it does not rerun stochastic solvers.

Metadata paths:
- `task_content/NOTICE.md` is the declared review-visible license notice path.
- `task_content/requirements.txt` is the declared review-visible environment path.

Artifact role:
- Bundled `artifacts/Fig_*.png` files are reference answer artifacts generated from the standard CSV evidence for evaluator-side image comparison. They are not source-paper originals.
- Participant answers should generate matching portfolio diagnostic figures at the requested output paths.

Participant visibility:
- `task_content.json` contains evaluator-only answer keys, expected_results, and scoring metadata. Benchmark participants receive the model-facing instruction/ask plus released input files/tools, not the expected_results or answer keys.


Visibility manifest:
- See `task_content/VISIBILITY.md` for the authoritative participant-visible and evaluator-only file lists.
- `task_content/standard_results_k10.csv`, `task_content/standard_points_k10.csv`, `task_content/cardinality_sensitivity_hang_seng.csv`, and `artifacts/Fig_*.png` are evaluator-only reference assets.
- The model-facing prompt receives the instruction/ask and released workflow inputs/tools, not answer keys or expected_results.
