# math_op01

This task is a derived low-budget return-target benchmark for bundled OR-Library portfolio instances. It is not a reproduction of the reference paper fixed-risk-aversion result tables.

Participant-facing scope:
- Work from the bundled asset, covariance, and efficient-frontier CSV files plus the reference paper context.
- Produce the K=10 solver comparison table, target-level audit table, Hang Seng cardinality table, and three requested diagnostic figures described in the model-facing instruction.
- Treat infeasible or missing target-level outputs as penalized records: 100.0 percentage-point VRE and 100.0 percentage-point MRE before aggregation, while n_points remains the count of strictly feasible records.

Runtime:
- Install core runtime dependencies from `task_content/requirements.txt`.
- Dependency ranges are intentionally narrow and match the tested Python 3.12 environment recorded in task_content metadata.

Visibility:
- See `task_content/VISIBILITY.md` for the authoritative participant-visible and evaluator-only file lists.
