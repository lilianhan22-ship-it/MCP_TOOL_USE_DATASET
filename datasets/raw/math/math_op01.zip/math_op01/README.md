# math_op01

This task is a derived low-budget return-target benchmark for bundled OR-Library portfolio instances. It is not a reproduction of the reference paper's fixed-risk-aversion result tables.

Scored standard tables are generated from the local input CSV files, fixed solver budgets, seed 7, strict exactly-K feasibility checks, and the pointwise metric in `tools/frontier_metrics.py`. The point table records 0-based row indices, 1-based asset ids, and weights for independent feasibility checks.

Standard artifacts:
- `tools.standard_artifacts.generate_standard_artifacts(task_root=".", output_dir="artifacts")` is the canonical deterministic entry point for regenerating `artifacts/Fig_1_efficient_frontiers.png`, `artifacts/Fig_2_algorithm_comparison.png`, and `artifacts/Fig_3_cardinality_sensitivity.png`.
- The generator uses the bundled auditable CSV tables and Hang Seng reference frontier; it does not rerun stochastic solvers.

Metadata paths:
- `task_content/NOTICE.md` is the review-visible license notice path; `NOTICE.md` is a root mirror.
- `task_content/requirements.txt` is the review-visible environment path; `requirements.txt` is a root mirror.
