# math_op01

This task is a derived low-budget return-target benchmark for bundled OR-Library portfolio instances. It is not a reproduction of the reference paper fixed-risk-aversion result tables.

Public standard protocol:
- scored_k: 10.
- target_return quantiles: [0.25, 0.50, 0.75] of each bundled unconstrained frontier.
- scored solvers: GRASP, SA, GA, Tabu.
- n_runs: 1.
- seed_sequence: seed = run*42 + 7; with n_runs=1, every solver-target call uses seed 7.
- solver budgets: GRASP n_iterations=1 eps=0.01; SA max_iter=20 T_init=1.0 T_min=0.001 alpha=0.9 eps=0.01; GA pop_size=10 n_generations=5 eps=0.01; Tabu max_iter=20 n_neighbors=5 eps=0.01.
- strict feasibility: exactly K selected assets, weights sum to 1, selected weights in [0.01,1], no negative weights, and achieved return >= target_return.
- infeasible policy: infeasible or missing target records receive 100.0 percentage-point VRE and 100.0 percentage-point MRE penalties before aggregation; n_points is the count of strictly feasible records.

Deliverables:
- `task_content/standard_results_k10.csv`: index, solver, mean, vre, mre, n_points.
- `task_content/standard_points_k10.csv`: index, solver, target_return, actual_return, variance, n_feasible_runs, n_failures, selected_asset_row_indices_0based, selected_asset_ids_1based, selected_weights, feasibility_violations.
- `task_content/cardinality_sensitivity_hang_seng.csv`: same audit fields plus K. Use Hang Seng only, K values [5,10,15,20], and TopReturnEqualWeight: select the K highest-mean-return assets and hold them equally.
- `artifacts/Fig_1_efficient_frontiers.png`: Hang Seng unconstrained frontier plus feasible K=10 solver points.
- `artifacts/Fig_2_algorithm_comparison.png`: grouped bar chart of penalized Mean by index and solver.
- `artifacts/Fig_3_cardinality_sensitivity.png`: Hang Seng TopReturnEqualWeight variance and actual_return versus K.

Public helper tools:
- `tools.standard_benchmark.run_standard_k10_protocol` computes the public K=10 metric table.
- `tools.standard_benchmark.standard_tables` returns standard result rows and target-level audit rows.
- `tools.standard_benchmark.hang_seng_cardinality_sensitivity_points` returns the Hang Seng cardinality rows.
- `tools.standard_artifacts.generate_standard_artifacts` regenerates the three requested figures from the standard CSV outputs.

Runtime:
- Install core runtime dependencies from `task_content/requirements.txt`.
- Dependency ranges are intentionally narrow and match the tested Python 3.12 environment recorded in task_content metadata.

Visibility:
- See `task_content/VISIBILITY.md` for the authoritative participant-visible and evaluator-only file lists.
