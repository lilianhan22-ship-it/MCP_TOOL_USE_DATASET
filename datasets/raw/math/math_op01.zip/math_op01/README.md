# math_op01

This task is a derived low-budget return-target benchmark for bundled OR-Library portfolio instances. It is not a reproduction of the reference paper's fixed-risk-aversion result tables.

Scored standard tables are generated from the local input CSV files, fixed solver budgets, seed 7, strict exactly-K feasibility checks, and the pointwise metric in `tools/frontier_metrics.py`. The point table records 0-based row indices, 1-based asset ids, and weights for independent feasibility checks.
