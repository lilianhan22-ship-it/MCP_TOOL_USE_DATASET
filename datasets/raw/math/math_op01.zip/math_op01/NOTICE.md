# Notice

This package is a derived benchmark task for cardinality-constrained portfolio optimization.

Reference paper:

- Javier Alcazar et al., "Enhancing combinatorial optimization with classical and quantum generative models," Nature Communications 15, 2761 (2024), DOI: https://doi.org/10.1038/s41467-024-46959-5.
- The included `input_data/reference_paper/target.pdf` is the open-access Nature Communications article. The PDF text states that the article is licensed under the Creative Commons Attribution 4.0 International License (CC BY 4.0), permitting sharing and redistribution with attribution and license link: https://creativecommons.org/licenses/by/4.0/.

Portfolio benchmark data:

- `input_data/data/assets_*.csv` and `covariance_*.csv` are local task copies of OR-Library cardinality-constrained portfolio benchmark data associated with the classic Chang et al. portfolio instances. OR-Library portfolio source: http://people.brunel.ac.uk/~mastjjb/jeb/orlib/portinfo.html.
- OR-Library legal/license page: http://people.brunel.ac.uk/~mastjjb/jeb/orlib/legal.html.
- The OR-Library permission notice is retained here because the local task bundle includes redistributed OR-Library-derived portfolio instance data:

```
Copyright (c) J E Beasley

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the
Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
```

- `input_data/data/efficient_frontier_*.csv` are derived 2001-point reference-frontier files generated from the bundled asset/covariance inputs for this task's reproducible scoring workflow; they are task-derived data under the same task distribution terms as this package.

Derived task files:

- `task_content/standard_results_k10.csv`, `task_content/standard_points_k10.csv`, and `task_content/cardinality_sensitivity_hang_seng.csv` are derived tables generated from bundled input files and local tools. `standard_points_k10.csv` records zero-based row indices, one-based asset ids, selected weights, and feasibility violations for audit.
- `tools/` contains task-specific Python code authored for this package.
- Runtime versions used for the generated standard tables are pinned in `requirements.txt` and mirrored in `task_content/requirements.txt`.
