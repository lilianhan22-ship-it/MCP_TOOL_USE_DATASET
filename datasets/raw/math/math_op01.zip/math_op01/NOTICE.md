# Notice

This package is a derived benchmark task for cardinality-constrained portfolio optimization.

Included sources and provenance:

- `input_data/data/assets_*.csv`, `covariance_*.csv`, and `efficient_frontier_*.csv` are OR-Library-style portfolio benchmark inputs and derived reference-frontier files used only as task input data for reproducible evaluation.
- `input_data/reference_paper/target.pdf` is included as the task reference paper for source-context review of the problem class. The scored outputs do not reproduce the paper's fixed-risk-aversion numerical tables.
- `task_content/standard_results_k10.csv`, `task_content/standard_points_k10.csv`, and `task_content/cardinality_sensitivity_hang_seng.csv` are derived tables generated from bundled input files and local tools. `standard_points_k10.csv` records zero-based row indices, one-based asset ids, selected weights, and feasibility violations for audit.
- `tools/` contains task-specific Python code authored for this package.
- Runtime versions used for the generated standard tables are pinned in `requirements.txt` and mirrored in `task_content/requirements.txt`.

If a deployment policy requires external-paper PDFs to be handled as platform attachments rather than redistributed files, `input_data/reference_paper/target.pdf` can be replaced by the platform attachment while keeping the same citation/source role.
