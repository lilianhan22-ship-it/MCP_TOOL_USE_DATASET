# Notice

Sources included in this task bundle:

- OR-Library-style portfolio benchmark data in `input_data/data/`, redistributed here only as task input data for reproducible benchmark evaluation.
- Reference paper PDF in `input_data/reference_paper/target.pdf`, used as source context for the cardinality-constrained portfolio problem class.
- Derived tables in `task_content/standard_results_k10.csv`, `task_content/standard_points_k10.csv`, and `task_content/cardinality_sensitivity_hang_seng.csv`, generated from the bundled inputs and local tools.
- Tool code in `tools/`, authored for this task package.

The scored task is the derived return-target workflow described in `task_content/task_content.json`; paper fixed-risk-aversion numerical tables are not scored.
