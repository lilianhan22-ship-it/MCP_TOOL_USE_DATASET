# Notice

This package is a derived benchmark task for cardinality-constrained portfolio optimization.

Reference paper:

- Javier Alcazar et al., "Enhancing combinatorial optimization with classical and quantum generative models," Nature Communications 15, 2761 (2024), DOI: https://doi.org/10.1038/s41467-024-46959-5.
- The included `input_data/reference_paper/target.pdf` is the open-access Nature Communications article. The PDF text states that the article is licensed under the Creative Commons Attribution 4.0 International License (CC BY 4.0), permitting sharing and redistribution with attribution and license link: https://creativecommons.org/licenses/by/4.0/.

Portfolio benchmark data:

- `input_data/data/assets_*.csv` and `covariance_*.csv` are local task copies of OR-Library-style cardinality-constrained portfolio benchmark data associated with the classic Chang et al. portfolio instances. OR-Library public benchmark source: http://people.brunel.ac.uk/~mastjjb/jeb/orlib/portinfo.html.
- `input_data/data/efficient_frontier_*.csv` are derived 2001-point reference-frontier files generated from the bundled asset/covariance inputs for this task's reproducible scoring workflow.
- Redistribution note: these files are included as benchmark input data for non-commercial research/evaluation in this task package. If a deployment policy requires a stricter upstream license audit for OR-Library-derived data, replace these CSVs with platform-provided benchmark inputs and regenerate the standard tables with the included tools.

Derived task files:

- `task_content/standard_results_k10.csv`, `task_content/standard_points_k10.csv`, and `task_content/cardinality_sensitivity_hang_seng.csv` are derived tables generated from bundled input files and local tools. `standard_points_k10.csv` records zero-based row indices, one-based asset ids, selected weights, and feasibility violations for audit.
- `tools/` contains task-specific Python code authored for this package.
- Runtime versions used for the generated standard tables are pinned in `requirements.txt` and mirrored in `task_content/requirements.txt`.
