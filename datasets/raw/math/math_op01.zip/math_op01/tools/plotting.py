"""Plotting utilities for portfolio optimization results."""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from typing import Dict, List, Optional, Tuple


def plot_efficient_frontiers(frontiers: Dict[str, Tuple[np.ndarray, np.ndarray]],
                             title: str = "Efficient Frontiers",
                             output_path: str = "artifacts/efficient_frontiers.png",
                             xlabel: str = "Variance",
                             ylabel: str = "Expected Return") -> str:
    """Plot multiple efficient frontiers on the same axes.

    Parameters
    ----------
    frontiers : dict
        Maps label to (variances, returns) arrays.
    title : str
    output_path : str
    xlabel, ylabel : str

    Returns
    -------
    path : str
        Path to saved figure.
    """
    fig, ax = plt.subplots(1, 1, figsize=(10, 7))
    colors = plt.cm.tab10(np.linspace(0, 1, max(len(frontiers), 1)))

    for i, (label, (variances, returns)) in enumerate(frontiers.items()):
        ax.plot(variances, returns, label=label, color=colors[i],
                linewidth=2 if "unconstrained" in label.lower() else 1.5,
                linestyle="-" if "unconstrained" in label.lower() else "--")

    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_frontier_gap(return_targets: np.ndarray,
                      pct_excess: np.ndarray,
                      K_values: List[int],
                      gap_by_K: Dict[int, np.ndarray],
                      title: str = "Frontier Gap vs Return Target",
                      output_path: str = "artifacts/frontier_gap.png") -> str:
    """Plot percentage excess variance across return targets for different K.

    Parameters
    ----------
    return_targets : np.ndarray
    pct_excess : np.ndarray (unused if gap_by_K provided)
    K_values : list of int
    gap_by_K : dict mapping K to pct_excess arrays
    title : str
    output_path : str

    Returns
    -------
    path : str
    """
    fig, ax = plt.subplots(1, 1, figsize=(10, 6))

    for K in K_values:
        if K in gap_by_K:
            n = len(gap_by_K[K])
            targets = np.linspace(return_targets[0], return_targets[-1], n) if len(return_targets) != n else return_targets
            ax.plot(targets, gap_by_K[K], label=f"K={K}")

    ax.set_xlabel("Target Return", fontsize=12)
    ax.set_ylabel("% Excess Variance", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_algorithm_comparison(results: Dict[str, Dict[str, float]],
                              metric_name: str = "Mean Variance",
                              title: str = "Algorithm Comparison",
                              output_path: str = "artifacts/algorithm_comparison.png") -> str:
    """Bar chart comparing algorithms across a single metric for multiple indices.

    Parameters
    ----------
    results : dict
        Nested dict: results[index_name][algo_name] = metric_value.
    metric_name : str
    title : str
    output_path : str

    Returns
    -------
    path : str
    """
    indices = list(results.keys())
    algos = sorted(set(a for idx in results.values() for a in idx.keys()))

    fig, ax = plt.subplots(1, 1, figsize=(12, 6))
    x = np.arange(len(indices))
    width = 0.8 / max(len(algos), 1)

    for i, algo in enumerate(algos):
        values = [results[idx].get(algo, 0) for idx in indices]
        ax.bar(x + i * width - 0.4 + width / 2, values, width,
               label=algo, alpha=0.8)

    ax.set_xlabel("Market Index", fontsize=12)
    ax.set_ylabel(metric_name, fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.set_xticks(x)
    ax.set_xticklabels(indices, rotation=45, ha="right")
    ax.legend(fontsize=8, ncol=2)
    ax.grid(True, alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_convergence(histories: Dict[str, List[Dict]],
                     y_key: str = "best_variance",
                     x_key: str = "iter",
                     title: str = "Convergence Comparison",
                     output_path: str = "artifacts/convergence.png") -> str:
    """Plot convergence curves for multiple solvers.

    Parameters
    ----------
    histories : dict
        Maps solver name to list of dicts with x_key and y_key fields.
    y_key : str
    x_key : str
    title : str
    output_path : str

    Returns
    -------
    path : str
    """
    fig, ax = plt.subplots(1, 1, figsize=(10, 6))

    for name, hist in histories.items():
        x = [h[x_key] for h in hist]
        y = [h[y_key] for h in hist]
        ax.plot(x, y, label=name, linewidth=1.5)

    ax.set_xlabel(x_key.replace("_", " ").title(), fontsize=12)
    ax.set_ylabel(y_key.replace("_", " ").title(), fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_weight_distribution(weights: np.ndarray,
                             asset_labels: Optional[List[str]] = None,
                             title: str = "Portfolio Weight Distribution",
                             output_path: str = "artifacts/weights.png") -> str:
    """Bar chart of portfolio weights.

    Parameters
    ----------
    weights : np.ndarray, shape (n,)
    asset_labels : list of str, optional
    title : str
    output_path : str

    Returns
    -------
    path : str
    """
    nonzero = np.where(np.abs(weights) > 1e-8)[0]
    w_nz = weights[nonzero]

    if asset_labels is None:
        labels = [f"Asset {i+1}" for i in nonzero]
    else:
        labels = [asset_labels[i] for i in nonzero]

    fig, ax = plt.subplots(1, 1, figsize=(max(8, len(nonzero) * 0.4), 5))
    ax.bar(range(len(w_nz)), w_nz, color="steelblue", alpha=0.8)
    ax.set_xticks(range(len(w_nz)))
    ax.set_xticklabels(labels, rotation=60, ha="right", fontsize=8)
    ax.set_ylabel("Weight", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.grid(True, alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path
