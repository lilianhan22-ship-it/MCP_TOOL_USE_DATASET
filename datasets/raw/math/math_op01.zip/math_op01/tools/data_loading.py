"""Data loading and preprocessing utilities for portfolio optimization."""

import csv
import numpy as np
from typing import Tuple, List, Dict


def load_asset_data(csv_path: str) -> Tuple[np.ndarray, np.ndarray]:
    """Load asset mean returns and standard deviations from CSV.

    Parameters
    ----------
    csv_path : str
        Path to assets CSV with columns: asset_id, mean_return, std_return.

    Returns
    -------
    means : np.ndarray, shape (n,)
        Expected returns per asset.
    stds : np.ndarray, shape (n,)
        Standard deviations per asset.
    """
    means, stds = [], []
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            means.append(float(row["mean_return"]))
            stds.append(float(row["std_return"]))
    return np.array(means), np.array(stds)


def load_covariance_matrix(csv_path: str) -> np.ndarray:
    """Load covariance matrix from CSV.

    Parameters
    ----------
    csv_path : str
        Path to covariance CSV (header row with asset labels, then n rows of n floats).

    Returns
    -------
    cov : np.ndarray, shape (n, n)
        Covariance matrix.
    """
    return np.loadtxt(csv_path, delimiter=",", skiprows=1)


def load_efficient_frontier(csv_path: str) -> Tuple[np.ndarray, np.ndarray]:
    """Load reference efficient frontier points from CSV.

    Parameters
    ----------
    csv_path : str
        Path to efficient frontier CSV with columns: mean_return, variance.

    Returns
    -------
    returns : np.ndarray, shape (m,)
        Target returns (descending order, from max-return to min-variance).
    variances : np.ndarray, shape (m,)
        Corresponding portfolio variances.
    """
    returns, variances = [], []
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            returns.append(float(row["mean_return"]))
            variances.append(float(row["variance"]))
    return np.array(returns), np.array(variances)


def get_return_targets(means: np.ndarray, n_points: int = 2001) -> np.ndarray:
    """Generate equally-spaced return targets from min to max mean return.

    Parameters
    ----------
    means : np.ndarray
        Asset mean returns.
    n_points : int
        Number of target return levels.

    Returns
    -------
    targets : np.ndarray, shape (n_points,)
        Return targets from max to min.
    """
    r_min = np.min(means)
    r_max = np.max(means)
    return np.linspace(r_max, r_min, n_points)


def portfolio_stats(weights: np.ndarray, means: np.ndarray,
                    cov: np.ndarray) -> Dict[str, float]:
    """Compute portfolio return and variance for given weights.

    Parameters
    ----------
    weights : np.ndarray, shape (n,)
    means : np.ndarray, shape (n,)
    cov : np.ndarray, shape (n, n)

    Returns
    -------
    dict with keys 'return', 'variance', 'std', 'n_assets' (count of non-zero weights).
    """
    ret = float(weights @ means)
    var = float(weights @ cov @ weights)
    n_active = int(np.sum(np.abs(weights) > 1e-8))
    return {"return": ret, "variance": var, "std": np.sqrt(max(var, 0)),
            "n_assets": n_active}
