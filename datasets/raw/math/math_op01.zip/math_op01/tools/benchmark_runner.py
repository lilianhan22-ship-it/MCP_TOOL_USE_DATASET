"""Benchmark runner for comparing optimization algorithms across problem instances."""

import numpy as np
import time
from typing import Dict, List, Callable, Optional

try:
    from .cardinality_constraint import check_feasibility
    from .frontier_metrics import standardized_frontier_error
except ImportError:
    from cardinality_constraint import check_feasibility
    from frontier_metrics import standardized_frontier_error


def run_single_instance(solver_fn: Callable,
                        means: np.ndarray, cov: np.ndarray,
                        K: int, target_return: float,
                        solver_kwargs: Optional[Dict] = None,
                        n_runs: int = 5) -> Dict:
    """Run a solver multiple times on a single instance and collect statistics.

    Parameters
    ----------
    solver_fn : callable
        Signature: (means, cov, K, target_return, **kwargs) -> dict with 'variance'.
    means, cov : arrays
    K : int
    target_return : float
    solver_kwargs : dict, optional
    n_runs : int

    Returns
    -------
    dict with 'mean_var', 'median_var', 'min_var', 'max_var', 'std_var',
    'mean_time', 'all_variances'.
    """
    if solver_kwargs is None:
        solver_kwargs = {}

    variances = []
    times = []

    for run in range(n_runs):
        kw = dict(solver_kwargs)
        kw["seed"] = run * 42 + 7
        start = time.time()
        result = solver_fn(means, cov, K, target_return, **kw)
        elapsed = time.time() - start
        feasibility = check_feasibility(
            result["weights"],
            K=K,
            eps=kw.get("eps", 0.01),
            target_return=target_return,
            means=means,
            require_exact_K=True,
        )
        if result.get("feasible", True) and feasibility["feasible"]:
            variances.append(result["variance"])
            times.append(elapsed)

    if not variances:
        return {
            "mean_var": float("nan"),
            "median_var": float("nan"),
            "min_var": float("nan"),
            "max_var": float("nan"),
            "std_var": float("nan"),
            "mean_time": float("nan"),
            "all_variances": [],
        }

    variances = np.array(variances)
    return {
        "mean_var": float(np.mean(variances)),
        "median_var": float(np.median(variances)),
        "min_var": float(np.min(variances)),
        "max_var": float(np.max(variances)),
        "std_var": float(np.std(variances)),
        "mean_time": float(np.mean(times)),
        "all_variances": variances.tolist(),
    }


def run_benchmark_suite(solvers: Dict[str, Callable],
                        means: np.ndarray, cov: np.ndarray,
                        K: int,
                        return_targets: np.ndarray,
                        solver_kwargs: Optional[Dict[str, Dict]] = None,
                        n_runs: int = 3) -> Dict:
    """Run all solvers across all return targets.

    Parameters
    ----------
    solvers : dict mapping name to callable
    means, cov : arrays
    K : int
    return_targets : np.ndarray
    solver_kwargs : dict mapping solver name to kwargs dict
    n_runs : int

    Returns
    -------
    dict mapping solver_name to dict with 'returns', 'variances' arrays.
    """
    if solver_kwargs is None:
        solver_kwargs = {}

    results = {}
    for name, fn in solvers.items():
        kwargs = solver_kwargs.get(name, {})
        rets = []
        vars_ = []
        for t in return_targets:
            stats = run_single_instance(fn, means, cov, K, t,
                                        solver_kwargs=kwargs, n_runs=n_runs)
            if np.isfinite(stats["min_var"]):
                rets.append(t)
                vars_.append(stats["min_var"])

        results[name] = {
            "returns": np.array(rets),
            "variances": np.array(vars_),
        }

    return results


def aggregate_metrics(solver_results: Dict[str, Dict],
                      ref_returns: np.ndarray,
                      ref_variances: np.ndarray) -> Dict[str, Dict]:
    """Compute standardized frontier-error metrics for each solver.

    Parameters
    ----------
    solver_results : output of run_benchmark_suite
    ref_returns, ref_variances : np.ndarray
        Unconstrained reference frontier. Solver frontiers are compared by
        interpolation at their actual feasible returns, so dropping infeasible
        targets cannot misalign arrays by position.

    Returns
    -------
    dict mapping solver name to metrics dict.
    """
    metrics = {}
    for name, data in solver_results.items():
        if len(data.get("returns", [])) == 0:
            metrics[name] = {"mean": float("nan"), "vre": float("nan"), "mre": float("nan"), "n_points": 0}
            continue
        err = standardized_frontier_error(
            data["returns"], data["variances"], ref_returns, ref_variances
        )
        err["n_points"] = int(len(data["returns"]))
        metrics[name] = err

    return metrics
