"""Benchmark runner for comparing optimization algorithms across problem instances."""

import numpy as np
import time
from typing import Dict, List, Callable, Optional


def run_single_instance(solver_fn: Callable,
                        means: np.ndarray, cov: np.ndarray,
                        K: int, target_return: float,
                        solver_kwargs: Optional[Dict] = None,
                        n_runs: int = 5) -> Dict:
    """Run a solver multiple times on a single instance and collect statistics.

    Parameters
    ----------
    solver_fn : callable
        Signature: (means, cov, K, target_return, **kwargs) -> dict with 'variance'.
    means, cov : arrays
    K : int
    target_return : float
    solver_kwargs : dict, optional
    n_runs : int

    Returns
    -------
    dict with 'mean_var', 'median_var', 'min_var', 'max_var', 'std_var',
    'mean_time', 'all_variances'.
    """
    if solver_kwargs is None:
        solver_kwargs = {}

    variances = []
    times = []

    for run in range(n_runs):
        kw = dict(solver_kwargs)
        kw["seed"] = run * 42 + 7
        start = time.time()
        result = solver_fn(means, cov, K, target_return, **kw)
        elapsed = time.time() - start
        variances.append(result["variance"])
        times.append(elapsed)

    variances = np.array(variances)
    return {
        "mean_var": float(np.mean(variances)),
        "median_var": float(np.median(variances)),
        "min_var": float(np.min(variances)),
        "max_var": float(np.max(variances)),
        "std_var": float(np.std(variances)),
        "mean_time": float(np.mean(times)),
        "all_variances": variances.tolist(),
    }


def run_benchmark_suite(solvers: Dict[str, Callable],
                        means: np.ndarray, cov: np.ndarray,
                        K: int,
                        return_targets: np.ndarray,
                        solver_kwargs: Optional[Dict[str, Dict]] = None,
                        n_runs: int = 3) -> Dict:
    """Run all solvers across all return targets.

    Parameters
    ----------
    solvers : dict mapping name to callable
    means, cov : arrays
    K : int
    return_targets : np.ndarray
    solver_kwargs : dict mapping solver name to kwargs dict
    n_runs : int

    Returns
    -------
    dict mapping solver_name to dict with 'returns', 'variances' arrays.
    """
    if solver_kwargs is None:
        solver_kwargs = {}

    results = {}
    for name, fn in solvers.items():
        kwargs = solver_kwargs.get(name, {})
        rets = []
        vars_ = []
        for t in return_targets:
            stats = run_single_instance(fn, means, cov, K, t,
                                        solver_kwargs=kwargs, n_runs=n_runs)
            rets.append(t)
            vars_.append(stats["min_var"])

        results[name] = {
            "returns": np.array(rets),
            "variances": np.array(vars_),
        }

    return results


def aggregate_metrics(solver_results: Dict[str, Dict],
                      unconstrained_vars: np.ndarray,
                      return_targets: np.ndarray) -> Dict[str, Dict]:
    """Compute summary metrics for each solver relative to unconstrained frontier.

    Parameters
    ----------
    solver_results : output of run_benchmark_suite
    unconstrained_vars : np.ndarray
    return_targets : np.ndarray

    Returns
    -------
    dict mapping solver name to metrics dict.
    """
    metrics = {}
    for name, data in solver_results.items():
        c_vars = data["variances"]
        n = min(len(c_vars), len(unconstrained_vars))
        c_v = c_vars[:n]
        u_v = unconstrained_vars[:n]
        valid = u_v > 1e-15

        if np.any(valid):
            pct_excess = (c_v[valid] - u_v[valid]) / u_v[valid] * 100
            mean_pe = float(np.mean(pct_excess))
            max_pe = float(np.max(pct_excess))
            ratios = c_v[valid] / u_v[valid]
            vre = float(np.mean(ratios))
        else:
            mean_pe = max_pe = vre = 0.0

        metrics[name] = {
            "mean_pct_excess": mean_pe,
            "max_pct_excess": max_pe,
            "vre": vre,
            "mean_variance": float(np.mean(c_v)),
            "min_variance": float(np.min(c_v)),
        }

    return metrics
