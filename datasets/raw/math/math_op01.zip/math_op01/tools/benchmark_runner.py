"""Benchmark runner for comparing optimization algorithms across problem instances."""

import numpy as np
import time
from typing import Dict, List, Callable, Optional

try:
    from .cardinality_constraint import check_feasibility
except ImportError:
    from cardinality_constraint import check_feasibility


def run_single_instance(solver_fn: Callable,
                        means: np.ndarray, cov: np.ndarray,
                        K: int, target_return: float,
                        solver_kwargs: Optional[Dict] = None,
                        n_runs: int = 5) -> Dict:
    """Run a solver multiple times on a single instance and collect statistics.

    Parameters
    ----------
    solver_fn : callable
        Signature: (means, cov, K, target_return, **kwargs) -> dict with 'variance'.
    means, cov : arrays
    K : int
    target_return : float
    solver_kwargs : dict, optional
    n_runs : int

    Returns
    -------
    dict with 'mean_var', 'median_var', 'min_var', 'max_var', 'std_var',
    'mean_time', 'all_variances'.
    """
    if solver_kwargs is None:
        solver_kwargs = {}

    variances = []
    times = []

    for run in range(n_runs):
        kw = dict(solver_kwargs)
        kw["seed"] = run * 42 + 7
        start = time.time()
        result = solver_fn(means, cov, K, target_return, **kw)
        elapsed = time.time() - start
        feasibility = check_feasibility(
            result["weights"],
            K=K,
            eps=kw.get("eps", 0.01),
            target_return=target_return,
            means=means,
            require_exact_K=True,
        )
        if result.get("feasible", True) and feasibility["feasible"]:
            variances.append(result["variance"])
            times.append(elapsed)

    if not variances:
        return {
            "mean_var": float("nan"),
            "median_var": float("nan"),
            "min_var": float("nan"),
            "max_var": float("nan"),
            "std_var": float("nan"),
            "mean_time": float("nan"),
            "all_variances": [],
        }

    variances = np.array(variances)
    return {
        "mean_var": float(np.mean(variances)),
        "median_var": float(np.median(variances)),
        "min_var": float(np.min(variances)),
        "max_var": float(np.max(variances)),
        "std_var": float(np.std(variances)),
        "mean_time": float(np.mean(times)),
        "all_variances": variances.tolist(),
    }


def run_benchmark_suite(solvers: Dict[str, Callable],
                        means: np.ndarray, cov: np.ndarray,
                        K: int,
                        return_targets: np.ndarray,
                        solver_kwargs: Optional[Dict[str, Dict]] = None,
                        n_runs: int = 3) -> Dict:
    """Run all solvers across all return targets.

    Parameters
    ----------
    solvers : dict mapping name to callable
    means, cov : arrays
    K : int
    return_targets : np.ndarray
    solver_kwargs : dict mapping solver name to kwargs dict
    n_runs : int

    Returns
    -------
    dict mapping solver_name to dict with 'returns', 'variances' arrays.
    """
    if solver_kwargs is None:
        solver_kwargs = {}

    results = {}
    for name, fn in solvers.items():
        kwargs = solver_kwargs.get(name, {})
        rets = []
        vars_ = []
        for t in return_targets:
            stats = run_single_instance(fn, means, cov, K, t,
                                        solver_kwargs=kwargs, n_runs=n_runs)
            if np.isfinite(stats["min_var"]):
                rets.append(t)
                vars_.append(stats["min_var"])

        results[name] = {
            "returns": np.array(rets),
            "variances": np.array(vars_),
        }

    return results


def aggregate_metrics(solver_results: Dict[str, Dict],
                      unconstrained_returns: np.ndarray,
                      unconstrained_vars: np.ndarray,
                      return_targets: np.ndarray = None) -> Dict[str, Dict]:
    """Compute summary metrics for each solver relative to the unconstrained frontier.

    Aligns the heuristic frontier against the unconstrained reference by
    INTERPOLATING the unconstrained variance at each heuristic frontier's
    achieved return level (matching the convention used by
    ``tools.frontier_metrics.standardized_frontier_error``). The previous
    implementation truncated by index position, which silently mismatched
    return levels after infeasible points were dropped from the frontier.

    Parameters
    ----------
    solver_results : dict
        ``{solver_name: {'returns': ndarray, 'variances': ndarray, ...}}``
        as emitted by ``compute_constrained_frontier``.
    unconstrained_returns : np.ndarray
        Return levels of the 2001-point unconstrained reference frontier.
    unconstrained_vars : np.ndarray
        Variances at those return levels (same length as ``unconstrained_returns``).
    return_targets : np.ndarray, optional
        Ignored (kept only for backward-compatibility with older call
        sites that passed the raw target grid); alignment uses the
        heuristic's ACHIEVED returns, not the requested targets.
    """
    order = np.argsort(unconstrained_returns)
    ref_r = np.asarray(unconstrained_returns, dtype=float)[order]
    ref_v = np.asarray(unconstrained_vars, dtype=float)[order]

    metrics = {}
    for name, data in solver_results.items():
        c_r = np.asarray(data.get("returns", []), dtype=float)
        c_v = np.asarray(data.get("variances", []), dtype=float)
        if c_v.size == 0:
            metrics[name] = {"mean_pct_excess": 0.0, "max_pct_excess": 0.0,
                             "vre": 0.0, "mean_variance": 0.0, "min_variance": 0.0}
            continue
        in_range = (c_r >= ref_r[0]) & (c_r <= ref_r[-1])
        if not np.any(in_range):
            metrics[name] = {"mean_pct_excess": 0.0, "max_pct_excess": 0.0,
                             "vre": 0.0, "mean_variance": float(np.mean(c_v)),
                             "min_variance": float(np.min(c_v))}
            continue
        u_v_at_c_r = np.interp(c_r[in_range], ref_r, ref_v)
        c_v_aligned = c_v[in_range]
        valid = u_v_at_c_r > 1e-15
        if np.any(valid):
            pct_excess = (c_v_aligned[valid] - u_v_at_c_r[valid]) / u_v_at_c_r[valid] * 100
            mean_pe = float(np.mean(pct_excess))
            max_pe = float(np.max(pct_excess))
            ratios = c_v_aligned[valid] / u_v_at_c_r[valid]
            vre = float(np.mean(ratios))
        else:
            mean_pe = max_pe = vre = 0.0
        metrics[name] = {
            "mean_pct_excess": mean_pe,
            "max_pct_excess": max_pe,
            "vre": vre,
            "mean_variance": float(np.mean(c_v)),
            "min_variance": float(np.min(c_v)),
        }
    return metrics
