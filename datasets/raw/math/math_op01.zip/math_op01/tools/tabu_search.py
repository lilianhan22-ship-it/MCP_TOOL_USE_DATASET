"""Tabu search solver for cardinality-constrained portfolio optimization.

Tabu search maintains a list of recently visited solutions to avoid cycling,
combined with neighborhood search via asset swaps.
"""

import numpy as np
from scipy.optimize import minimize
from typing import Dict, Optional, List


def tabu_portfolio(means: np.ndarray, cov: np.ndarray,
                   K: int, target_return: float,
                   tabu_tenure: int = 10,
                   max_iter: int = 2000,
                   n_neighbors: int = 30,
                   eps: float = 0.01,
                   seed: Optional[int] = None) -> Dict:
    """Tabu search for cardinality-constrained min-variance portfolio.

    Parameters
    ----------
    means : np.ndarray, shape (n,)
    cov : np.ndarray, shape (n, n)
    K : int
    target_return : float
    tabu_tenure : int
        Number of iterations a move stays tabu.
    max_iter : int
    n_neighbors : int
        Number of neighbors to evaluate per iteration.
    eps : float
        Minimum weight.
    seed : int, optional

    Returns
    -------
    dict with 'weights', 'variance', 'return', 'n_iter', 'history'.
    """
    if seed is not None:
        np.random.seed(seed)

    n = len(means)

    # Initialize with highest-return assets
    sorted_idx = np.argsort(means)[::-1]
    current_sel = np.sort(sorted_idx[:K])

    def solve_inner(sel):
        """Solve QP for given selection."""
        K_act = len(sel)
        sub_cov = cov[np.ix_(sel, sel)]
        sub_means = means[sel]
        result = minimize(
            lambda wa: wa @ sub_cov @ wa,
            np.ones(K_act) / K_act,
            method="SLSQP",
            constraints=[{"type": "eq", "fun": lambda wa: np.sum(wa) - 1}],
            bounds=[(eps, 1)] * K_act,
            options={"ftol": 1e-14},
        )
        full_w = np.zeros(n)
        if result.success:
            full_w[sel] = result.x
        else:
            full_w[sel] = np.ones(K_act) / K_act
        return full_w, float(full_w @ cov @ full_w)

    current_w, current_var = solve_inner(current_sel)
    best_w = current_w.copy()
    best_var = current_var

    # Tabu list: maps (asset_out, asset_in) -> iteration when it becomes non-tabu
    tabu_list: Dict = {}
    history = []

    for it in range(max_iter):
        best_neighbor_var = np.inf
        best_neighbor_sel = None
        best_move = None

        unselected = np.setdiff1d(np.arange(n), current_sel)

        # Generate neighbors by swapping one asset
        moves = []
        for _ in range(min(n_neighbors, K * len(unselected))):
            i_out = np.random.randint(K)
            i_in = np.random.choice(unselected)
            moves.append((i_out, i_in))

        for i_out, i_in in moves:
            move = (current_sel[i_out], i_in)

            # Check tabu
            is_tabu = move in tabu_list and tabu_list[move] > it

            new_sel = current_sel.copy()
            new_sel[i_out] = i_in
            new_sel = np.sort(new_sel)

            new_w, new_var = solve_inner(new_sel)
            new_ret = float(new_w @ means)

            # Aspiration: accept tabu move if it improves best known
            if new_var < best_neighbor_var:
                if not is_tabu or new_var < best_var:
                    best_neighbor_var = new_var
                    best_neighbor_sel = new_sel.copy()
                    best_move = move

        if best_neighbor_sel is not None:
            current_sel = best_neighbor_sel
            current_w, current_var = solve_inner(current_sel)

            if best_move is not None:
                tabu_list[best_move] = it + tabu_tenure
                # Also make reverse move tabu
                tabu_list[(best_move[1], best_move[0])] = it + tabu_tenure

            if current_var < best_var:
                best_w = current_w.copy()
                best_var = current_var

        if it % 100 == 0:
            history.append({"iter": it, "best_variance": best_var,
                            "current_variance": current_var})

    achieved_ret = float(best_w @ means)
    feasible = (target_return is None) or (achieved_ret >= target_return - 1e-8)

    return {
        "weights": best_w,
        "variance": best_var,
        "return": achieved_ret,
        "feasible": feasible,
        "status": "feasible" if feasible else "infeasible: target return not met",
        "n_iter": max_iter,
        "history": history,
    }
