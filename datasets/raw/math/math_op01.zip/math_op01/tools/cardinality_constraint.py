"""Cardinality-constrained portfolio optimization solvers.

The cardinality-constrained problem adds a constraint that at most K assets
can have non-zero weights, turning the QP into an NP-hard mixed-integer QP.
"""

import numpy as np
from typing import Dict, Optional, Tuple


def encode_portfolio(selected: np.ndarray, weights_active: np.ndarray,
                     n_total: int) -> np.ndarray:
    """Encode a cardinality-constrained portfolio as full weight vector.

    Parameters
    ----------
    selected : np.ndarray of int, shape (K,)
        Indices of selected assets.
    weights_active : np.ndarray, shape (K,)
        Weights for selected assets (must sum to 1, each >= 0).
    n_total : int
        Total number of assets.

    Returns
    -------
    weights : np.ndarray, shape (n_total,)
    """
    w = np.zeros(n_total)
    w[selected] = weights_active
    return w


def decode_portfolio(weights: np.ndarray,
                     threshold: float = 1e-8) -> Tuple[np.ndarray, np.ndarray]:
    """Extract selected assets and their weights from a full weight vector.

    Parameters
    ----------
    weights : np.ndarray, shape (n,)
    threshold : float
        Minimum weight to consider an asset selected.

    Returns
    -------
    selected : np.ndarray of int
    active_weights : np.ndarray
    """
    mask = np.abs(weights) > threshold
    return np.where(mask)[0], weights[mask]


def repair_weights(weights_active: np.ndarray,
                   eps: float = 0.01,
                   delta: float = 1.0) -> np.ndarray:
    """Repair weights to satisfy budget, lower and upper bound constraints.

    Ensures: sum = 1, each weight in [eps, delta].

    Parameters
    ----------
    weights_active : np.ndarray, shape (K,)
    eps : float
        Minimum weight per asset.
    delta : float
        Maximum weight per asset.

    Returns
    -------
    repaired : np.ndarray, shape (K,)
    """
    K = len(weights_active)
    w = np.clip(weights_active, eps, delta)
    # Normalize to sum to 1
    w = w / np.sum(w)
    # Re-clip and re-normalize iteratively
    for _ in range(50):
        w = np.clip(w, eps, delta)
        s = np.sum(w)
        if abs(s - 1.0) < 1e-12:
            break
        w = w / s
    return w


def random_portfolio(n: int, K: int,
                     eps: float = 0.01) -> Tuple[np.ndarray, np.ndarray]:
    """Generate a random feasible cardinality-constrained portfolio.

    Parameters
    ----------
    n : int
        Total assets.
    K : int
        Cardinality constraint.
    eps : float
        Minimum weight per selected asset.

    Returns
    -------
    selected : np.ndarray of int, shape (K,)
    weights : np.ndarray, shape (K,)
    """
    selected = np.sort(np.random.choice(n, K, replace=False))
    raw = np.random.dirichlet(np.ones(K))
    weights = repair_weights(raw, eps=eps)
    return selected, weights


def check_feasibility(weights: np.ndarray,
                      K: int,
                      eps: float = 0.01,
                      delta: float = 1.0,
                      target_return: Optional[float] = None,
                      means: Optional[np.ndarray] = None,
                      tol: float = 1e-6,
                      select_threshold: float = 1e-8,
                      require_exact_K: bool = True) -> Dict[str, object]:
    """Check whether a portfolio satisfies all problem constraints.

    Verifies, for the cardinality-constrained mean-variance problem:
      * budget:       sum(w) == 1
      * cardinality:  number of selected assets (|w_i| > select_threshold)
                      == K (when ``require_exact_K`` is True, the default,
                      matching the OR-Library / Chang et al. 2000
                      formulation) or <= K otherwise.
      * weight bounds: every selected weight lies in [eps, delta]
      * no shorting:  all weights >= 0
      * target return (optional): w'mu >= target_return

    Parameters
    ----------
    weights : np.ndarray, shape (n,)
    K : int
        Maximum cardinality.
    eps : float
        Minimum weight for a selected asset.
    delta : float
        Maximum weight per asset.
    target_return : float, optional
        If given (with ``means``), require w'mu >= target_return.
    means : np.ndarray, optional
        Asset mean returns, needed only when ``target_return`` is given.
    tol : float
        Numerical tolerance for the budget and bound checks.
    select_threshold : float
        Weight magnitude above which an asset counts as "selected".

    Returns
    -------
    dict
        'feasible': bool (all constraints satisfied),
        'status': 'feasible' or a short reason string,
        'n_selected': int,
        'budget_error': float,
        'violations': list[str].
    """
    w = np.asarray(weights, dtype=float)
    selected = np.where(np.abs(w) > select_threshold)[0]
    n_selected = int(len(selected))
    budget_error = float(abs(np.sum(w) - 1.0))
    violations = []

    if budget_error > tol:
        violations.append(f"budget: sum(w)={np.sum(w):.6f} != 1")
    if require_exact_K:
        if n_selected != K:
            violations.append(f"cardinality: {n_selected} selected != K={K} (exactly-K required)")
    elif n_selected > K:
        violations.append(f"cardinality: {n_selected} selected > K={K}")
    if np.any(w < -tol):
        violations.append("negative weights present")
    if selected.size and np.any(w[selected] < eps - tol):
        violations.append(f"weight below lower bound eps={eps}")
    if selected.size and np.any(w[selected] > delta + tol):
        violations.append(f"weight above upper bound delta={delta}")
    if target_return is not None and means is not None:
        achieved = float(w @ np.asarray(means, dtype=float))
        if achieved < target_return - tol:
            violations.append(
                f"target return: achieved {achieved:.6f} < target {target_return:.6f}")

    feasible = len(violations) == 0
    return {
        "feasible": feasible,
        "status": "feasible" if feasible else "infeasible: " + "; ".join(violations),
        "n_selected": n_selected,
        "budget_error": budget_error,
        "violations": violations,
    }


def evaluate_portfolio(weights: np.ndarray, means: np.ndarray,
                       cov: np.ndarray) -> Dict[str, float]:
    """Evaluate portfolio return and variance.

    Parameters
    ----------
    weights : np.ndarray, shape (n,)
    means : np.ndarray, shape (n,)
    cov : np.ndarray, shape (n, n)

    Returns
    -------
    dict with 'return', 'variance'.
    """
    return {
        "return": float(weights @ means),
        "variance": float(weights @ cov @ weights),
    }
