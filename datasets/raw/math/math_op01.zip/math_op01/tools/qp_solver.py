"""Quadratic programming solvers for unconstrained portfolio optimization."""

import numpy as np
from scipy.optimize import minimize
from typing import Optional, Tuple, Dict


def solve_min_variance_qp(cov: np.ndarray, means: np.ndarray,
                          target_return: float,
                          allow_short: bool = False,
                          n_restarts: int = 5) -> Dict:
    """Solve min-variance portfolio for a given target return using QP.

    min  w' C w
    s.t. w' mu = target_return
         sum(w) = 1
         w >= 0  (if allow_short=False)

    Parameters
    ----------
    cov : np.ndarray, shape (n, n)
    means : np.ndarray, shape (n,)
    target_return : float
    allow_short : bool
        If True, allow negative weights (short selling).
    n_restarts : int
        Number of random restarts for SLSQP.

    Returns
    -------
    dict with 'weights', 'variance', 'return', 'success'.
    """
    n = len(means)
    bounds = None if allow_short else [(0, 1)] * n

    best_var = np.inf
    best_w = None
    success = False

    for trial in range(n_restarts):
        if trial == 0:
            w0 = np.ones(n) / n
        else:
            w0 = np.random.dirichlet(np.ones(n))

        result = minimize(
            lambda w: w @ cov @ w, w0,
            method="SLSQP",
            jac=lambda w: 2 * cov @ w,
            constraints=[
                {"type": "eq", "fun": lambda w: np.sum(w) - 1},
                {"type": "eq", "fun": lambda w: w @ means - target_return},
            ],
            bounds=bounds,
            options={"ftol": 1e-15, "maxiter": 5000},
        )
        if result.success and result.fun < best_var:
            best_var = result.fun
            best_w = result.x.copy()
            success = True

    if best_w is None:
        best_w = np.ones(n) / n
        best_var = float(best_w @ cov @ best_w)

    return {
        "weights": best_w,
        "variance": best_var,
        "return": float(best_w @ means),
        "success": success,
    }


def compute_unconstrained_frontier(cov: np.ndarray, means: np.ndarray,
                                   n_points: int = 200,
                                   allow_short: bool = False) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute the unconstrained efficient frontier (no cardinality limit).

    Parameters
    ----------
    cov : np.ndarray, shape (n, n)
    means : np.ndarray, shape (n,)
    n_points : int
        Number of points on the frontier.
    allow_short : bool
        If True, allow short selling.

    Returns
    -------
    returns : np.ndarray, shape (m,)
    variances : np.ndarray, shape (m,)
    weights_list : np.ndarray, shape (m, n)
    """
    r_min = np.min(means)
    r_max = np.max(means)
    targets = np.linspace(r_max, r_min, n_points)

    returns_out = []
    variances_out = []
    weights_out = []

    for t in targets:
        sol = solve_min_variance_qp(cov, means, t,
                                    allow_short=allow_short, n_restarts=3)
        if sol["success"]:
            returns_out.append(sol["return"])
            variances_out.append(sol["variance"])
            weights_out.append(sol["weights"])

    return (np.array(returns_out), np.array(variances_out),
            np.array(weights_out))


def analytical_frontier_short(cov: np.ndarray, means: np.ndarray,
                              n_points: int = 200) -> Tuple[np.ndarray, np.ndarray]:
    """Compute efficient frontier analytically (short selling allowed).

    Uses closed-form Lagrange multiplier solution.

    Parameters
    ----------
    cov : np.ndarray, shape (n, n)
    means : np.ndarray, shape (n,)
    n_points : int

    Returns
    -------
    returns : np.ndarray
    variances : np.ndarray
    """
    ones = np.ones(len(means))
    cov_inv = np.linalg.inv(cov)
    A = float(means @ cov_inv @ means)
    B = float(means @ cov_inv @ ones)
    C = float(ones @ cov_inv @ ones)
    D = A * C - B * B

    r_targets = np.linspace(np.max(means), np.min(means), n_points)
    variances = (C * r_targets**2 - 2 * B * r_targets + A) / D

    return r_targets, variances
