"""Deterministic low-budget benchmark protocol for the scored K=10 task."""

import numpy as np
from typing import Dict

try:
    from .data_loading import load_asset_data, load_covariance_matrix, load_efficient_frontier
    from .benchmark_runner import run_benchmark_suite, aggregate_metrics
    from .grasp_solver import grasp_portfolio
    from .simulated_annealing import sa_portfolio
    from .genetic_algorithm import ga_portfolio
    from .tabu_search import tabu_portfolio
except ImportError:
    from data_loading import load_asset_data, load_covariance_matrix, load_efficient_frontier
    from benchmark_runner import run_benchmark_suite, aggregate_metrics
    from grasp_solver import grasp_portfolio
    from simulated_annealing import sa_portfolio
    from genetic_algorithm import ga_portfolio
    from tabu_search import tabu_portfolio

INDICES = ["Hang_Seng", "DAX_100", "FTSE_100", "SP_100", "Nikkei_225"]
TARGET_QUANTILES = [0.25, 0.50, 0.75]
SOLVER_KWARGS = {
    "GRASP": {"n_iterations": 1, "eps": 0.01},
    "SA": {"max_iter": 20, "T_init": 1.0, "T_min": 1e-3, "alpha": 0.90, "eps": 0.01},
    "GA": {"pop_size": 10, "n_generations": 5, "eps": 0.01},
    "Tabu": {"max_iter": 20, "n_neighbors": 5, "eps": 0.01},
}
SOLVERS = {
    "GRASP": grasp_portfolio,
    "SA": sa_portfolio,
    "GA": ga_portfolio,
    "Tabu": tabu_portfolio,
}


def target_returns_from_reference(ref_returns: np.ndarray) -> np.ndarray:
    """Return the three central target-return quantiles used for scoring."""
    return np.quantile(np.sort(np.asarray(ref_returns, dtype=float)), TARGET_QUANTILES)


def run_standard_k10_protocol(data_dir: str = "input_data/data") -> Dict[str, Dict[str, Dict[str, float]]]:
    """Run the fixed K=10, three-target, one-run benchmark protocol.

    Infeasible solver outputs are filtered by benchmark_runner.run_single_instance,
    which calls check_feasibility(..., require_exact_K=True). Returned n_points can
    therefore be below three for solvers that do not produce feasible portfolios at
    all target returns.
    """
    out = {}
    for index in INDICES:
        means, _ = load_asset_data(f"{data_dir}/assets_{index}.csv")
        cov = load_covariance_matrix(f"{data_dir}/covariance_{index}.csv")
        ref_returns, ref_vars = load_efficient_frontier(f"{data_dir}/efficient_frontier_{index}.csv")
        targets = target_returns_from_reference(ref_returns)
        frontiers = run_benchmark_suite(
            SOLVERS, means, cov, 10, targets, solver_kwargs=SOLVER_KWARGS, n_runs=1
        )
        out[index] = aggregate_metrics(frontiers, ref_returns, ref_vars)
    return out


def standard_tables(data_dir: str = "input_data/data"):
    """Return metric rows and point-level audit rows for the scored protocol."""
    rows = []
    point_rows = []
    for index in INDICES:
        means, _ = load_asset_data(f"{data_dir}/assets_{index}.csv")
        cov = load_covariance_matrix(f"{data_dir}/covariance_{index}.csv")
        ref_returns, ref_vars = load_efficient_frontier(f"{data_dir}/efficient_frontier_{index}.csv")
        targets = target_returns_from_reference(ref_returns)
        frontiers = run_benchmark_suite(
            SOLVERS, means, cov, 10, targets, solver_kwargs=SOLVER_KWARGS, n_runs=1
        )
        metrics = aggregate_metrics(frontiers, ref_returns, ref_vars)
        for solver, metric in metrics.items():
            rows.append({
                "index": index, "solver": solver,
                "mean": round(metric["mean"], 4),
                "vre": round(metric["vre"], 4),
                "mre": round(metric["mre"], 4),
                "n_points": int(metric["n_points"]),
            })
            for rec in frontiers[solver]["point_records"]:
                point_rows.append({
                    "index": index, "solver": solver,
                    "target_return": rec["target_return"],
                    "actual_return": rec["actual_return"],
                    "variance": rec["variance"],
                    "n_feasible_runs": rec["n_feasible_runs"],
                    "n_failures": len(rec["failures"]),
                })
    return rows, point_rows


def hang_seng_cardinality_sensitivity_points(data_dir: str = "input_data/data"):
    """Return cheap audited Hang Seng K-sensitivity rows.

    This plot-support protocol is intentionally deterministic and lightweight:
    for each K, select the K highest-mean-return assets and hold them equally.
    It is not used for solver scoring; it supplies machine-checkable Fig. 3
    reference points without running slow stochastic optimizers.
    """
    index = "Hang_Seng"
    means, _ = load_asset_data(f"{data_dir}/assets_{index}.csv")
    cov = load_covariance_matrix(f"{data_dir}/covariance_{index}.csv")
    ref_returns, _ = load_efficient_frontier(f"{data_dir}/efficient_frontier_{index}.csv")
    targets = target_returns_from_reference(ref_returns)
    rows = []
    for K in [5, 10, 15, 20]:
        selected = np.argsort(means)[-K:]
        weights = np.zeros_like(means, dtype=float)
        weights[selected] = 1.0 / K
        actual_return = float(weights @ means)
        variance = float(weights @ cov @ weights)
        for target in targets:
            rows.append({
                "index": index,
                "solver": "TopReturnEqualWeight",
                "K": K,
                "target_return": float(target),
                "actual_return": actual_return,
                "variance": variance,
                "n_feasible_runs": int(actual_return >= target),
                "n_failures": int(actual_return < target),
            })
    return rows
