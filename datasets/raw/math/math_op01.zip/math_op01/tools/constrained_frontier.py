"""Compute cardinality-constrained efficient frontiers using multiple solvers."""

import numpy as np
from typing import Dict, List, Callable, Optional, Tuple


def compute_constrained_frontier(solver_fn: Callable,
                                 means: np.ndarray,
                                 cov: np.ndarray,
                                 K: int,
                                 return_targets: np.ndarray,
                                 solver_kwargs: Optional[Dict] = None
                                 ) -> Dict:
    """Compute a cardinality-constrained efficient frontier by solving at each return target.

    Parameters
    ----------
    solver_fn : callable
        Solver function with signature (means, cov, K, target_return, **kwargs) -> dict.
        Must return dict with 'weights', 'variance', 'return'.
    means : np.ndarray, shape (n,)
    cov : np.ndarray, shape (n, n)
    K : int
    return_targets : np.ndarray, shape (m,)
    solver_kwargs : dict, optional

    Returns
    -------
    dict with 'returns', 'variances', 'weights_list', 'n_solved'.
    """
    if solver_kwargs is None:
        solver_kwargs = {}

    returns_out = []
    variances_out = []
    weights_out = []

    for t in return_targets:
        try:
            sol = solver_fn(means, cov, K, t, **solver_kwargs)
            returns_out.append(sol["return"])
            variances_out.append(sol["variance"])
            weights_out.append(sol["weights"])
        except Exception:
            continue

    return {
        "returns": np.array(returns_out),
        "variances": np.array(variances_out),
        "weights_list": weights_out,
        "n_solved": len(returns_out),
    }


def extract_pareto_front(returns: np.ndarray,
                         variances: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Extract non-dominated (Pareto-optimal) points from return-variance pairs.

    Maximize return, minimize variance.

    Parameters
    ----------
    returns : np.ndarray
    variances : np.ndarray

    Returns
    -------
    pareto_returns : np.ndarray
    pareto_variances : np.ndarray
    """
    n = len(returns)
    dominated = np.zeros(n, dtype=bool)

    for i in range(n):
        if dominated[i]:
            continue
        for j in range(n):
            if i == j or dominated[j]:
                continue
            # j dominates i if j has >= return and <= variance (strictly better in at least one)
            if (returns[j] >= returns[i] and variances[j] <= variances[i] and
                (returns[j] > returns[i] or variances[j] < variances[i])):
                dominated[i] = True
                break

    mask = ~dominated
    order = np.argsort(returns[mask])[::-1]
    return returns[mask][order], variances[mask][order]


def frontier_gap(constrained_vars: np.ndarray,
                 unconstrained_vars: np.ndarray,
                 constrained_returns: np.ndarray,
                 unconstrained_returns: np.ndarray) -> Dict:
    """Compute gap metrics between constrained and unconstrained frontiers.

    For each constrained point, finds the nearest unconstrained point at the
    same return level via interpolation and computes excess variance.

    Parameters
    ----------
    constrained_vars, unconstrained_vars : np.ndarray
    constrained_returns, unconstrained_returns : np.ndarray

    Returns
    -------
    dict with 'mean_pct_excess', 'max_pct_excess', 'median_pct_excess',
    'mean_abs_excess'.
    """
    # Interpolate unconstrained frontier at constrained return levels
    # unconstrained should be sorted by return (descending)
    uc_order = np.argsort(unconstrained_returns)
    uc_ret_sorted = unconstrained_returns[uc_order]
    uc_var_sorted = unconstrained_vars[uc_order]

    pct_excess = []
    abs_excess = []

    for i in range(len(constrained_returns)):
        r = constrained_returns[i]
        # Only compare within the unconstrained return range
        if r < uc_ret_sorted[0] or r > uc_ret_sorted[-1]:
            continue
        uc_var_at_r = np.interp(r, uc_ret_sorted, uc_var_sorted)
        if uc_var_at_r > 1e-15:
            pe = (constrained_vars[i] - uc_var_at_r) / uc_var_at_r * 100
            pct_excess.append(pe)
            abs_excess.append(constrained_vars[i] - uc_var_at_r)

    pct_excess = np.array(pct_excess) if pct_excess else np.array([0])
    abs_excess = np.array(abs_excess) if abs_excess else np.array([0])

    return {
        "mean_pct_excess": float(np.mean(pct_excess)),
        "max_pct_excess": float(np.max(pct_excess)),
        "median_pct_excess": float(np.median(pct_excess)),
        "mean_abs_excess": float(np.mean(abs_excess)),
    }
