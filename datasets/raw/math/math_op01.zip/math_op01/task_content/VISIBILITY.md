# Visibility Manifest

Participant-visible during solving:

- Model-facing instruction/ask extracted by the benchmark runner.
- `input_data/data/assets_*.csv`
- `input_data/data/covariance_*.csv`
- `input_data/data/efficient_frontier_*.csv`
- `input_data/reference_paper/target.pdf`
- Domain method tools in `tools/` except evaluator-support modules listed below.
- `task_content/requirements.txt` for runtime setup.
- `task_content/NOTICE.md` for source attribution and license notice.

Evaluator-only / not shown to participants during solving:

- `task_content/task_content.json` answer entries, expected_results, scoring_metadata, and evaluator checklists.
- `task_content/standard_results_k10.csv`
- `task_content/standard_points_k10.csv`
- `task_content/cardinality_sensitivity_hang_seng.csv`
- `tools/standard_benchmark.py`
- `tools/standard_artifacts.py`
- `artifacts/Fig_1_efficient_frontiers.png`
- `artifacts/Fig_2_algorithm_comparison.png`
- `artifacts/Fig_3_cardinality_sensitivity.png`

`tools/standard_benchmark.py` and `tools/standard_artifacts.py` are evaluator-support regeneration utilities for auditing the packaged answer assets. They are not model-facing prompt tools. The bundled artifacts are reference answer artifacts for evaluator-side image comparison, not source-paper originals and not participant-visible prompt content.
