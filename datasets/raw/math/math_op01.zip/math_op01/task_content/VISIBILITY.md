# Visibility Manifest

Participant-visible during solving:

- Model-facing instruction/ask extracted by the benchmark runner.
- `input_data/data/assets_*.csv`
- `input_data/data/covariance_*.csv`
- `input_data/data/efficient_frontier_*.csv`
- `input_data/reference_paper/target.pdf`
- Domain method tools in `tools/`, including public reproducibility helpers `tools/standard_benchmark.py` and `tools/standard_artifacts.py`.
- `task_content/requirements.txt` for runtime setup.
- `task_content/NOTICE.md` for source attribution and license notice.

Evaluator-only / not shown to participants during solving:

- `task_content/task_content.json` answer entries, expected_results, scoring_metadata, and evaluator checklists.
- Bundled answer CSVs: `task_content/standard_results_k10.csv`, `task_content/standard_points_k10.csv`, and `task_content/cardinality_sensitivity_hang_seng.csv`.
- Bundled reference answer images: `artifacts/Fig_1_efficient_frontiers.png`, `artifacts/Fig_2_algorithm_comparison.png`, and `artifacts/Fig_3_cardinality_sensitivity.png`.

The model-facing instruction and README disclose the complete public protocol needed to regenerate the answer tables and figures; the bundled CSVs and PNGs are evaluator-side references.
