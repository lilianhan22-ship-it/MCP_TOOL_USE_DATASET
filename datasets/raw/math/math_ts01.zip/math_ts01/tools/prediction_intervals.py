"""Prediction interval construction from point forecasts."""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple


def rolling_residual_sd(
    observed: np.ndarray,
    predicted: np.ndarray,
    window: int = 20,
) -> np.ndarray:
    """Compute rolling standard deviation of forecast residuals.

    Parameters
    ----------
    observed : np.ndarray
    predicted : np.ndarray
    window : int
        Rolling window size for computing residual SD.

    Returns
    -------
    np.ndarray
        Array of rolling SDs, same length as inputs.
    """
    residuals = observed - predicted
    n = len(residuals)
    sd = np.full(n, np.nan)
    for i in range(window, n):
        block = residuals[i - window : i]
        valid = block[~np.isnan(block)]
        if len(valid) >= 3:
            sd[i] = np.std(valid, ddof=1)
    return sd


def optimal_window_for_coverage(
    observed: np.ndarray,
    predicted: np.ndarray,
    target_coverage: float = 0.90,
    window_candidates: Optional[List[int]] = None,
) -> int:
    """Find rolling window size that achieves closest to target coverage.

    Parameters
    ----------
    observed : np.ndarray
    predicted : np.ndarray
    target_coverage : float
    window_candidates : list of int or None
        Window sizes to test. Defaults to range(5, 51).

    Returns
    -------
    int
        Optimal window size.
    """
    if window_candidates is None:
        window_candidates = list(range(5, 51))

    best_window = 20
    best_diff = np.inf

    for w in window_candidates:
        sd = rolling_residual_sd(observed, predicted, window=w)
        valid = ~np.isnan(sd) & ~np.isnan(observed) & ~np.isnan(predicted)
        if valid.sum() < 10:
            continue

        z = 1.645  # ~90%
        lower = predicted[valid] - z * sd[valid]
        upper = predicted[valid] + z * sd[valid]
        cov = np.mean((observed[valid] >= lower) & (observed[valid] <= upper))
        diff = abs(cov - target_coverage)
        if diff < best_diff:
            best_diff = diff
            best_window = w

    return best_window


def construct_prediction_interval(
    predicted: np.ndarray,
    residual_sd: np.ndarray,
    coverage: float = 0.90,
) -> Tuple[np.ndarray, np.ndarray]:
    """Construct normal-distribution-based prediction interval.

    Parameters
    ----------
    predicted : np.ndarray
        Point forecasts.
    residual_sd : np.ndarray
        Standard deviation of residuals (from rolling window).
    coverage : float
        Desired coverage level (e.g. 0.50, 0.90, 0.95).

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        (lower_bound, upper_bound)
    """
    from scipy import stats

    z = stats.norm.ppf(0.5 + coverage / 2)
    lower = predicted - z * residual_sd
    upper = predicted + z * residual_sd
    return lower, upper


def empirical_quantile(
    residuals: np.ndarray,
    predicted: np.ndarray,
    coverage: float = 0.90,
) -> "Tuple[np.ndarray, np.ndarray]":
    """Empirical-residual prediction interval at the requested coverage.

    The non-parametric counterpart to :func:`prediction_quantiles`: takes
    the empirical (1-coverage)/2 and 1-(1-coverage)/2 residual quantiles
    (no Gaussian assumption) and adds them to ``predicted`` to form
    (lower, upper). This is the prediction-interval entry point referenced
    in the BUNDLE-SCORED forecast-trajectory answer item.
    """
    lo_q = (1 - coverage) / 2.0
    hi_q = 1 - lo_q
    lo_res = float(np.quantile(residuals, lo_q))
    hi_res = float(np.quantile(residuals, hi_q))
    return predicted + lo_res, predicted + hi_res


def prediction_quantiles(
    predicted: np.ndarray,
    residual_sd: np.ndarray,
    quantiles: Optional[List[float]] = None,
) -> Dict[float, np.ndarray]:
    """Generate prediction quantiles assuming normal distribution.

    Parameters
    ----------
    predicted : np.ndarray
    residual_sd : np.ndarray
    quantiles : list of float or None
        Quantile levels. Defaults to standard WIS quantiles.

    Returns
    -------
    dict
        {quantile_level: array of quantile values}
    """
    from scipy import stats

    if quantiles is None:
        quantiles = [0.025, 0.1, 0.25, 0.5, 0.75, 0.9, 0.975]

    result = {}
    for q in quantiles:
        z = stats.norm.ppf(q)
        result[q] = predicted + z * residual_sd
    return result


def bootstrap_prediction_interval(
    residuals: np.ndarray,
    predicted: np.ndarray,
    coverage: float = 0.90,
    n_boot: int = 1000,
    random_state: int = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """Construct prediction interval via bootstrap resampling of residuals.

    Parameters
    ----------
    residuals : np.ndarray
        Historical forecast residuals (observed - predicted).
    predicted : np.ndarray
        Current point forecasts.
    coverage : float
    n_boot : int
    random_state : int

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        (lower_bound, upper_bound)
    """
    rng = np.random.RandomState(random_state)
    clean_residuals = residuals[~np.isnan(residuals)]
    if len(clean_residuals) < 5:
        return predicted - 1.0, predicted + 1.0

    alpha = 1 - coverage
    boot_samples = rng.choice(clean_residuals, size=(n_boot, len(predicted)), replace=True)
    boot_values = predicted[np.newaxis, :] + boot_samples

    lower = np.percentile(boot_values, 100 * alpha / 2, axis=0)
    upper = np.percentile(boot_values, 100 * (1 - alpha / 2), axis=0)
    return lower, upper
