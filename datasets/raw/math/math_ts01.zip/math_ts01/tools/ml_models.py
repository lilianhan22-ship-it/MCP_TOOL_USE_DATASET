"""Machine learning forecasting models: Random Forest and XGBoost."""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple


def fit_random_forest_forecast(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    n_estimators: int = 500,
    max_depth: Optional[int] = None,
    min_samples_leaf: int = 5,
    random_state: int = 42,
    n_jobs: int = 1,
) -> Dict[str, np.ndarray]:
    """Fit Random Forest regressor and produce forecasts.

    Parameters
    ----------
    X_train : np.ndarray
        Training feature matrix (n_samples, n_features).
    y_train : np.ndarray
        Training target values.
    X_test : np.ndarray
        Test feature matrix.
    n_estimators : int
        Number of trees.
    max_depth : int or None
        Maximum tree depth.
    min_samples_leaf : int
        Minimum samples per leaf.
    random_state : int
    n_jobs : int
        Number of parallel jobs. Defaults to 1 for deterministic benchmark
        execution in constrained runtimes.

    Returns
    -------
    dict
        'forecast': point predictions,
        'feature_importance': array of feature importances.
    """
    from sklearn.ensemble import RandomForestRegressor

    rf = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_leaf=min_samples_leaf,
        random_state=random_state,
        n_jobs=n_jobs,
    )
    rf.fit(X_train, y_train)
    preds = rf.predict(X_test)
    return {
        "forecast": preds,
        "feature_importance": rf.feature_importances_,
    }


def fit_xgboost_forecast(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    n_estimators: int = 500,
    max_depth: int = 6,
    learning_rate: float = 0.1,
    subsample: float = 0.8,
    random_state: int = 42,
) -> Dict[str, np.ndarray]:
    """Fit XGBoost regressor and produce forecasts.

    Parameters
    ----------
    X_train : np.ndarray
        Training feature matrix.
    y_train : np.ndarray
        Training target values.
    X_test : np.ndarray
        Test feature matrix.
    n_estimators : int
    max_depth : int
    learning_rate : float
    subsample : float
    random_state : int

    Returns
    -------
    dict
        'forecast': point predictions,
        'feature_importance': array of feature importances.
    """
    from xgboost import XGBRegressor

    xgb = XGBRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        subsample=subsample,
        random_state=random_state,
        verbosity=0,
    )
    xgb.fit(X_train, y_train)
    preds = xgb.predict(X_test)
    return {
        "forecast": preds,
        "feature_importance": xgb.feature_importances_,
    }


def rolling_ml_forecast(
    df: pd.DataFrame,
    target_col: str,
    feature_cols: List[str],
    train_start_idx: int,
    train_end_idx: int,
    test_end_idx: int,
    horizon: int = 9,
    model_type: str = "rf",
    retrain_annually: bool = True,
    **model_kwargs,
) -> pd.DataFrame:
    """Generate rolling direct multi-horizon forecasts using ML models.

    At each forecast origin ``t``, a separate direct model is fit for each
    horizon ``h`` using historical pairs ``features[i] -> target[i+h]`` with
    ``i+h < t``. Because same-week and future weather are unavailable at the
    forecast origin, the latest observed feature row ``features[t-1]`` is then
    queried by every horizon-specific model. This prevents future predictor
    leakage and avoids the invalid shortcut of returning the same point forecast
    for all 0--8 week horizons.
    """
    results = []
    target = df[target_col].values
    features = df[feature_cols].values
    current_models = {}

    for t in range(train_end_idx + 1, test_end_idx + 1):
        need_retrain = not current_models
        if retrain_annually and "monthid" in df.columns:
            if df["monthid"].iloc[t] == 11 and (
                t == train_end_idx + 1
                or df["monthid"].iloc[t - 1] != 11
            ):
                need_retrain = True

        if need_retrain:
            current_models = {}
            for h in range(horizon):
                end_x = t - h
                if end_x <= train_start_idx:
                    continue
                X_tr = features[train_start_idx:end_x]
                y_tr = target[train_start_idx + h:t]
                valid = ~np.isnan(X_tr).any(axis=1) & ~np.isnan(y_tr)
                X_h, y_h = X_tr[valid], y_tr[valid]
                if len(y_h) < 10:
                    continue

                if model_type == "rf":
                    from sklearn.ensemble import RandomForestRegressor
                    model = RandomForestRegressor(
                        n_estimators=model_kwargs.get("n_estimators", 500),
                        max_depth=model_kwargs.get("max_depth", None),
                        random_state=42 + h,
                        n_jobs=model_kwargs.get("n_jobs", 1),
                    )
                else:
                    from xgboost import XGBRegressor
                    model = XGBRegressor(
                        n_estimators=model_kwargs.get("n_estimators", 500),
                        max_depth=model_kwargs.get("max_depth", 6),
                        learning_rate=model_kwargs.get("learning_rate", 0.1),
                        random_state=42 + h,
                        verbosity=0,
                    )
                model.fit(X_h, y_h)
                current_models[h] = model

        # At forecast origin t, only information through t-1 is known.
        # Meteorological predictors for the target week are not used; the
        # latest observed predictor row is persisted across all horizons.
        origin_idx = t - 1
        if origin_idx < 0 or origin_idx >= len(features) or np.isnan(features[origin_idx]).any():
            origin_feat = None
        else:
            origin_feat = features[origin_idx : origin_idx + 1]

        for h in range(min(horizon, test_end_idx - t + 1)):
            idx = t + h
            if origin_feat is not None and h in current_models:
                fc = current_models[h].predict(origin_feat)[0]
            else:
                fc = np.nan
            results.append({
                "forecast_origin": t,
                "horizon": h,
                "forecast": fc,
                "observed": target[idx] if idx < len(target) else np.nan,
            })

    return pd.DataFrame(results)

def compute_feature_importance(
    X_train: np.ndarray,
    y_train: np.ndarray,
    feature_names: List[str],
    model_type: str = "rf",
) -> pd.DataFrame:
    """Compute and return ranked feature importances.

    Parameters
    ----------
    X_train : np.ndarray
    y_train : np.ndarray
    feature_names : list of str
    model_type : str
        'rf' or 'xgb'.

    Returns
    -------
    pd.DataFrame
        Columns: 'feature', 'importance', sorted descending.
    """
    if model_type == "rf":
        from sklearn.ensemble import RandomForestRegressor

        model = RandomForestRegressor(n_estimators=500, random_state=42, n_jobs=1)
    else:
        from xgboost import XGBRegressor

        model = XGBRegressor(n_estimators=500, random_state=42, verbosity=0)

    valid = ~np.isnan(X_train).any(axis=1) & ~np.isnan(y_train)
    model.fit(X_train[valid], y_train[valid])
    imp = model.feature_importances_
    result = pd.DataFrame({"feature": feature_names, "importance": imp})
    return result.sort_values("importance", ascending=False).reset_index(drop=True)
