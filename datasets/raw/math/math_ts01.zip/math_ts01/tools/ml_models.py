"""Machine learning forecasting models: Random Forest and XGBoost."""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple


def fit_random_forest_forecast(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    n_estimators: int = 500,
    max_depth: Optional[int] = None,
    min_samples_leaf: int = 5,
    random_state: int = 42,
) -> Dict[str, np.ndarray]:
    """Fit Random Forest regressor and produce forecasts.

    Parameters
    ----------
    X_train : np.ndarray
        Training feature matrix (n_samples, n_features).
    y_train : np.ndarray
        Training target values.
    X_test : np.ndarray
        Test feature matrix.
    n_estimators : int
        Number of trees.
    max_depth : int or None
        Maximum tree depth.
    min_samples_leaf : int
        Minimum samples per leaf.
    random_state : int

    Returns
    -------
    dict
        'forecast': point predictions,
        'feature_importance': array of feature importances.
    """
    from sklearn.ensemble import RandomForestRegressor

    rf = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_leaf=min_samples_leaf,
        random_state=random_state,
        n_jobs=-1,
    )
    rf.fit(X_train, y_train)
    preds = rf.predict(X_test)
    return {
        "forecast": preds,
        "feature_importance": rf.feature_importances_,
    }


def fit_xgboost_forecast(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    n_estimators: int = 500,
    max_depth: int = 6,
    learning_rate: float = 0.1,
    subsample: float = 0.8,
    random_state: int = 42,
) -> Dict[str, np.ndarray]:
    """Fit XGBoost regressor and produce forecasts.

    Parameters
    ----------
    X_train : np.ndarray
        Training feature matrix.
    y_train : np.ndarray
        Training target values.
    X_test : np.ndarray
        Test feature matrix.
    n_estimators : int
    max_depth : int
    learning_rate : float
    subsample : float
    random_state : int

    Returns
    -------
    dict
        'forecast': point predictions,
        'feature_importance': array of feature importances.
    """
    from xgboost import XGBRegressor

    xgb = XGBRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        subsample=subsample,
        random_state=random_state,
        verbosity=0,
    )
    xgb.fit(X_train, y_train)
    preds = xgb.predict(X_test)
    return {
        "forecast": preds,
        "feature_importance": xgb.feature_importances_,
    }


def rolling_ml_forecast(
    df: pd.DataFrame,
    target_col: str,
    feature_cols: List[str],
    train_start_idx: int,
    train_end_idx: int,
    test_end_idx: int,
    horizon: int = 9,
    model_type: str = "rf",
    retrain_annually: bool = True,
    **model_kwargs,
) -> pd.DataFrame:
    """Generate rolling multi-step forecasts using ML models.

    For each week t in the test period the model is queried with the feature
    vector that is FULLY OBSERVABLE at the forecast origin, namely the lagged
    feature row at week ``t-1`` (ILI+ is reported with a one-week delay, so
    week ``t-1`` is the most recent data available at origin ``t``). The same
    origin feature row is reused for every horizon ``h = 0 .. horizon-1``,
    because the feature rows at weeks ``t, t+1, ..., t+h`` are NOT available at
    origin ``t`` -- reading ``features[t+h]`` (as a naive implementation might)
    would leak future predictor values into the h-step-ahead forecast. ML
    models are retrained at the start of each November.

    Parameters
    ----------
    df : pd.DataFrame
    target_col : str
    feature_cols : list of str
        Column names to use as features (pre-built lagged features, where each
        row is built only from information up to that week).
    train_start_idx : int
    train_end_idx : int
    test_end_idx : int
    horizon : int
    model_type : str
        'rf' or 'xgb'.
    retrain_annually : bool
    **model_kwargs
        Additional keyword arguments for the model.

    Returns
    -------
    pd.DataFrame
        Columns: 'forecast_origin', 'horizon', 'forecast', 'observed'.
    """
    results = []
    target = df[target_col].values
    features = df[feature_cols].values
    current_model = None

    for t in range(train_end_idx + 1, test_end_idx + 1):
        # Check if we need to retrain
        need_retrain = current_model is None
        if retrain_annually and "monthid" in df.columns:
            if df["monthid"].iloc[t] == 11 and (
                t == train_end_idx + 1
                or df["monthid"].iloc[t - 1] != 11
            ):
                need_retrain = True

        if need_retrain:
            X_tr = features[train_start_idx:t]
            y_tr = target[train_start_idx:t]
            valid = ~np.isnan(X_tr).any(axis=1) & ~np.isnan(y_tr)
            X_tr, y_tr = X_tr[valid], y_tr[valid]

            if model_type == "rf":
                from sklearn.ensemble import RandomForestRegressor

                current_model = RandomForestRegressor(
                    n_estimators=model_kwargs.get("n_estimators", 500),
                    max_depth=model_kwargs.get("max_depth", None),
                    random_state=42,
                    n_jobs=-1,
                )
            else:
                from xgboost import XGBRegressor

                current_model = XGBRegressor(
                    n_estimators=model_kwargs.get("n_estimators", 500),
                    max_depth=model_kwargs.get("max_depth", 6),
                    learning_rate=model_kwargs.get("learning_rate", 0.1),
                    random_state=42,
                    verbosity=0,
                )
            current_model.fit(X_tr, y_tr)

        # Feature vector fully observable at the forecast origin: the lagged
        # row at week t-1 (most recent available data). Reused for all
        # horizons so no future predictor row (features[t+h]) is consumed.
        origin_idx = t - 1
        if origin_idx < 0 or np.isnan(features[origin_idx]).any():
            origin_feat = None
        else:
            origin_feat = features[origin_idx : origin_idx + 1]

        # Generate forecasts for each horizon
        for h in range(min(horizon, test_end_idx - t + 1)):
            idx = t + h
            if origin_feat is not None:
                fc = current_model.predict(origin_feat)[0]
            else:
                fc = np.nan
            results.append(
                {
                    "forecast_origin": t,
                    "horizon": h,
                    "forecast": fc,
                    "observed": target[idx] if idx < len(target) else np.nan,
                }
            )

    return pd.DataFrame(results)


def compute_feature_importance(
    X_train: np.ndarray,
    y_train: np.ndarray,
    feature_names: List[str],
    model_type: str = "rf",
) -> pd.DataFrame:
    """Compute and return ranked feature importances.

    Parameters
    ----------
    X_train : np.ndarray
    y_train : np.ndarray
    feature_names : list of str
    model_type : str
        'rf' or 'xgb'.

    Returns
    -------
    pd.DataFrame
        Columns: 'feature', 'importance', sorted descending.
    """
    if model_type == "rf":
        from sklearn.ensemble import RandomForestRegressor

        model = RandomForestRegressor(n_estimators=500, random_state=42, n_jobs=-1)
    else:
        from xgboost import XGBRegressor

        model = XGBRegressor(n_estimators=500, random_state=42, verbosity=0)

    valid = ~np.isnan(X_train).any(axis=1) & ~np.isnan(y_train)
    model.fit(X_train[valid], y_train[valid])
    imp = model.feature_importances_
    result = pd.DataFrame({"feature": feature_names, "importance": imp})
    return result.sort_values("importance", ascending=False).reset_index(drop=True)
