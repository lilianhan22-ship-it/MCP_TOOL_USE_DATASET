"""Machine learning forecasting models: Random Forest and XGBoost."""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple


def fit_random_forest_forecast(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    n_estimators: int = 500,
    max_depth: Optional[int] = None,
    min_samples_leaf: int = 5,
    random_state: int = 42,
) -> Dict[str, np.ndarray]:
    """Fit Random Forest regressor and produce forecasts.

    Parameters
    ----------
    X_train : np.ndarray
        Training feature matrix (n_samples, n_features).
    y_train : np.ndarray
        Training target values.
    X_test : np.ndarray
        Test feature matrix.
    n_estimators : int
        Number of trees.
    max_depth : int or None
        Maximum tree depth.
    min_samples_leaf : int
        Minimum samples per leaf.
    random_state : int

    Returns
    -------
    dict
        'forecast': point predictions,
        'feature_importance': array of feature importances.
    """
    from sklearn.ensemble import RandomForestRegressor

    rf = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_leaf=min_samples_leaf,
        random_state=random_state,
        n_jobs=-1,
    )
    rf.fit(X_train, y_train)
    preds = rf.predict(X_test)
    return {
        "forecast": preds,
        "feature_importance": rf.feature_importances_,
    }


def fit_xgboost_forecast(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    n_estimators: int = 500,
    max_depth: int = 6,
    learning_rate: float = 0.1,
    subsample: float = 0.8,
    random_state: int = 42,
) -> Dict[str, np.ndarray]:
    """Fit XGBoost regressor and produce forecasts.

    Parameters
    ----------
    X_train : np.ndarray
        Training feature matrix.
    y_train : np.ndarray
        Training target values.
    X_test : np.ndarray
        Test feature matrix.
    n_estimators : int
    max_depth : int
    learning_rate : float
    subsample : float
    random_state : int

    Returns
    -------
    dict
        'forecast': point predictions,
        'feature_importance': array of feature importances.
    """
    from xgboost import XGBRegressor

    xgb = XGBRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        subsample=subsample,
        random_state=random_state,
        verbosity=0,
    )
    xgb.fit(X_train, y_train)
    preds = xgb.predict(X_test)
    return {
        "forecast": preds,
        "feature_importance": xgb.feature_importances_,
    }


def rolling_ml_forecast(
    df: pd.DataFrame,
    target_col: str,
    feature_cols: List[str],
    train_start_idx: int,
    train_end_idx: int,
    test_end_idx: int,
    horizon: int = 9,
    model_type: str = "rf",
    retrain_annually: bool = True,
    direct_multi_step: bool = True,
    **model_kwargs,
) -> pd.DataFrame:
    """Generate rolling multi-step forecasts using ML models.

    When ``direct_multi_step=True`` (default, matching the paper's
    horizon-specific direct multi-step setup) the function fits a SEPARATE
    model per horizon ``h``: the regressor for horizon h is trained on
    ``(X[i], y[i + h])`` pairs, so each h-step-ahead prediction comes from a
    model that was directly optimised for that horizon. This produces
    genuinely different forecast values at h=0, h=1, ..., h=horizon-1 from
    the same forecast origin.

    When ``direct_multi_step=False`` (legacy behaviour) a single h=0 model
    is reused for every horizon — every horizon at the same forecast
    origin gets the SAME prediction. Use this only when you want to inspect
    the same-week direct mapping baseline; the bundled scored pipeline
    uses ``direct_multi_step=True``.

    For each week t in the test period the per-horizon model is queried with
    the feature vector that is FULLY OBSERVABLE at the forecast origin: the
    lagged feature row at week ``t`` itself. Because every lag column in
    ``build_lagged_features`` is built with ``shift(>=1)``, the row at
    week ``t`` already encodes only data from weeks ``<=t-1`` -- i.e.
    ``rate_lag1[t] = rate[t-1]``, the most recent ILI+ observation that is
    fully available at origin ``t``. The same origin row is reused across
    horizons so that the feature rows at weeks ``t+1, ..., t+h`` (which would
    leak future predictor values) are NOT consumed. ML models are retrained
    at the start of each November.

    Parameters
    ----------
    df : pd.DataFrame
    target_col : str
    feature_cols : list of str
        Column names to use as features (pre-built lagged features, where each
        row is built only from information up to that week).
    train_start_idx : int
    train_end_idx : int
    test_end_idx : int
    horizon : int
    model_type : str
        'rf' or 'xgb'.
    retrain_annually : bool
    **model_kwargs
        Additional keyword arguments for the model.

    Returns
    -------
    pd.DataFrame
        Columns: 'forecast_origin', 'horizon', 'forecast', 'observed'.
    """
    results = []
    target = df[target_col].values
    features = df[feature_cols].values
    # When direct_multi_step=True, current_models is a dict {h: fitted_regressor}
    # When direct_multi_step=False, current_model is a single regressor (legacy)
    current_models = None
    current_model = None

    def _make_regressor():
        if model_type == "rf":
            from sklearn.ensemble import RandomForestRegressor
            return RandomForestRegressor(
                n_estimators=model_kwargs.get("n_estimators", 500),
                max_depth=model_kwargs.get("max_depth", None),
                random_state=42, n_jobs=-1,
            )
        else:
            from xgboost import XGBRegressor
            return XGBRegressor(
                n_estimators=model_kwargs.get("n_estimators", 500),
                max_depth=model_kwargs.get("max_depth", 6),
                learning_rate=model_kwargs.get("learning_rate", 0.1),
                random_state=42, verbosity=0,
            )

    for t in range(train_end_idx + 1, test_end_idx + 1):
        # Check if we need to retrain
        need_retrain = (current_models is None and current_model is None)
        if retrain_annually and "monthid" in df.columns:
            if df["monthid"].iloc[t] == 11 and (
                t == train_end_idx + 1
                or df["monthid"].iloc[t - 1] != 11
            ):
                need_retrain = True

        if need_retrain:
            if direct_multi_step:
                # Fit one regressor per horizon: features[i] -> target[i+h]
                current_models = {}
                for h in range(horizon):
                    # Train rows where both features[i] and target[i+h] are observable
                    end = t - h  # exclusive upper bound so i+h < t (training stops before test period)
                    if end <= train_start_idx:
                        continue
                    X_tr = features[train_start_idx:end]
                    y_tr = target[train_start_idx + h: end + h]
                    # Trim to common length
                    n_train = min(len(X_tr), len(y_tr))
                    X_tr = X_tr[:n_train]; y_tr = y_tr[:n_train]
                    valid = ~np.isnan(X_tr).any(axis=1) & ~np.isnan(y_tr)
                    X_tr, y_tr = X_tr[valid], y_tr[valid]
                    if len(X_tr) < 10:
                        continue
                    reg = _make_regressor()
                    reg.fit(X_tr, y_tr)
                    current_models[h] = reg
            else:
                # Legacy: single h=0 model reused for every horizon
                X_tr = features[train_start_idx:t]
                y_tr = target[train_start_idx:t]
                valid = ~np.isnan(X_tr).any(axis=1) & ~np.isnan(y_tr)
                X_tr, y_tr = X_tr[valid], y_tr[valid]
                current_model = _make_regressor()
                current_model.fit(X_tr, y_tr)

        # Feature vector fully observable at the forecast origin: the lagged
        # row at week t itself. The lag columns in this row already encode
        # data only from weeks <= t-1 (build_lagged_features uses shift(>=1)
        # for every column), so reading features[t] gives the agent the most
        # recent t-1 ILI+ observation rather than the older t-2 value that
        # an earlier off-by-one (features[t-1]) gave. Reused for all
        # horizons so no future predictor row (features[t+h]) is consumed.
        origin_idx = t
        if origin_idx >= len(features) or np.isnan(features[origin_idx]).any():
            origin_feat = None
        else:
            origin_feat = features[origin_idx : origin_idx + 1]

        # Generate forecasts for each horizon
        for h in range(min(horizon, test_end_idx - t + 1)):
            idx = t + h
            if origin_feat is None:
                fc = np.nan
            elif direct_multi_step:
                # Use the per-horizon model trained on (X[i], y[i+h])
                mdl = current_models.get(h) if current_models is not None else None
                if mdl is None:
                    fc = np.nan
                else:
                    fc = mdl.predict(origin_feat)[0]
            else:
                fc = current_model.predict(origin_feat)[0]
            results.append(
                {
                    "forecast_origin": t,
                    "horizon": h,
                    "forecast": fc,
                    "observed": target[idx] if idx < len(target) else np.nan,
                }
            )

    return pd.DataFrame(results)


def compute_feature_importance(
    X_train: np.ndarray,
    y_train: np.ndarray,
    feature_names: List[str],
    model_type: str = "rf",
) -> pd.DataFrame:
    """Compute and return ranked feature importances.

    Parameters
    ----------
    X_train : np.ndarray
    y_train : np.ndarray
    feature_names : list of str
    model_type : str
        'rf' or 'xgb'.

    Returns
    -------
    pd.DataFrame
        Columns: 'feature', 'importance', sorted descending.
    """
    if model_type == "rf":
        from sklearn.ensemble import RandomForestRegressor

        model = RandomForestRegressor(n_estimators=500, random_state=42, n_jobs=-1)
    else:
        from xgboost import XGBRegressor

        model = XGBRegressor(n_estimators=500, random_state=42, verbosity=0)

    valid = ~np.isnan(X_train).any(axis=1) & ~np.isnan(y_train)
    model.fit(X_train[valid], y_train[valid])
    imp = model.feature_importances_
    result = pd.DataFrame({"feature": feature_names, "importance": imp})
    return result.sort_values("importance", ascending=False).reset_index(drop=True)
