"""Baseline constant-incidence persistence model."""

import numpy as np
import pandas as pd
from typing import Dict, Optional, Tuple


def constant_baseline_forecast(
    series: np.ndarray,
    current_idx: int,
    horizon: int = 9,
) -> np.ndarray:
    """Generate baseline forecast: ILI+ at week t = ILI+ at week t-1.

    The baseline "constant incidence" model predicts that ILI+ from
    the current week through t+horizon remains equal to the most
    recently observed value.

    Parameters
    ----------
    series : np.ndarray
        Full ILI+ time series.
    current_idx : int
        Index of the most recent available observation (week t-1).
    horizon : int
        Number of forecast steps.

    Returns
    -------
    np.ndarray
        Array of constant forecasts.
    """
    last_val = series[current_idx]
    return np.full(horizon, last_val)


def rolling_baseline_forecast(
    df: pd.DataFrame,
    target_col: str,
    train_end_idx: int,
    test_end_idx: int,
    horizon: int = 9,
) -> pd.DataFrame:
    """Generate rolling baseline forecasts over the test period.

    Parameters
    ----------
    df : pd.DataFrame
    target_col : str
    train_end_idx : int
    test_end_idx : int
    horizon : int

    Returns
    -------
    pd.DataFrame
        Columns: 'forecast_origin', 'horizon', 'forecast', 'observed'.
    """
    target = df[target_col].values
    results = []

    for t in range(train_end_idx + 1, test_end_idx + 1):
        fc = constant_baseline_forecast(target, t - 1, horizon)
        for h in range(min(horizon, test_end_idx - t + 1)):
            idx = t + h
            results.append(
                {
                    "forecast_origin": t,
                    "horizon": h,
                    "forecast": fc[h],
                    "observed": target[idx] if idx < len(target) else np.nan,
                }
            )

    return pd.DataFrame(results)


def baseline_prediction_interval(
    series: np.ndarray,
    current_idx: int,
    horizon: int = 9,
    window: int = 20,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Generate baseline prediction interval using historical differences.

    Compute SD from positive/negative 1-week differences in past
    observations and construct normal prediction interval.

    Parameters
    ----------
    series : np.ndarray
    current_idx : int
    horizon : int
    window : int
        Number of past weeks to compute difference SD.

    Returns
    -------
    Tuple
        (forecast, lower_90, upper_90)
    """
    from scipy import stats

    fc = constant_baseline_forecast(series, current_idx, horizon)
    start = max(0, current_idx - window)
    diffs = np.diff(series[start : current_idx + 1])
    sd = np.std(diffs, ddof=1) if len(diffs) > 1 else 1.0
    z = stats.norm.ppf(0.95)  # 90% interval
    lower = fc - z * sd
    upper = fc + z * sd
    return fc, lower, upper
