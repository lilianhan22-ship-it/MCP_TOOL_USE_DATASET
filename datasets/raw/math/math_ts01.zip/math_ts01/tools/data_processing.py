"""Data processing utilities for influenza time series forecasting."""

import pandas as pd
import numpy as np
from typing import List, Optional, Tuple


def load_influenza_data(csv_path: str) -> pd.DataFrame:
    """Load weekly influenza activity (ILI+) time series from CSV.

    Parameters
    ----------
    csv_path : str
        Path to the CSV file containing weekly ILI+ data.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns including 'date', 'weekid', 'rate',
        meteorological variables, and 'monthid'.
    """
    df = pd.read_csv(csv_path)
    # Standardise date parsing
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").reset_index(drop=True)
    return df


def split_train_test(
    df: pd.DataFrame,
    train_end: str,
    test_start: str,
    date_col: str = "date",
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Split time series into training and testing periods.

    Parameters
    ----------
    df : pd.DataFrame
        Full dataset.
    train_end : str
        Last date (inclusive) of the training period, e.g. '2007-10-31'.
    test_start : str
        First date (inclusive) of the test period, e.g. '2007-11-01'.
    date_col : str
        Name of the date column.

    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame]
        (train_df, test_df)
    """
    train = df[df[date_col] <= pd.Timestamp(train_end)].copy()
    test = df[df[date_col] >= pd.Timestamp(test_start)].copy()
    return train, test


def exclude_period(
    df: pd.DataFrame,
    start: str,
    end: str,
    date_col: str = "date",
) -> pd.DataFrame:
    """Remove rows within a date range (inclusive).

    Parameters
    ----------
    df : pd.DataFrame
    start, end : str
        Date strings for exclusion boundaries.
    date_col : str

    Returns
    -------
    pd.DataFrame
    """
    mask = (df[date_col] >= pd.Timestamp(start)) & (
        df[date_col] <= pd.Timestamp(end)
    )
    return df[~mask].reset_index(drop=True)


def select_meteorological_predictors(
    df: pd.DataFrame,
    target_col: str = "rate",
    candidate_cols: Optional[List[str]] = None,
    n_select: int = 5,
) -> List[str]:
    """Select top meteorological predictors by Pearson correlation with target.

    Parameters
    ----------
    df : pd.DataFrame
    target_col : str
        Column name of the target variable.
    candidate_cols : list of str or None
        Meteorological columns to consider. If None, uses default set.
    n_select : int
        Number of top predictors to return.

    Returns
    -------
    List[str]
        Names of selected predictor columns.
    """
    if candidate_cols is None:
        candidate_cols = [
            "temp.max",
            "temp.mean",
            "temp.min",
            "relative.humidity",
            "total.rainfall",
            "solar.radiation",
            "wind.speed",
            "absolute.humidity",
            "pressure",
            "temp.range",
        ]
    available = [c for c in candidate_cols if c in df.columns]
    corrs = {}
    for col in available:
        valid = df[[target_col, col]].dropna()
        if len(valid) > 2:
            corrs[col] = abs(valid[target_col].corr(valid[col]))
    sorted_cols = sorted(corrs, key=corrs.get, reverse=True)
    return sorted_cols[:n_select]


def build_lagged_features(
    df: pd.DataFrame,
    target_col: str = "rate",
    predictor_cols: Optional[List[str]] = None,
    max_lag: int = 14,
    include_epidemiological: bool = True,
) -> pd.DataFrame:
    """Create lagged feature matrix for forecasting models.

    Parameters
    ----------
    df : pd.DataFrame
    target_col : str
        Target variable column name.
    predictor_cols : list of str or None
        Meteorological predictor columns.
    max_lag : int
        Maximum lag order for predictors.
    include_epidemiological : bool
        Whether to include weekid and monthid as features.

    Returns
    -------
    pd.DataFrame
        DataFrame with lagged features added.
    """
    result = df.copy()
    # Lagged target values
    for lag in range(1, max_lag + 1):
        result[f"{target_col}_lag{lag}"] = result[target_col].shift(lag)

    # Lagged meteorological predictors
    if predictor_cols is not None:
        for col in predictor_cols:
            if col in result.columns:
                for lag in range(1, max_lag + 1):
                    result[f"{col}_lag{lag}"] = result[col].shift(lag)

    return result


def optimal_lag_by_correlation(
    df: pd.DataFrame,
    target_col: str,
    predictor_col: str,
    max_lag: int = 14,
) -> int:
    """Find the lag with highest absolute Pearson correlation.

    Parameters
    ----------
    df : pd.DataFrame
    target_col : str
    predictor_col : str
    max_lag : int

    Returns
    -------
    int
        Optimal lag (1-indexed).
    """
    best_lag = 1
    best_corr = 0.0
    for lag in range(1, max_lag + 1):
        lagged = df[predictor_col].shift(lag)
        valid = pd.DataFrame({"t": df[target_col], "p": lagged}).dropna()
        if len(valid) > 2:
            c = abs(valid["t"].corr(valid["p"]))
            if c > best_corr:
                best_corr = c
                best_lag = lag
    return best_lag


def define_epidemic_phases(
    series: pd.Series,
    window: int = 3,
) -> pd.Series:
    """Classify each time point into epidemic phase: growth, plateau, or decline.

    Growth: ILI+ increasing for `window` consecutive weeks.
    Decline: ILI+ decreasing for `window` consecutive weeks.
    Plateau: otherwise.

    Parameters
    ----------
    series : pd.Series
        ILI+ time series values.
    window : int
        Number of consecutive weeks to define a trend.

    Returns
    -------
    pd.Series
        Phase labels ('growth', 'decline', 'plateau').
    """
    diffs = series.diff()
    phases = pd.Series("plateau", index=series.index)
    for i in range(window, len(series)):
        if all(diffs.iloc[i - j] > 0 for j in range(window)):
            phases.iloc[i] = "growth"
        elif all(diffs.iloc[i - j] < 0 for j in range(window)):
            phases.iloc[i] = "decline"
    return phases


def identify_seasons(
    df: pd.DataFrame,
    monthid_col: str = "monthid",
) -> pd.Series:
    """Label each observation as 'winter' or 'summer' season.

    Winter: November to April (monthid 11,12,1,2,3,4).
    Summer: May to October (monthid 5,6,7,8,9,10).

    Parameters
    ----------
    df : pd.DataFrame
    monthid_col : str

    Returns
    -------
    pd.Series
        Season labels.
    """
    winter_months = {11, 12, 1, 2, 3, 4}
    return df[monthid_col].apply(
        lambda m: "winter" if m in winter_months else "summer"
    )
