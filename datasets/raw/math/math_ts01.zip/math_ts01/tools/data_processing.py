"""Data processing utilities for influenza time series forecasting."""

import pandas as pd
import numpy as np
from typing import List, Optional, Tuple


def load_influenza_data(csv_path: str) -> pd.DataFrame:
    """Load weekly influenza activity (ILI+) time series from CSV.

    Parameters
    ----------
    csv_path : str
        Path to the CSV file containing weekly ILI+ data.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns including 'date', 'weekid', 'rate',
        meteorological variables, and 'monthid'.
    """
    df = pd.read_csv(csv_path)
    # Standardise date parsing
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").reset_index(drop=True)
    return df


def split_train_test(
    df: pd.DataFrame,
    train_end: str,
    test_start: str,
    date_col: str = "date",
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Split time series into training and testing periods.

    Parameters
    ----------
    df : pd.DataFrame
        Full dataset.
    train_end : str
        Last date (inclusive) of the training period, e.g. '2007-10-31'.
    test_start : str
        First date (inclusive) of the test period, e.g. '2007-11-01'.
    date_col : str
        Name of the date column.

    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame]
        (train_df, test_df)
    """
    train = df[df[date_col] <= pd.Timestamp(train_end)].copy()
    test = df[df[date_col] >= pd.Timestamp(test_start)].copy()
    return train, test


def exclude_period(
    df: pd.DataFrame,
    start: str,
    end: str,
    date_col: str = "date",
) -> pd.DataFrame:
    """Remove rows within a date range (inclusive).

    WARNING: this drops rows from the time axis, creating a gap. For the
    Hong Kong 2009 surveillance change a naive call here would let a
    forecast at origin late-2008 silently span the gap and claim 0-8 weeks
    ahead while actually pointing at early-2010 observations. Prefer
    :func:`exclude_period_evaluation_mask` for the 2009 exclusion: it
    leaves the time-index intact (so rolling models keep coherent
    horizons) and returns a boolean mask the evaluator should AND into
    its (forecast_origin in excluded period) OR (target_date in excluded
    period) filter before metrics are computed.

    Parameters
    ----------
    df : pd.DataFrame
    start, end : str
        Date strings for exclusion boundaries.
    date_col : str

    Returns
    -------
    pd.DataFrame
    """
    mask = (df[date_col] >= pd.Timestamp(start)) & (
        df[date_col] <= pd.Timestamp(end)
    )
    return df[~mask].reset_index(drop=True)


def exclude_period_evaluation_mask(
    df: pd.DataFrame,
    start: str,
    end: str,
    date_col: str = "date",
) -> "pd.Series":
    """Return a boolean mask flagging rows OUTSIDE the excluded period.

    Unlike :func:`exclude_period` this does not modify ``df`` so the
    time-index stays contiguous and rolling-forecast horizons line up
    correctly. The evaluator should filter forecast rows by
    ``(forecast_origin date OR target date) lies outside [start, end]``
    before computing metrics. For the Hong Kong surveillance-system change
    interval used by the paper, call::

        eval_mask = exclude_period_evaluation_mask(df, '2009-04-01',
                                                   '2010-03-31')

    Then drop any forecast row whose ``forecast_origin`` or ``observed``
    date maps to ``~eval_mask``.
    """
    return ~((df[date_col] >= pd.Timestamp(start)) & (df[date_col] <= pd.Timestamp(end)))


def select_meteorological_predictors(
    df: pd.DataFrame,
    target_col: str = "rate",
    candidate_cols: Optional[List[str]] = None,
    n_select: int = 5,
    train_end_idx: Optional[int] = None,
) -> List[str]:
    """Select top meteorological predictors by Pearson correlation with target.

    Leakage policy: when ``train_end_idx`` is provided, predictor selection
    is computed ONLY on rows ``df.iloc[:train_end_idx+1]`` so that no test-
    period information leaks into the choice of predictors. The caller is
    expected to set ``train_end_idx`` to the last training-period row index
    (matching ``rolling_ml_forecast`` / ``rolling_statistical_forecast``'s
    ``train_end_idx`` argument). If ``train_end_idx`` is None the function
    falls back to all rows — use that mode only for exploratory analysis
    on the full series, never to feed a forecast model used on the test set.

    Parameters
    ----------
    df : pd.DataFrame
    target_col : str
        Column name of the target variable.
    candidate_cols : list of str or None
        Meteorological columns to consider. If None, uses default set.
    n_select : int
        Number of top predictors to return.
    train_end_idx : int, optional
        Last training-period row index. When set, correlations are
        evaluated on ``df.iloc[:train_end_idx + 1]`` only.

    Returns
    -------
    List[str]
        Names of selected predictor columns.
    """
    if candidate_cols is None:
        candidate_cols = [
            "temp.max",
            "temp.mean",
            "temp.min",
            "relative.humidity",
            "total.rainfall",
            "solar.radiation",
            "wind.speed",
            "absolute.humidity",
            "pressure",
            "temp.range",
        ]
    if train_end_idx is not None:
        scope_df = df.iloc[: int(train_end_idx) + 1]
    else:
        scope_df = df
    available = [c for c in candidate_cols if c in scope_df.columns]
    corrs = {}
    for col in available:
        valid = scope_df[[target_col, col]].dropna()
        if len(valid) > 2:
            corrs[col] = abs(valid[target_col].corr(valid[col]))
    sorted_cols = sorted(corrs, key=corrs.get, reverse=True)
    return sorted_cols[:n_select]


def build_lagged_features(
    df: pd.DataFrame,
    target_col: str = "rate",
    predictor_cols: Optional[List[str]] = None,
    max_lag: int = 14,
    include_epidemiological: bool = True,
) -> pd.DataFrame:
    """Create lagged feature matrix for forecasting models.

    Parameters
    ----------
    df : pd.DataFrame
    target_col : str
        Target variable column name.
    predictor_cols : list of str or None
        Meteorological predictor columns.
    max_lag : int
        Maximum lag order for predictors.
    include_epidemiological : bool
        Whether to include weekid and monthid as features.

    Returns
    -------
    pd.DataFrame
        DataFrame with lagged features added.
    """
    result = df.copy()
    # Lagged target values
    for lag in range(1, max_lag + 1):
        result[f"{target_col}_lag{lag}"] = result[target_col].shift(lag)

    # Lagged meteorological predictors
    if predictor_cols is not None:
        for col in predictor_cols:
            if col in result.columns:
                for lag in range(1, max_lag + 1):
                    result[f"{col}_lag{lag}"] = result[col].shift(lag)

    if include_epidemiological:
        # Surface week-of-year and month-of-year as model features. These
        # are calendar-derived so they leak no future data (week 30 of any
        # week is just an integer). They give every model a seasonality
        # signal without a future-information leak.
        if "weekid" in result.columns and "weekid_feat" not in result.columns:
            result["weekid_feat"] = result["weekid"].astype(float)
        elif "date" in result.columns and "weekid_feat" not in result.columns:
            result["weekid_feat"] = pd.to_datetime(result["date"]).dt.isocalendar().week.astype(float)
        if "monthid" in result.columns and "monthid_feat" not in result.columns:
            result["monthid_feat"] = result["monthid"].astype(float)
        elif "date" in result.columns and "monthid_feat" not in result.columns:
            result["monthid_feat"] = pd.to_datetime(result["date"]).dt.month.astype(float)

    return result


def optimal_lag_by_correlation(
    df: pd.DataFrame,
    target_col: str,
    predictor_col: str,
    max_lag: int = 14,
) -> int:
    """Find the lag with highest absolute Pearson correlation.

    Parameters
    ----------
    df : pd.DataFrame
    target_col : str
    predictor_col : str
    max_lag : int

    Returns
    -------
    int
        Optimal lag (1-indexed).
    """
    best_lag = 1
    best_corr = 0.0
    for lag in range(1, max_lag + 1):
        lagged = df[predictor_col].shift(lag)
        valid = pd.DataFrame({"t": df[target_col], "p": lagged}).dropna()
        if len(valid) > 2:
            c = abs(valid["t"].corr(valid["p"]))
            if c > best_corr:
                best_corr = c
                best_lag = lag
    return best_lag


def define_epidemic_phases(
    series: pd.Series,
    window: int = 3,
) -> pd.Series:
    """Classify each time point into epidemic phase: growth, plateau, or decline.

    Growth: ILI+ increasing for `window` consecutive weeks.
    Decline: ILI+ decreasing for `window` consecutive weeks.
    Plateau: otherwise.

    Parameters
    ----------
    series : pd.Series
        ILI+ time series values.
    window : int
        Number of consecutive weeks to define a trend.

    Returns
    -------
    pd.Series
        Phase labels ('growth', 'decline', 'plateau').
    """
    diffs = series.diff()
    phases = pd.Series("plateau", index=series.index)
    for i in range(window, len(series)):
        if all(diffs.iloc[i - j] > 0 for j in range(window)):
            phases.iloc[i] = "growth"
        elif all(diffs.iloc[i - j] < 0 for j in range(window)):
            phases.iloc[i] = "decline"
    return phases


def identify_seasons(
    df: pd.DataFrame,
    monthid_col: str = "monthid",
) -> pd.Series:
    """Label each observation as 'winter' or 'summer' season.

    Winter: November to April (monthid 11,12,1,2,3,4).
    Summer: May to October (monthid 5,6,7,8,9,10).

    Parameters
    ----------
    df : pd.DataFrame
    monthid_col : str

    Returns
    -------
    pd.Series
        Season labels.
    """
    winter_months = {11, 12, 1, 2, 3, 4}
    return df[monthid_col].apply(
        lambda m: "winter" if m in winter_months else "summer"
    )
