"""Deterministic non-deep standard workflow for the bundled ILI+ task."""

import csv
from typing import List
import pandas as pd

try:
    from .data_processing import load_influenza_data, exclude_period_evaluation_mask
    from .baseline_model import rolling_baseline_forecast
    from .ml_models import rolling_ml_forecast
    from .forecast_evaluation import compute_rmse, compute_mae, compute_smape, compute_mape
except ImportError:
    from data_processing import load_influenza_data, exclude_period_evaluation_mask
    from baseline_model import rolling_baseline_forecast
    from ml_models import rolling_ml_forecast
    from forecast_evaluation import compute_rmse, compute_mae, compute_smape, compute_mape

WEATHER_FEATURES = [
    "temp.max", "temp.mean", "temp.min", "relative.humidity", "total.rainfall",
    "solar.radiation", "wind.speed", "absolute.humidity", "pressure", "temp.range",
]


def filter_paper_evaluation_rows(forecasts, df, start="2009-04-01", end="2010-03-31"):
    """Drop rows whose forecast origin or target date falls in the exclusion interval."""
    mask = exclude_period_evaluation_mask(df, start, end)
    out = forecasts.copy()
    out["target_idx"] = out["forecast_origin"] + out["horizon"]
    keep = []
    for origin, target in zip(out["forecast_origin"].astype(int), out["target_idx"].astype(int)):
        keep.append(origin < len(mask) and target < len(mask) and bool(mask.iloc[origin]) and bool(mask.iloc[target]))
    return out.loc[keep].reset_index(drop=True)


def compute_standard_metrics(csv_path="input_data/data/hk_influenza_weekly.csv", n_estimators=25):
    """Compute baseline, RF, and RF-relative metrics for the scored non-deep protocol."""
    df = load_influenza_data(csv_path)
    test_start = pd.Timestamp("2007-11-01")
    test_end = pd.Timestamp("2019-07-31")
    train_end_idx = int(df.index[df["date"] < test_start].max())
    test_end_idx = int(df.index[df["date"] <= test_end].max())
    base = rolling_baseline_forecast(df, "rate", train_end_idx, test_end_idx, horizon=9)
    rf = rolling_ml_forecast(
        df, "rate", WEATHER_FEATURES, 0, train_end_idx, test_end_idx,
        horizon=9, model_type="rf", retrain_annually=True,
        n_estimators=n_estimators,
    )
    base = filter_paper_evaluation_rows(base, df)
    rf = filter_paper_evaluation_rows(rf, df)
    rows = []
    for model, res in [("baseline", base), ("rf", rf)]:
        for h, sub in res.groupby("horizon"):
            rows.append({
                "model": model, "horizon": int(h), "n": len(sub),
                "rmse": compute_rmse(sub.observed.values, sub.forecast.values),
                "mae": compute_mae(sub.observed.values, sub.forecast.values),
                "smape": compute_smape(sub.observed.values, sub.forecast.values),
                "mape": compute_mape(sub.observed.values, sub.forecast.values),
            })
    by = {(r["model"], r["horizon"]): r for r in rows}
    for h in range(9):
        b, r = by[("baseline", h)], by[("rf", h)]
        rows.append({
            "model": "rf_relative_to_baseline", "horizon": h, "n": r["n"],
            "rmse": r["rmse"] / b["rmse"], "mae": r["mae"] / b["mae"],
            "smape": r["smape"] / b["smape"], "mape": r["mape"] / b["mape"],
        })
    return rows, {"baseline": base, "rf": rf}
