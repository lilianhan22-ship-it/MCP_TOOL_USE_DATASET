"""Deterministic non-deep standard workflow for the bundled ILI+ task."""

import csv
import os
from typing import List
import numpy as np
import pandas as pd

try:
    from .data_processing import load_influenza_data, exclude_period_evaluation_mask
    from .baseline_model import rolling_baseline_forecast
    from .ml_models import rolling_ml_forecast
    from .forecast_evaluation import compute_rmse, compute_mae, compute_smape, compute_mape
except ImportError:
    from data_processing import load_influenza_data, exclude_period_evaluation_mask
    from baseline_model import rolling_baseline_forecast
    from ml_models import rolling_ml_forecast
    from forecast_evaluation import compute_rmse, compute_mae, compute_smape, compute_mape

WEATHER_FEATURES = [
    "temp.max", "temp.mean", "temp.min", "relative.humidity", "total.rainfall",
    "solar.radiation", "wind.speed", "absolute.humidity", "pressure", "temp.range",
]


def filter_paper_evaluation_rows(forecasts, df, start="2009-04-01", end="2010-03-31"):
    """Drop rows whose forecast origin or target date falls in the exclusion interval."""
    mask = exclude_period_evaluation_mask(df, start, end)
    out = forecasts.copy()
    out["target_idx"] = out["forecast_origin"] + out["horizon"]
    keep = []
    for origin, target in zip(out["forecast_origin"].astype(int), out["target_idx"].astype(int)):
        keep.append(origin < len(mask) and target < len(mask) and bool(mask.iloc[origin]) and bool(mask.iloc[target]))
    return out.loc[keep].reset_index(drop=True)


def compute_standard_metrics(csv_path="input_data/data/hk_influenza_weekly.csv", n_estimators=25):
    """Compute baseline, RF, and RF-relative metrics for the scored non-deep protocol."""
    df = load_influenza_data(csv_path)
    test_start = pd.Timestamp("2007-11-01")
    test_end = pd.Timestamp("2019-07-31")
    train_end_idx = int(df.index[df["date"] < test_start].max())
    test_end_idx = int(df.index[df["date"] <= test_end].max())
    base = rolling_baseline_forecast(df, "rate", train_end_idx, test_end_idx, horizon=9)
    rf = rolling_ml_forecast(
        df, "rate", WEATHER_FEATURES, 0, train_end_idx, test_end_idx,
        horizon=9, model_type="rf", retrain_annually=True,
        n_estimators=n_estimators,
    )
    base = filter_paper_evaluation_rows(base, df)
    rf = filter_paper_evaluation_rows(rf, df)
    rows = []
    for model, res in [("baseline", base), ("rf", rf)]:
        for h, sub in res.groupby("horizon"):
            rows.append({
                "model": model, "horizon": int(h), "n": len(sub),
                "rmse": compute_rmse(sub.observed.values, sub.forecast.values),
                "mae": compute_mae(sub.observed.values, sub.forecast.values),
                "smape": compute_smape(sub.observed.values, sub.forecast.values),
                "mape": compute_mape(sub.observed.values, sub.forecast.values),
            })
    by = {(r["model"], r["horizon"]): r for r in rows}
    for h in range(9):
        b, r = by[("baseline", h)], by[("rf", h)]
        rows.append({
            "model": "rf_relative_to_baseline", "horizon": h, "n": r["n"],
            "rmse": r["rmse"] / b["rmse"], "mae": r["mae"] / b["mae"],
            "smape": r["smape"] / b["smape"], "mape": r["mape"] / b["mape"],
        })
    return rows, {"baseline": base, "rf": rf}


def generate_standard_artifacts(
    csv_path="input_data/data/hk_influenza_weekly.csv",
    output_dir="artifacts",
    n_estimators=25,
):
    """Generate the two scored artifact PNG files for the derived RF diagnostic.

    Returns the metric rows plus output paths. The function deliberately uses
    the same protocol as ``compute_standard_metrics``: weather features listed
    in ``WEATHER_FEATURES``, forecast-origin feature row t-1, Nov 2007-Jul 2019
    evaluation, and closed exclusion of Apr 2009-Mar 2010 for both origin and
    target dates.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    os.makedirs(output_dir, exist_ok=True)
    rows, forecasts = compute_standard_metrics(csv_path, n_estimators=n_estimators)
    df = load_influenza_data(csv_path)

    rel = pd.DataFrame([r for r in rows if r["model"] == "rf_relative_to_baseline"])
    metrics = ["rmse", "mae", "smape", "mape"]
    heat = rel.set_index("horizon")[metrics].T
    fig, ax = plt.subplots(figsize=(9, 4.8))
    im = ax.imshow(heat.values, aspect="auto", cmap="RdYlBu_r", vmin=0, vmax=max(3.0, float(np.nanmax(heat.values))))
    ax.set_xticks(range(len(heat.columns)))
    ax.set_xticklabels([str(int(h)) for h in heat.columns])
    ax.set_yticks(range(len(metrics)))
    ax.set_yticklabels([m.upper() for m in metrics])
    ax.set_xlabel("Forecast horizon (weeks)")
    ax.set_title("RF relative to persistence baseline")
    for i in range(len(metrics)):
        for j in range(len(heat.columns)):
            ax.text(j, i, f"{heat.values[i, j]:.2f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im, ax=ax, label="Relative metric")
    fig.tight_layout()
    perf_path = os.path.join(output_dir, "fig_performance_comparison.png")
    fig.savefig(perf_path, dpi=160)
    plt.close(fig)

    base = forecasts["baseline"]
    rf = forecasts["rf"]
    b8 = base[base["horizon"] == 8].copy()
    r8 = rf[rf["horizon"] == 8].copy()
    traj = b8.merge(
        r8[["forecast_origin", "target_idx", "forecast"]],
        on=["forecast_origin", "target_idx"],
        how="inner",
        suffixes=("_baseline", "_rf"),
    )
    traj["target_date"] = df.loc[traj["target_idx"].astype(int), "date"].to_numpy()
    # Keep the visual readable while preserving the paper-aligned filtered period.
    plot_traj = traj.tail(min(len(traj), 180))
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(plot_traj["target_date"], plot_traj["observed"], label="Observed", color="black", linewidth=1.8)
    ax.plot(plot_traj["target_date"], plot_traj["forecast_baseline"], label="Persistence baseline", color="tab:gray", alpha=0.9)
    ax.plot(plot_traj["target_date"], plot_traj["forecast_rf"], label="RF weather forecast", color="tab:blue", alpha=0.9)
    ax.set_ylabel("ILI+ rate")
    ax.set_title("Derived h=8 RF-vs-persistence trajectory")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.autofmt_xdate()
    fig.tight_layout()
    traj_path = os.path.join(output_dir, "fig_forecast_trajectories.png")
    fig.savefig(traj_path, dpi=160)
    plt.close(fig)

    return {
        "rows": rows,
        "artifacts": {
            "performance_comparison": perf_path,
            "forecast_trajectories": traj_path,
        },
    }
