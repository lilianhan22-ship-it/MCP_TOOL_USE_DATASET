# Tools

## Categories

### Data Processing (`data_processing.py`)
- `load_influenza_data` — Load weekly ILI+ CSV
- `split_train_test` — Split by date
- `exclude_period` — Remove date ranges
- `select_meteorological_predictors` — Pearson correlation-based feature selection
- `build_lagged_features` — Create lagged feature matrix
- `optimal_lag_by_correlation` — Find best lag per predictor
- `define_epidemic_phases` — Classify growth/plateau/decline
- `identify_seasons` — Label winter/summer

### Time Series Decomposition (`time_series_decomposition.py`)
- `seasonal_decompose` — Classical additive/multiplicative decomposition
- `stl_decompose` — STL (LOESS-based) decomposition
- `compute_seasonal_pattern` — Average seasonal profile
- `compute_autocorrelation` — ACF
- `compute_partial_autocorrelation` — PACF
- `adf_stationarity_test` — Augmented Dickey-Fuller test

### Statistical Models (`statistical_models.py`)
- `fit_arima_forecast` — ARIMA fitting and forecasting
- `fit_garch_forecast` — GARCH fitting and forecasting
- `auto_arima_select` — AIC/BIC-based order selection
- `rolling_statistical_forecast` — Rolling re-fit forecast generation

### Machine Learning Models (`ml_models.py`)
- `fit_random_forest_forecast` — RF fitting
- `fit_xgboost_forecast` — XGB fitting
- `rolling_ml_forecast` — Rolling ML forecasts with annual retraining
- `compute_feature_importance` — Feature importance ranking

### Standard Public Workflow (`standard_workflow.py`)
- `compute_standard_metrics` — deterministic scored protocol for the released
  public-data sub-chain: persistence baseline, random-forest weather-feature
  forecasts, and RF-relative metrics over the paper-aligned evaluation window.
- `filter_paper_evaluation_rows` — removes rows whose forecast origin or target
  week falls in the Apr 2009-Mar 2010 surveillance-change interval.

### Ensemble Models (`ensemble_models.py`)
- `simple_average_ensemble` — SAE (top-N average), **strictly rolling**: model
  ranking uses only past origins (expanding window); never the full test-period
  `observed`
- `normal_blending_ensemble` — NBE (rolling LASSO blend), **strictly rolling**:
  weights fit only on past pairs at each origin
- `adaptive_weighted_average_ensemble` — AWAE (decay-weighted selection)
- `adaptive_weighted_blending_ensemble` — AWBE (decay-weighted LASSO)
- `exponential_decay_weights` — time-decay weights; **most recent observation
  (`t-1`) gets the highest weight**, decaying into the past (oldest-first
  alignment)
- `grid_search_decay_rate` — Optimize decay parameter

### Leakage policy
- `rolling_ml_forecast` and `rolling_statistical_forecast` use ONLY information
  available at the forecast origin (ILI+ up to week `t-1`; no future weather —
  the last observed predictor row is persisted across the horizon).
- The package does not ship a generated metric-answer CSV as participant-facing
  input. The derived RF-vs-persistence diagnostics are regenerated with
  `standard_workflow.compute_standard_metrics`. It also does not ship hidden
  paper RF/AWBE/AWAE prediction tables or full paper Fig. 2F answer files.

### Scope note
The derived generated-output workflow is `standard_workflow.compute_standard_metrics`,
which is limited to the released non-deep public-data sub-chain and is not a paper RF/Fig. 2F reproduction. The paper's
deep-learning models (LSTM, GRU, TSTPlus, InTimePlus) and the full AWBE/AWAE
Fig. 2F ensemble table are not bundled, not scored as generated tool outputs,
and appear only as source-paper context in `target.pdf`.

### Baseline Model (`baseline_model.py`)
- `constant_baseline_forecast` — Persistence (constant incidence) model
- `rolling_baseline_forecast` — Rolling baseline over test period
- `baseline_prediction_interval` — PI from historical differences

### Epidemic Detection (`epidemic_detection.py`)
- `detect_epidemic_onset` — Find epidemic start/end/peak
- `classify_epidemic_season` — Winter vs summer
- `predict_epidemic_occurrence` — Forecast-based epidemic prediction
- `evaluate_peak_prediction` — Peak timing/magnitude accuracy
- `epidemic_classification_metrics` — TPR, SPC, PPV, NPV

### Prediction Intervals (`prediction_intervals.py`)
- `rolling_residual_sd` — Rolling SD of residuals
- `optimal_window_for_coverage` — Window size tuning for target coverage
- `construct_prediction_interval` — Normal-based PI
- `prediction_quantiles` — Generate quantile forecasts
- `bootstrap_prediction_interval` — Bootstrap PI

### Plotting (`plotting.py`)
- `plot_influenza_time_series` — Full time series plot
- `plot_model_comparison` — Bar chart of model metrics
- `plot_performance_by_horizon` — Metric vs horizon curves
- `plot_forecast_trajectory` — Observed vs forecast with PI
- `plot_relative_performance_heatmap` — Heatmap of relative metrics
- `plot_feature_importance_heatmap` — Feature importance visualization
- `plot_seasonal_pattern` — Average seasonal cycle
- `plot_epidemic_phases` — Phase-colored time series

### Artifact generation note
- Use `standard_workflow.compute_standard_metrics` to obtain baseline/RF forecast tables and relative metrics for the derived public diagnostic.
- `artifacts/fig_performance_comparison.png` visualizes the RF relative-to-baseline metrics across horizons 0-8.
- `artifacts/fig_forecast_trajectories.png` visualizes the derived h=8 observed/persistence/RF trajectory.
- These artifacts are not paper Fig. 2F redraws and do not visualize paper RF/AWBE/AWAE predictions.
