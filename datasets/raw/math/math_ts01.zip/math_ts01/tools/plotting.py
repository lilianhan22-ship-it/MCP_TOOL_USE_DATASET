"""Plotting utilities for influenza time series forecasting."""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from typing import Dict, List, Optional, Tuple


def plot_influenza_time_series(
    df: pd.DataFrame,
    date_col: str = "date",
    rate_col: str = "rate",
    train_end: Optional[str] = None,
    title: str = "Influenza Activity (ILI+) in Hong Kong",
    save_path: str = "artifacts/fig_time_series.png",
) -> str:
    """Plot full ILI+ time series with optional train/test split.

    Parameters
    ----------
    df : pd.DataFrame
    date_col : str
    rate_col : str
    train_end : str or None
        Date marking end of training period. Vertical line drawn here.
    title : str
    save_path : str

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(figsize=(14, 5))
    ax.plot(df[date_col], df[rate_col], linewidth=0.8, color="steelblue")
    if train_end:
        ax.axvline(pd.Timestamp(train_end), color="red", linestyle="--", alpha=0.7, label="Train/Test split")
        ax.legend()
    ax.set_xlabel("Date")
    ax.set_ylabel("ILI+ Activity")
    ax.set_title(title)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    return save_path


def plot_model_comparison(
    metrics_df: pd.DataFrame,
    metric_name: str = "RMSE",
    title: str = "Model Performance Comparison",
    save_path: str = "artifacts/fig_model_comparison.png",
) -> str:
    """Plot bar chart comparing model performance.

    Parameters
    ----------
    metrics_df : pd.DataFrame
        Rows = models, columns include the metric to plot.
    metric_name : str
    title : str
    save_path : str

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    models = metrics_df.index.tolist()
    values = metrics_df[metric_name].values if metric_name in metrics_df.columns else metrics_df.iloc[:, 0].values

    colors = plt.cm.Set2(np.linspace(0, 1, len(models)))
    bars = ax.barh(models, values, color=colors)
    ax.set_xlabel(metric_name)
    ax.set_title(title)
    ax.invert_yaxis()
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    return save_path


def plot_performance_by_horizon(
    results: Dict[str, pd.DataFrame],
    metric: str = "rmse",
    title: str = "Performance by Forecast Horizon",
    save_path: str = "artifacts/fig_by_horizon.png",
) -> str:
    """Plot performance metric vs forecast horizon for multiple models.

    Parameters
    ----------
    results : dict
        {model_name: DataFrame with 'horizon' and metric columns}.
    metric : str
    title : str
    save_path : str

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    for name, df in results.items():
        ax.plot(df["horizon"], df[metric], marker="o", label=name)
    ax.set_xlabel("Weeks Ahead")
    ax.set_ylabel(metric.upper())
    ax.set_title(title)
    ax.legend(bbox_to_anchor=(1.05, 1), loc="upper left")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    return save_path


def plot_forecast_trajectory(
    observed: np.ndarray,
    dates: pd.Series,
    forecasts: Dict[str, np.ndarray],
    prediction_intervals: Optional[Dict[str, Tuple[np.ndarray, np.ndarray]]] = None,
    title: str = "Forecast Trajectory",
    save_path: str = "artifacts/fig_forecast_trajectory.png",
) -> str:
    """Plot observed vs forecasted time series with prediction intervals.

    Parameters
    ----------
    observed : np.ndarray
    dates : pd.Series
    forecasts : dict
        {model_name: forecast_array}
    prediction_intervals : dict or None
        {model_name: (lower, upper)} for 90% PI.
    title : str
    save_path : str

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(figsize=(14, 6))
    ax.plot(dates, observed, "k-", linewidth=1, label="Observed", alpha=0.8)

    colors = plt.cm.tab10(np.linspace(0, 0.8, len(forecasts)))
    for (name, fc), color in zip(forecasts.items(), colors):
        ax.plot(dates[: len(fc)], fc, linewidth=1, color=color, label=name, alpha=0.7)
        if prediction_intervals and name in prediction_intervals:
            lo, hi = prediction_intervals[name]
            ax.fill_between(
                dates[: len(lo)], lo, hi, color=color, alpha=0.15
            )

    ax.set_xlabel("Date")
    ax.set_ylabel("ILI+ Activity")
    ax.set_title(title)
    ax.legend(bbox_to_anchor=(1.05, 1), loc="upper left")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    return save_path


def plot_relative_performance_heatmap(
    rel_perf: pd.DataFrame,
    title: str = "Performance Relative to Baseline",
    save_path: str = "artifacts/fig_relative_heatmap.png",
) -> str:
    """Plot heatmap of relative performance metrics across models.

    Parameters
    ----------
    rel_perf : pd.DataFrame
        Rows = models, columns = metrics. Values < 1 indicate
        improvement over baseline.
    title : str
    save_path : str

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(figsize=(8, max(6, len(rel_perf) * 0.5)))
    data = rel_perf.values.astype(float)
    im = ax.imshow(data, cmap="RdYlGn_r", aspect="auto", vmin=0.3, vmax=1.1)
    ax.set_xticks(range(len(rel_perf.columns)))
    ax.set_xticklabels(rel_perf.columns, rotation=45, ha="right")
    ax.set_yticks(range(len(rel_perf.index)))
    ax.set_yticklabels(rel_perf.index)

    for i in range(len(rel_perf.index)):
        for j in range(len(rel_perf.columns)):
            ax.text(j, i, f"{data[i, j]:.2f}", ha="center", va="center", fontsize=9)

    plt.colorbar(im, ax=ax, label="Relative Performance")
    ax.set_title(title)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    return save_path


def plot_feature_importance_heatmap(
    importance_df: pd.DataFrame,
    title: str = "Feature Importance",
    save_path: str = "artifacts/fig_feature_importance.png",
) -> str:
    """Plot heatmap of feature importances across models and horizons.

    Parameters
    ----------
    importance_df : pd.DataFrame
        Rows = features, columns = model/horizon combinations.
    title : str
    save_path : str

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(figsize=(12, max(6, len(importance_df) * 0.4)))
    data = importance_df.values.astype(float)
    im = ax.imshow(data, cmap="Oranges", aspect="auto")
    ax.set_xticks(range(len(importance_df.columns)))
    ax.set_xticklabels(importance_df.columns, rotation=45, ha="right")
    ax.set_yticks(range(len(importance_df.index)))
    ax.set_yticklabels(importance_df.index)
    plt.colorbar(im, ax=ax, label="Importance")
    ax.set_title(title)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    return save_path


def plot_seasonal_pattern(
    seasonal_df: pd.DataFrame,
    weekid_col: str = "weekid",
    mean_col: str = "mean_rate",
    std_col: str = "std_rate",
    title: str = "Average Seasonal Pattern of ILI+ Activity",
    save_path: str = "artifacts/fig_seasonal_pattern.png",
) -> str:
    """Plot average seasonal pattern with confidence band.

    Parameters
    ----------
    seasonal_df : pd.DataFrame
    weekid_col : str
    mean_col : str
    std_col : str
    title : str
    save_path : str

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(seasonal_df[weekid_col], seasonal_df[mean_col], "b-", linewidth=2)
    ax.fill_between(
        seasonal_df[weekid_col],
        seasonal_df[mean_col] - seasonal_df[std_col],
        seasonal_df[mean_col] + seasonal_df[std_col],
        alpha=0.2,
    )
    ax.set_xlabel("Week of Year")
    ax.set_ylabel("ILI+ Activity")
    ax.set_title(title)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    return save_path


def plot_epidemic_phases(
    df: pd.DataFrame,
    date_col: str = "date",
    rate_col: str = "rate",
    phase_col: str = "phase",
    title: str = "Epidemic Phases",
    save_path: str = "artifacts/fig_epidemic_phases.png",
) -> str:
    """Plot time series colored by epidemic phase.

    Parameters
    ----------
    df : pd.DataFrame
    date_col, rate_col, phase_col : str
    title : str
    save_path : str

    Returns
    -------
    str
        Path to saved figure.
    """
    fig, ax = plt.subplots(figsize=(14, 5))
    phase_colors = {"growth": "red", "decline": "blue", "plateau": "green", "normal": "gray"}
    for phase, color in phase_colors.items():
        mask = df[phase_col] == phase
        if mask.any():
            ax.scatter(
                df.loc[mask, date_col],
                df.loc[mask, rate_col],
                c=color,
                s=5,
                label=phase,
                alpha=0.7,
            )
    ax.set_xlabel("Date")
    ax.set_ylabel("ILI+ Activity")
    ax.set_title(title)
    ax.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    return save_path
