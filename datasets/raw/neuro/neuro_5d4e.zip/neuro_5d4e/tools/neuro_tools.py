from __future__ import annotations
from pathlib import Path
from zipfile import ZipFile
import io
import re
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None

try:
    from .data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns
    from .database_retrieval import public_repository_links
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from data_processing import data_root, list_files, read_table, workbook_sheets, numeric_columns
    from database_retrieval import public_repository_links

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
CONFIG = {'title': 'paper evidence extraction'}


def _target_pdf() -> Path:
    return Path(__file__).resolve().parents[1] / "input_data" / "reference_paper" / "target.pdf"


def _norm(text: str) -> str:
    repl = {"\ufb01":"fi", "\ufb02":"fl", "−":"-", "–":"-", "—":"-", "\u00a0":" ", "×":"x", "℃":" C", "°C":" C", "ºC":" C"}
    for k, v in repl.items():
        text = text.replace(k, v)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def target_pdf_text(max_pages: int | None = None) -> str:
    if PdfReader is None:
        raise ImportError("pypdf is required to inspect target.pdf")
    reader = PdfReader(str(_target_pdf()))
    parts = []
    pages = reader.pages if max_pages is None else reader.pages[:max_pages]
    for page in pages:
        try:
            parts.append(page.extract_text() or "")
        except Exception:
            continue
    return _norm("\n".join(parts))


def source_inventory(root: str | Path | None = None) -> dict:
    root_path = Path(root) if root else data_root()
    files = list_files(root_path)
    return {"n_files": len(files), "extensions": sorted({Path(f).suffix.lower() for f in files}), "files": [str(Path(f).relative_to(root_path)) for f in files], "repositories": public_repository_links().get("repositories", [])}


def _word_number(token: str) -> float:
    words = {"one":1, "two":2, "three":3, "four":4, "five":5, "six":6, "seven":7, "eight":8, "nine":9, "ten":10}
    t = token.lower().replace(",", "")
    if t in words:
        return float(words[t])
    return float(t)


def paper_claims(search_terms: list[str] | None = None, max_mentions: int = 40) -> pd.DataFrame:
    """Extract numeric paper evidence snippets without hard-coded final answers.

    Args:
        search_terms: optional terms that must appear in the local context.
        max_mentions: maximum numeric mentions to return.
    """
    text = target_pdf_text()
    terms = [t.lower() for t in (search_terms or [])]
    number_re = re.compile(r"(?P<value>[-+]?\d[\d,]*(?:\.\d+)?)(?:\s*(?P<unit>%|mAh\s*cm-2|mg\s*cm-2|Wh\s*L-1|mW\s*cm-2|A\s*mg\w*-1|V|cycles?|h|hours?|publications?|x|fold))?", re.I)
    rows = []
    seen = set()
    for match in number_re.finditer(text):
        start = max(0, match.start() - 180)
        end = min(len(text), match.end() + 180)
        context = text[start:end]
        if terms and not any(term in context.lower() for term in terms):
            continue
        raw = match.group("value")
        key = (raw, match.group("unit") or "", context[:80])
        if key in seen:
            continue
        seen.add(key)
        try:
            value = float(raw.replace(",", ""))
        except ValueError:
            continue
        rows.append({
            "claim": context.strip()[:120],
            "value": value,
            "unit": match.group("unit") or "",
            "matched": True,
            "evidence_excerpt": context.strip(),
        })
        if len(rows) >= max_mentions:
            break
    return pd.DataFrame(rows)


def source_data_catalog() -> pd.DataFrame:
    rows = []
    root = data_root()
    for path in sorted(root.rglob("*")):
        if path.is_dir():
            continue
        rel = path.relative_to(root).as_posix()
        if path.suffix.lower() in {".zip"}:
            try:
                with ZipFile(path) as zf:
                    for name in zf.namelist():
                        if name.endswith("/") or "__MACOSX" in name:
                            continue
                        rows.append({"container": rel, "member": name, "kind": Path(name).suffix.lower() or "no_ext", "label": Path(name).stem})
            except Exception as exc:
                rows.append({"container": rel, "member": f"ERROR:{exc}", "kind": ".zip", "label": path.stem})
        else:
            rows.append({"container": "", "member": rel, "kind": path.suffix.lower() or "no_ext", "label": path.stem})
    return pd.DataFrame(rows)


def _panel_label(source, sheet: str) -> str:
    try:
        df = pd.read_excel(source, sheet_name=sheet, nrows=1)
        cols = [str(c) for c in df.columns[:8] if not str(c).startswith("Unnamed")]
        return " | ".join([sheet] + cols)
    except Exception:
        return sheet


def workbook_panel_catalog() -> pd.DataFrame:
    rows = []
    root = data_root()
    for path in sorted(root.rglob("*.xlsx")):
        try:
            xl = pd.ExcelFile(path)
            for sh in xl.sheet_names:
                rows.append({"container": path.relative_to(root).as_posix(), "sheet": sh, "kind": "xlsx_sheet", "label": _panel_label(path, sh)})
        except Exception:
            pass
    for path in sorted(root.rglob("*.zip")):
        try:
            with ZipFile(path) as zf:
                for name in zf.namelist():
                    if name.lower().endswith((".xlsx", ".xls")) and "__MACOSX" not in name:
                        data = zf.read(name)
                        try:
                            xl = pd.ExcelFile(io.BytesIO(data))
                            for sh in xl.sheet_names:
                                rows.append({"container": path.relative_to(root).as_posix() + "!" + name, "sheet": sh, "kind": "zip_xlsx_sheet", "label": _panel_label(io.BytesIO(data), sh)})
                        except Exception:
                            rows.append({"container": path.relative_to(root).as_posix() + "!" + name, "sheet": "", "kind": "zip_xlsx", "label": Path(name).stem})
                    elif name.lower().endswith((".csv", ".tsv", ".fyp")) and "__MACOSX" not in name:
                        rows.append({"container": path.relative_to(root).as_posix() + "!" + name, "sheet": "", "kind": Path(name).suffix.lower(), "label": Path(name).stem})
        except Exception:
            pass
    return pd.DataFrame(rows)


def _read_first_numeric_panel() -> tuple[str, pd.DataFrame]:
    root = data_root()
    candidates = []
    for p in sorted(root.rglob("*.csv")):
        candidates.append((p.relative_to(root).as_posix(), p, None))
    for p in sorted(root.rglob("*.xlsx")):
        try:
            for sh in pd.ExcelFile(p).sheet_names:
                candidates.append((p.relative_to(root).as_posix()+"::"+sh, p, sh))
        except Exception:
            pass
    for label, path, sheet in candidates[:80]:
        try:
            df = pd.read_csv(path) if path.suffix.lower() == ".csv" else pd.read_excel(path, sheet_name=sheet)
            nums = [c for c in df.columns if pd.to_numeric(df[c], errors="coerce").notna().sum() >= 3]
            if nums:
                return label, df[nums[:6]].apply(pd.to_numeric, errors="coerce")
        except Exception:
            continue
    for zip_path in sorted(root.rglob("*.zip")):
        try:
            with ZipFile(zip_path) as zf:
                for name in zf.namelist():
                    if "__MACOSX" in name:
                        continue
                    lower = name.lower()
                    if lower.endswith(".csv") or lower.endswith(".tsv"):
                        try:
                            sep = "\t" if lower.endswith(".tsv") else ","
                            df = pd.read_csv(io.BytesIO(zf.read(name)), sep=sep)
                            nums = [c for c in df.columns if pd.to_numeric(df[c], errors="coerce").notna().sum() >= 3]
                            if nums:
                                return zip_path.relative_to(root).as_posix()+"!"+name, df[nums[:6]].apply(pd.to_numeric, errors="coerce")
                        except Exception:
                            pass
                    if lower.endswith(".xlsx"):
                        try:
                            data = zf.read(name)
                            xl = pd.ExcelFile(io.BytesIO(data))
                            keywords = []
                            sheets = sorted(xl.sheet_names, key=lambda s: 1)
                            for sh in sheets:
                                df = pd.read_excel(io.BytesIO(data), sheet_name=sh)
                                nums = [c for c in df.columns if pd.to_numeric(df[c], errors="coerce").notna().sum() >= 3]
                                if nums:
                                    return zip_path.relative_to(root).as_posix()+"!"+name+"::"+sh, df[nums[:6]].apply(pd.to_numeric, errors="coerce")
                        except Exception:
                            pass
        except Exception:
            pass
    return "none", pd.DataFrame()


def mch_source_workbooks() -> pd.DataFrame:
    """List Nature source-data workbooks, including the dCA3/dLS and spatial-memory MOESM4-MOESM9 files."""
    rows = []
    for path in sorted(data_root().glob("41593_2021_984_MOESM*_ESM.xlsx")):
        m = re.search(r"MOESM(\d+)", path.name)
        number = int(m.group(1)) if m else -1
        try:
            xl = pd.ExcelFile(path)
            sheet_count = len(xl.sheet_names)
            first = pd.read_excel(path, sheet_name=xl.sheet_names[0], nrows=5)
            numeric_cols = sum(pd.to_numeric(first[c], errors="coerce").notna().sum() > 0 for c in first.columns)
        except Exception:
            sheet_count, numeric_cols = 0, 0
        rows.append({"file": path.name, "moesm": number, "sheet_count": sheet_count, "numeric_preview_columns": numeric_cols})
    return pd.DataFrame(rows).sort_values("moesm").reset_index(drop=True)



def mechanism_passages(search_terms: list[str] | None = None, max_passages: int = 12) -> pd.DataFrame:
    """Extract caller-selected MCH/dLS mechanism passages from target.pdf."""
    terms = [t.lower() for t in (search_terms or ["mch", "dls", "dca3", "gaba", "feed-forward", "spatial memory"])]
    text = target_pdf_text()
    sentences = re.split(r"(?<=[.!?])\s+", text)
    rows = []
    for sentence in sentences:
        low = sentence.lower()
        hits = [t for t in terms if t in low]
        if hits:
            rows.append({"passage": _norm(sentence), "term_hits": len(hits), "matched_terms": ",".join(hits)})
        if len(rows) >= max_passages:
            break
    return pd.DataFrame(rows)


def circuit_claims(search_terms: list[str] | None = None) -> pd.DataFrame:
    return mechanism_passages(search_terms)


def workbook_keyword_map(keywords: list[str] | None = None, moesm_numbers: list[int] | None = None) -> pd.DataFrame:
    """Score source workbooks against caller-provided experiment keywords."""
    keywords = [k.lower() for k in (keywords or ["oEPSC", "MCH", "GABA", "FFI", "ppr", "spatial", "memory", "SNAP", "TC-MCH7c"])]
    moesm_numbers = moesm_numbers or list(range(4, 10))
    rows = []
    for n in moesm_numbers:
        path = data_root() / f"41593_2021_984_MOESM{n}_ESM.xlsx"
        if not path.exists():
            rows.append({"moesm": n, "file": path.name, "present": False, "keyword_hits": 0, "matched_terms": ""})
            continue
        preview = pd.read_excel(path, sheet_name=0, nrows=8)
        text = " ".join([str(c) for c in preview.columns] + preview.astype(str).stack().head(160).tolist()).lower()
        hits = [k for k in keywords if k in text]
        rows.append({"moesm": n, "file": path.name, "present": True, "keyword_hits": len(hits), "matched_terms": ",".join(hits)})
    return pd.DataFrame(rows)


def source_panel_map(keywords: list[str] | None = None) -> pd.DataFrame:
    return workbook_keyword_map(keywords)


def workbook_numeric_panel(file_number: int = 5) -> pd.DataFrame:
    matches = sorted(data_root().glob(f"41593_2021_984_MOESM{file_number}_ESM.xlsx"))
    if not matches:
        raise FileNotFoundError(f"Missing MOESM{file_number} source-data workbook")
    df = pd.read_excel(matches[0], sheet_name=0)
    long = []
    for col in df.columns:
        vals = pd.to_numeric(df[col], errors="coerce")
        if vals.notna().sum() >= 3:
            long.append(pd.DataFrame({"column": str(col), "row_index": vals.index, "value": vals.values}).dropna())
    return pd.concat(long, ignore_index=True) if long else pd.DataFrame(columns=["column", "row_index", "value"])


def plot_paper_metrics(passages: pd.DataFrame | None = None, output_filename: str = "mch_mechanism_passages.png") -> dict:
    passages = mechanism_passages() if passages is None else passages.copy()
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(range(len(passages)), passages["term_hits"].astype(float), color="#6a4c93")
    ax.set_xticks(range(len(passages)))
    ax.set_xticklabels(passages["matched_terms"], rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("caller-term hits in paper passage")
    ax.set_title("MCH/dLS mechanism passages selected from target.pdf")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "passage_rows": int(len(passages))}


def plot_source_panels(panel_map: pd.DataFrame | None = None, output_filename: str = "mch_source_workbook_keyword_map.png") -> dict:
    panel_map = workbook_keyword_map() if panel_map is None else panel_map.copy()
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    x = np.arange(len(panel_map))
    fig, ax = plt.subplots(figsize=(9.5, 4.8))
    ax.bar(x, panel_map["keyword_hits"].astype(float), color="#2a9d8f")
    ax.set_xticks(x)
    ax.set_xticklabels(panel_map["file"], rotation=45, ha="right", fontsize=8)
    ax.set_ylabel("caller-keyword hits in workbook preview")
    ax.set_title("Source workbook keyword map for selected physiology/behavior terms")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "panel_map": panel_map.to_dict(orient="records")}


def plot_source_numeric_panel(panel: pd.DataFrame | None = None, output_filename: str = "mch_source_numeric_panel.png", file_number: int = 4) -> dict:
    long = workbook_numeric_panel(file_number) if panel is None else panel.copy()
    out = ARTIFACT_DIR / output_filename
    out.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8.8, 4.8))
    plotted = 0
    for col, sub in long.groupby("column"):
        if plotted >= 8:
            break
        vals = sub["value"].dropna().head(80).to_numpy()
        if len(vals) >= 3:
            ax.plot(range(len(vals)), vals, marker="o", ms=2, lw=1, label=col[:24])
            plotted += 1
    if plotted:
        ax.legend(fontsize=7, frameon=False, ncol=2)
    ax.set_xlabel("source-data row index")
    ax.set_ylabel("source value")
    ax.set_title(f"Caller-selected numeric source-data workbook MOESM{file_number}")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return {"path": str(out), "file_number": file_number, "numeric_series": plotted, "rows": int(len(long))}


def package_smoke_test() -> dict:
    catalog = mch_source_workbooks()
    passages = mechanism_passages()
    panel_map = workbook_keyword_map()
    return {"workbooks": catalog.to_dict(orient="records"), "passage_rows": int(len(passages)), "panel_map": panel_map.to_dict(orient="records"), "has_moesm4_9": bool(set(range(4, 10)).issubset(set(catalog["moesm"]))), "plot_functions": ["plot_paper_metrics", "plot_source_panels", "plot_source_numeric_panel"]}
