from __future__ import annotations

from pathlib import Path
import zipfile
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


STABLE_CSV_NAME = "place_cell_transitions/stable_unstable_classification.csv"
BEHAVIOR_CSV_NAME = "vr_behavior/behavior.csv"
GROUP_CSV_NAME = "experimental_groups/animal_groups.csv"
PERIOD_ORDER = ["pre", "early", "late"]
PERIOD_LABELS = {"pre": "Healthy", "early": "Early post", "late": "Late post"}


def _read_csv_from_bundle(path: str, member_suffix: str) -> pd.DataFrame:
    p = Path(path)
    if p.is_dir():
        matches = list(p.rglob(Path(member_suffix).name))
        matches = [m for m in matches if str(m).replace("\\", "/").endswith(member_suffix)]
        if not matches:
            raise FileNotFoundError(f"No {member_suffix} found under {p}")
        return pd.read_csv(matches[0])
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as zf:
            matches = [name for name in zf.namelist() if name.endswith(member_suffix)]
            if not matches:
                raise FileNotFoundError(f"No {member_suffix} found in {p}")
            with zf.open(matches[0]) as handle:
                return pd.read_csv(handle)
    return pd.read_csv(p)


def _panel_bounds(raw: pd.DataFrame, panel_label: str) -> tuple[int, int]:
    labels = raw.astype(str).apply(lambda c: c.str.strip())
    matches = raw.where(labels.eq(panel_label)).stack()
    if matches.empty:
        raise ValueError(f"{panel_label} header not found")
    start = int(matches.index[0][0])
    later = []
    for idx, row in raw.iloc[start + 1:].iterrows():
        first = str(row.iloc[0]).strip()
        if first.startswith("Panel "):
            later.append(int(idx))
    end = later[0] if later else raw.shape[0]
    return start, end


def _figure1_panel_f(source_xlsx: str) -> pd.DataFrame:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    df = pd.read_excel(source_xlsx, sheet_name="Figure 1", header=None)
    start, end = _panel_bounds(df, "Panel F")
    header_row = start + 1
    headers = [_canonical_column_label(df.iat[header_row, c]) for c in range(df.shape[1])]
    wanted = {
        "estimated_number_of_microspheres": "microspheres",
        "healthy": "healthy",
        "early_post": "early_post",
        "late_post": "late_post",
    }
    indices = []
    columns = []
    for idx, key in enumerate(headers):
        if key in wanted:
            indices.append(idx)
            columns.append(wanted[key])
    if set(columns) != set(wanted.values()):
        raise ValueError(f"Figure 1 Panel F schema not recognized: {headers}")
    vals = df.iloc[header_row + 1:end, indices].copy()
    vals.columns = columns
    for col in vals.columns:
        vals[col] = pd.to_numeric(vals[col], errors="coerce")
    return vals.dropna(subset=["microspheres", "early_post"])


def _canonical_column_label(value) -> str:
    text = str(value).strip().lower().replace("-", " ")
    text = "_".join(text.split())
    text = text.replace("[bits]", "").replace("[", "").replace("]", "")
    return text


def _default_source_from_bundle(path: str) -> Path | None:
    p = Path(path)
    candidates = [
        p / "data" / "source_data.xlsx" if p.is_dir() else p.parent / "source_data.xlsx",
        p / "input_data" / "data" / "source_data.xlsx" if p.is_dir() else p.parent / "source_data.xlsx",
        p.parent / "source_data.xlsx",
        p.parents[1] / "source_data.xlsx" if len(p.parents) > 1 else p.parent / "source_data.xlsx",
        Path(__file__).resolve().parents[1] / "input_data" / "data" / "source_data.xlsx",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _resolve_source_xlsx(path: str) -> Path:
    p = Path(path)
    if p.is_file():
        return p
    source = _default_source_from_bundle(path)
    if source and source.exists():
        return source
    matches = list(p.rglob("source_data.xlsx")) if p.is_dir() else []
    if matches:
        return matches[0]
    raise FileNotFoundError(f"source_data.xlsx not found from {path}")


def _canonical_group(name: str) -> str:
    text = str(name).strip().replace("_", "-")
    low = text.lower().replace(" ", "-")
    if low in {"control", "sham"}:
        return "Sham"
    if low in {"no-recovery", "norecovery", "no-recover", "no-recovery-group"}:
        return "No-Recovery"
    if low in {"recovery", "recover"}:
        return "Recovery"
    return text


def _figure3_panel_b_stable_groups(source_xlsx: str) -> list[dict]:
    """Parse Figure 3 Panel B by labels instead of fixed column indices."""
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    raw = pd.read_excel(source_xlsx, sheet_name="Figure 3", header=None)
    start, end = _panel_bounds(raw, "Panel B")
    group_labels = raw.iloc[start, :].ffill()
    period_rows = {"pre": start + 1, "early": start + 2, "late": start + 3}
    records = []
    for col in range(raw.shape[1]):
        group = _canonical_group(group_labels.iloc[col])
        if group.lower() in {"nan", "", "panel b"}:
            continue
        values = {
            period: pd.to_numeric(pd.Series([raw.iat[row, col]]), errors="coerce").iloc[0]
            for period, row in period_rows.items()
            if row < end
        }
        if all(pd.notna(v) for v in values.values()) and len(values) == 3:
            records.append({"source_column": int(col), "group": group, **{k: float(v) for k, v in values.items()}})
    return records


def stability_group_mapping(source_xlsx: str, stable_csv_or_bundle: str) -> dict:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    stable = _read_csv_from_bundle(stable_csv_or_bundle, STABLE_CSV_NAME)
    for col in ["n3_r"]:
        stable[col] = pd.to_numeric(stable[col], errors="coerce")
    panel = _figure3_panel_b_stable_groups(source_xlsx)
    assignments = {}
    used_columns = set()
    for mouse_id, sub in stable.dropna(subset=["mouse_id"]).groupby("mouse_id"):
        triplet = {
            period: float(sub.loc[sub["period"] == period, "n3_r"].mean())
            for period in PERIOD_ORDER
            if (sub["period"] == period).any()
        }
        if len(triplet) != 3:
            continue
        best = None
        for record in panel:
            if record["source_column"] in used_columns:
                continue
            distance = sum(abs(record[period] - triplet[period]) for period in PERIOD_ORDER)
            if best is None or distance < best[0]:
                best = (distance, record)
        if best is not None and best[0] < 1e-3:
            used_columns.add(best[1]["source_column"])
            assignments[str(mouse_id)] = {"group": best[1]["group"], "source_column": best[1]["source_column"]}
    return {
        "source": str(source_xlsx),
        "mapping_method": "Figure 3 Panel B nearest exact n3_r triplet",
        "matched_mice": len(assignments),
        "assignments": assignments,
    }


def microsphere_performance_summary(source_xlsx: str) -> dict:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    vals = _figure1_panel_f(source_xlsx)
    corr = np.corrcoef(vals["microspheres"].astype(float), vals["early_post"].astype(float))[0, 1]
    return {
        "rows": int(len(vals)),
        "microsphere_task_corr_early_post": float(corr),
        "median_microspheres": float(vals["microspheres"].median()),
        "early_post_mean": float(vals["early_post"].mean()),
        "late_post_mean": float(vals["late_post"].dropna().mean()),
    }


def place_cell_stability_summary(stable_csv_or_bundle: str, source_xlsx: str | None = None) -> dict:
    df = _read_csv_from_bundle(stable_csv_or_bundle, STABLE_CSV_NAME)
    for col in ["n1_r", "n2_r", "n3_r", "baseline_stability"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    grouped = df.groupby("period")[["n1_r", "n2_r", "n3_r", "baseline_stability"]].mean()
    grouped = grouped.reindex([p for p in PERIOD_ORDER if p in grouped.index])
    result = {
        "rows": int(len(df)),
        "periods": list(grouped.index),
        "class_labels": {
            "n1_r": "non-coding tracked cells",
            "n2_r": "unstable place cells",
            "n3_r": "stable place cells",
        },
        "class_fraction_means": {
            str(period): {
                "noncoding_n1_percent": float(row["n1_r"]),
                "unstable_place_cell_n2_percent": float(row["n2_r"]),
                "stable_place_cell_n3_percent": float(row["n3_r"]),
                "baseline_stability": float(row["baseline_stability"]),
            }
            for period, row in grouped.iterrows()
        },
    }
    source = Path(source_xlsx) if source_xlsx else _default_source_from_bundle(stable_csv_or_bundle)
    if source and source.exists():
        mapping = stability_group_mapping(str(source), stable_csv_or_bundle)
        df = df.copy()
        df["mouse_id"] = df["mouse_id"].astype(str)
        df["group"] = df["mouse_id"].map({mouse: item["group"] for mouse, item in mapping["assignments"].items()})
        group_df = df.dropna(subset=["group"]).groupby(["group", "period"])["n3_r"].mean().reset_index()
        result["group_mapping"] = mapping
        result["stable_place_cell_by_group"] = {
            group: {
                period: float(group_df[(group_df["group"] == group) & (group_df["period"] == period)]["n3_r"].mean())
                for period in PERIOD_ORDER
                if not group_df[(group_df["group"] == group) & (group_df["period"] == period)].empty
            }
            for group in sorted(group_df["group"].unique())
        }
    return result


def behavior_trace_summary(code_bundle: str) -> dict:
    df = _read_csv_from_bundle(code_bundle, BEHAVIOR_CSV_NAME)
    return {
        "rows": int(len(df)),
        "trials": int(df["trial_nb"].nunique()) if "trial_nb" in df else None,
        "duration_seconds": float(pd.to_numeric(df["time"], errors="coerce").max()) if "time" in df else None,
        "mean_speed": float(pd.to_numeric(df["speed"], errors="coerce").mean()) if "speed" in df else None,
    }


def _figure3_panel_a_recovery(source_xlsx: str) -> pd.DataFrame:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    raw = pd.read_excel(source_xlsx, sheet_name="Figure 3", header=None)
    start, end = _panel_bounds(raw, "Panel A")
    label_row = start + 1
    group_labels = raw.iloc[label_row, :].ffill()
    day_col = 0
    for col in range(raw.shape[1]):
        label = str(raw.iat[label_row, col]).strip().lower()
        if "day" in label or label in {"d", "time"}:
            day_col = col
            break
    records = []
    for col in range(raw.shape[1]):
        group = _canonical_group(group_labels.iloc[col])
        if group.lower() in {"nan", "", "panel a"} or col == day_col or "day" in group.lower():
            continue
        for row in range(label_row + 1, end):
            day = pd.to_numeric(pd.Series([raw.iat[row, day_col]]), errors="coerce").iloc[0]
            val = pd.to_numeric(pd.Series([raw.iat[row, col]]), errors="coerce").iloc[0]
            if pd.notna(day) and pd.notna(val):
                records.append({"days": float(day), "group": group, "performance": float(val), "source_column": int(col)})
    return pd.DataFrame(records)


def recovery_group_summary(source_xlsx: str) -> dict:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    vals = _figure3_panel_a_recovery(source_xlsx)
    group_means = vals.groupby("group")["performance"].mean().to_dict()
    return {
        "days": int(vals["days"].nunique()) if not vals.empty else 0,
        "groups": sorted(vals["group"].unique()) if not vals.empty else [],
        "group_means": {str(k): float(v) for k, v in group_means.items()},
    }


def plot_microsphere_vs_performance(source_xlsx: str, output_path: str) -> dict:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    vals = _figure1_panel_f(source_xlsx)
    plt.figure(figsize=(5, 4))
    plt.scatter(vals["microspheres"], vals["early_post"], s=25, color="#4C78A8")
    plt.xlabel("Estimated microspheres")
    plt.ylabel("Early post-stroke task performance")
    plt.title("Microsphere burden versus early post-stroke behavior")
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": output_path, "summary": microsphere_performance_summary(source_xlsx)}


def plot_recovery_groups(source_xlsx: str, output_path: str) -> dict:
    source_xlsx = str(_resolve_source_xlsx(source_xlsx))
    vals = _figure3_panel_a_recovery(source_xlsx)
    plt.figure(figsize=(6, 4))
    for group in ["No-Recovery", "Recovery", "Sham"]:
        sub = vals[vals["group"] == group].sort_values("days")
        if not sub.empty:
            plt.plot(sub["days"], sub["performance"], marker="o", label=group)
    plt.xlabel("Days after stroke")
    plt.ylabel("Task performance")
    plt.legend()
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": output_path, "summary": recovery_group_summary(source_xlsx)}
# Strict reproduction additions: place-cell stability artifact and smoke test.
def plot_place_cell_stability(stable_csv_or_bundle: str, output_path: str, source_xlsx: str | None = None) -> dict:
    df = _read_csv_from_bundle(stable_csv_or_bundle, STABLE_CSV_NAME)
    for col in ["n1_r", "n2_r", "n3_r"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    source = Path(source_xlsx) if source_xlsx else _default_source_from_bundle(stable_csv_or_bundle)
    plt.figure(figsize=(6.8, 4.2))
    if not (source and source.exists()):
        raise FileNotFoundError("source_data.xlsx is required to map stable place-cell rows to recovery groups")
    mapping = stability_group_mapping(str(source), stable_csv_or_bundle)
    if mapping["matched_mice"] == 0:
        raise ValueError("no mice could be matched to Figure 3 Panel B groups")
    df = df.copy()
    df["mouse_id"] = df["mouse_id"].astype(str)
    df["group"] = df["mouse_id"].map({mouse: item["group"] for mouse, item in mapping["assignments"].items()})
    grouped = df.dropna(subset=["group"]).groupby(["group", "period"])["n3_r"].mean().reset_index()
    for group in ["Sham", "Recovery", "No-Recovery"]:
        sub = grouped[grouped["group"] == group]
        y = [float(sub[sub["period"] == period]["n3_r"].mean()) if not sub[sub["period"] == period].empty else float("nan") for period in PERIOD_ORDER]
        plt.plot([PERIOD_LABELS[p] for p in PERIOD_ORDER], y, marker="o", label=group)
    plt.xlabel("Experimental period")
    plt.ylabel("Stable place-cell fraction (%)")
    plt.title("Stable place-cell fractions by recovery group")
    plt.legend(frameon=False)
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), "summary": place_cell_stability_summary(stable_csv_or_bundle, str(source) if source else None)}

def package_smoke_test() -> dict:
    root = Path(__file__).resolve().parents[1]
    source = root / "input_data" / "data" / "source_data.xlsx"
    code = root / "input_data" / "data" / "code_bundle" / "Wahl-lab-Heiser_BrainwideMicrostrokes-2bc9f98"
    art = root / "artifacts"
    return {
        "microspheres": microsphere_performance_summary(str(source)),
        "place_cell_stability": place_cell_stability_summary(str(code), str(source)),
        "behavior_trace": behavior_trace_summary(str(code)),
        "recovery": recovery_group_summary(str(source)),
        "figures": [plot_microsphere_vs_performance(str(source), str(art / "microsphere_vs_performance.png")), plot_recovery_groups(str(source), str(art / "recovery_group_trajectories.png")), plot_place_cell_stability(str(code), str(art / "place_cell_stability.png"), str(source))],
    }
