from __future__ import annotations

from pathlib import Path
import zipfile
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


STABLE_CSV_NAME = "place_cell_transitions/stable_unstable_classification.csv"
BEHAVIOR_CSV_NAME = "vr_behavior/behavior.csv"
GROUP_CSV_NAME = "experimental_groups/animal_groups.csv"
PERIOD_ORDER = ["pre", "early", "late"]
PERIOD_LABELS = {"pre": "Healthy", "early": "Early post", "late": "Late post"}


def _read_csv_from_bundle(path: str, member_suffix: str) -> pd.DataFrame:
    p = Path(path)
    if p.is_dir():
        matches = list(p.rglob(Path(member_suffix).name))
        matches = [m for m in matches if str(m).replace("\\", "/").endswith(member_suffix)]
        if not matches:
            raise FileNotFoundError(f"No {member_suffix} found under {p}")
        return pd.read_csv(matches[0])
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as zf:
            matches = [name for name in zf.namelist() if name.endswith(member_suffix)]
            if not matches:
                raise FileNotFoundError(f"No {member_suffix} found in {p}")
            with zf.open(matches[0]) as handle:
                return pd.read_csv(handle)
    return pd.read_csv(p)


def _figure1_panel_f(source_xlsx: str) -> pd.DataFrame:
    df = pd.read_excel(source_xlsx, sheet_name="Figure 1", header=None)
    vals = df.iloc[2:, [0, 1, 2, 3]].copy()
    vals.columns = ["microspheres", "healthy", "early_post", "late_post"]
    for col in vals.columns:
        vals[col] = pd.to_numeric(vals[col], errors="coerce")
    return vals.dropna(subset=["microspheres", "early_post"])


def _default_source_from_bundle(path: str) -> Path | None:
    p = Path(path)
    candidates = [
        p.parent / "source_data.xlsx",
        p.parents[1] / "source_data.xlsx" if len(p.parents) > 1 else p.parent / "source_data.xlsx",
        Path(__file__).resolve().parents[1] / "input_data" / "data" / "source_data.xlsx",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _figure3_panel_b_stable_groups(source_xlsx: str) -> list[dict]:
    raw = pd.read_excel(source_xlsx, sheet_name="Figure 3", header=None)
    header_row = raw.index[raw.iloc[:, 0].astype(str).str.strip().eq("Panel B")]
    if len(header_row) == 0:
        raise ValueError("Figure 3 Panel B header not found")
    start = int(header_row[0])
    group_labels = raw.iloc[start, :].ffill()
    period_rows = {"pre": start + 1, "early": start + 2, "late": start + 3}
    records = []
    for col in range(1, raw.shape[1]):
        group = str(group_labels.iloc[col]).strip()
        if group.lower() in {"nan", ""}:
            continue
        values = {
            period: pd.to_numeric(pd.Series([raw.iat[row, col]]), errors="coerce").iloc[0]
            for period, row in period_rows.items()
        }
        if all(pd.notna(v) for v in values.values()):
            records.append({"source_column": int(col), "group": group, **{k: float(v) for k, v in values.items()}})
    return records


def stability_group_mapping(source_xlsx: str, stable_csv_or_bundle: str) -> dict:
    stable = _read_csv_from_bundle(stable_csv_or_bundle, STABLE_CSV_NAME)
    for col in ["n3_r"]:
        stable[col] = pd.to_numeric(stable[col], errors="coerce")
    try:
        groups = _read_csv_from_bundle(stable_csv_or_bundle, GROUP_CSV_NAME)
        groups["mouse_id"] = groups["mouse_id"].astype(int).astype(str)
        fine = dict(zip(groups["mouse_id"], groups["fine"].astype(str)))
        assignments = {}
        for mouse_id in stable["mouse_id"].dropna().astype(str).unique():
            mouse_key = mouse_id.split("_")[0]
            if mouse_key in fine:
                group = fine[mouse_key].replace("Control", "Sham")
                assignments[mouse_id] = {"group": group, "source": GROUP_CSV_NAME}
        if assignments:
            return {
                "source": GROUP_CSV_NAME,
                "matched_mice": len(assignments),
                "assignments": assignments,
            }
    except FileNotFoundError:
        pass

    panel = _figure3_panel_b_stable_groups(source_xlsx)
    assignments = {}
    used_columns = set()
    for mouse_id, sub in stable.dropna(subset=["mouse_id"]).groupby("mouse_id"):
        triplet = {
            period: float(sub.loc[sub["period"] == period, "n3_r"].mean())
            for period in PERIOD_ORDER
            if (sub["period"] == period).any()
        }
        if len(triplet) != 3:
            continue
        best = None
        for record in panel:
            if record["source_column"] in used_columns:
                continue
            distance = sum(abs(record[period] - triplet[period]) for period in PERIOD_ORDER)
            if best is None or distance < best[0]:
                best = (distance, record)
        if best is not None and best[0] < 1e-3:
            used_columns.add(best[1]["source_column"])
            assignments[str(mouse_id)] = {"group": best[1]["group"], "source_column": best[1]["source_column"]}
    return {
        "source": str(source_xlsx),
        "matched_mice": len(assignments),
        "assignments": assignments,
    }


def microsphere_performance_summary(source_xlsx: str) -> dict:
    vals = _figure1_panel_f(source_xlsx)
    corr = np.corrcoef(vals["microspheres"].astype(float), vals["early_post"].astype(float))[0, 1]
    return {
        "rows": int(len(vals)),
        "microsphere_task_corr_early_post": float(corr),
        "median_microspheres": float(vals["microspheres"].median()),
        "early_post_mean": float(vals["early_post"].mean()),
        "late_post_mean": float(vals["late_post"].dropna().mean()),
    }


def place_cell_stability_summary(stable_csv_or_bundle: str, source_xlsx: str | None = None) -> dict:
    df = _read_csv_from_bundle(stable_csv_or_bundle, STABLE_CSV_NAME)
    for col in ["n1_r", "n2_r", "n3_r", "baseline_stability"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    grouped = df.groupby("period")[["n1_r", "n2_r", "n3_r", "baseline_stability"]].mean()
    grouped = grouped.reindex([p for p in PERIOD_ORDER if p in grouped.index])
    result = {
        "rows": int(len(df)),
        "periods": list(grouped.index),
        "class_labels": {
            "n1_r": "non-coding tracked cells",
            "n2_r": "unstable place cells",
            "n3_r": "stable place cells",
        },
        "class_fraction_means": {
            str(period): {
                "noncoding_n1_percent": float(row["n1_r"]),
                "unstable_place_cell_n2_percent": float(row["n2_r"]),
                "stable_place_cell_n3_percent": float(row["n3_r"]),
                "baseline_stability": float(row["baseline_stability"]),
            }
            for period, row in grouped.iterrows()
        },
    }
    source = Path(source_xlsx) if source_xlsx else _default_source_from_bundle(stable_csv_or_bundle)
    if source and source.exists():
        mapping = stability_group_mapping(str(source), stable_csv_or_bundle)
        df = df.copy()
        df["mouse_id"] = df["mouse_id"].astype(str)
        df["group"] = df["mouse_id"].map({mouse: item["group"] for mouse, item in mapping["assignments"].items()})
        group_df = df.dropna(subset=["group"]).groupby(["group", "period"])["n3_r"].mean().reset_index()
        result["group_mapping"] = mapping
        result["stable_place_cell_by_group"] = {
            group: {
                period: float(group_df[(group_df["group"] == group) & (group_df["period"] == period)]["n3_r"].mean())
                for period in PERIOD_ORDER
                if not group_df[(group_df["group"] == group) & (group_df["period"] == period)].empty
            }
            for group in sorted(group_df["group"].unique())
        }
    return result


def behavior_trace_summary(code_bundle: str) -> dict:
    df = _read_csv_from_bundle(code_bundle, BEHAVIOR_CSV_NAME)
    return {
        "rows": int(len(df)),
        "trials": int(df["trial_nb"].nunique()) if "trial_nb" in df else None,
        "duration_seconds": float(pd.to_numeric(df["time"], errors="coerce").max()) if "time" in df else None,
        "mean_speed": float(pd.to_numeric(df["speed"], errors="coerce").mean()) if "speed" in df else None,
    }


def recovery_group_summary(source_xlsx: str) -> dict:
    df = pd.read_excel(source_xlsx, sheet_name="Figure 3")
    vals = df.iloc[1:, [0, 1, 5, 10]].dropna()
    vals.columns = ["days", "no_recovery", "recovery", "sham"]
    for c in vals.columns:
        vals[c] = pd.to_numeric(vals[c], errors="coerce")
    vals = vals.dropna()
    return {
        "days": int(len(vals)),
        "recovery_mean": float(vals["recovery"].mean()),
        "no_recovery_mean": float(vals["no_recovery"].mean()),
        "sham_mean": float(vals["sham"].mean())
    }


def plot_microsphere_vs_performance(source_xlsx: str, output_path: str) -> dict:
    vals = _figure1_panel_f(source_xlsx)
    plt.figure(figsize=(5, 4))
    plt.scatter(vals["microspheres"], vals["early_post"], s=25, color="#4C78A8")
    plt.xlabel("Estimated microspheres")
    plt.ylabel("Early post-stroke task performance")
    plt.title("Microsphere burden versus early post-stroke behavior")
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": output_path, "summary": microsphere_performance_summary(source_xlsx)}


def plot_recovery_groups(source_xlsx: str, output_path: str) -> dict:
    df = pd.read_excel(source_xlsx, sheet_name="Figure 3")
    vals = df.iloc[1:, [0, 1, 5, 10]].dropna()
    vals.columns = ["days", "no_recovery", "recovery", "sham"]
    for c in vals.columns:
        vals[c] = pd.to_numeric(vals[c], errors="coerce")
    vals = vals.dropna()
    plt.figure(figsize=(6, 4))
    plt.plot(vals["days"], vals["no_recovery"], label="No recovery")
    plt.plot(vals["days"], vals["recovery"], label="Recovery")
    plt.plot(vals["days"], vals["sham"], label="Sham")
    plt.xlabel("Days after stroke")
    plt.ylabel("Task performance")
    plt.legend()
    plt.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=200)
    plt.close()
    return {"path": output_path}
# Strict reproduction additions: place-cell stability artifact and smoke test.
def plot_place_cell_stability(stable_csv_or_bundle: str, output_path: str, source_xlsx: str | None = None) -> dict:
    df = _read_csv_from_bundle(stable_csv_or_bundle, STABLE_CSV_NAME)
    for col in ["n1_r", "n2_r", "n3_r"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    source = Path(source_xlsx) if source_xlsx else _default_source_from_bundle(stable_csv_or_bundle)
    plt.figure(figsize=(6.8, 4.2))
    if source and source.exists():
        mapping = stability_group_mapping(str(source), stable_csv_or_bundle)
        df = df.copy()
        df["mouse_id"] = df["mouse_id"].astype(str)
        df["group"] = df["mouse_id"].map({mouse: item["group"] for mouse, item in mapping["assignments"].items()})
        grouped = df.dropna(subset=["group"]).groupby(["group", "period"])["n3_r"].mean().reset_index()
        for group in ["Sham", "Recovery", "No Recovery"]:
            sub = grouped[grouped["group"] == group]
            y = [float(sub[sub["period"] == period]["n3_r"].mean()) if not sub[sub["period"] == period].empty else float("nan") for period in PERIOD_ORDER]
            plt.plot([PERIOD_LABELS[p] for p in PERIOD_ORDER], y, marker="o", label=group)
    else:
        grouped = df.groupby("period")[["n3_r"]].mean().reindex(PERIOD_ORDER)
        plt.plot([PERIOD_LABELS[p] for p in grouped.index], grouped["n3_r"], marker="o", label="all mice")
    plt.xlabel("Experimental period")
    plt.ylabel("Stable place-cell fraction (%)")
    plt.title("Stable place-cell fractions by recovery group")
    plt.legend(frameon=False)
    plt.tight_layout()
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=200)
    plt.close()
    return {"path": str(out), "summary": place_cell_stability_summary(stable_csv_or_bundle, str(source) if source else None)}

def package_smoke_test() -> dict:
    root = Path(__file__).resolve().parents[1]
    source = root / "input_data" / "data" / "source_data.xlsx"
    code = root / "input_data" / "data" / "code_bundle" / "Wahl-lab-Heiser_BrainwideMicrostrokes-2bc9f98"
    art = root / "artifacts"
    return {
        "microspheres": microsphere_performance_summary(str(source)),
        "place_cell_stability": place_cell_stability_summary(str(code), str(source)),
        "behavior_trace": behavior_trace_summary(str(code)),
        "recovery": recovery_group_summary(str(source)),
        "figures": [plot_microsphere_vs_performance(str(source), str(art / "microsphere_vs_performance.png")), plot_recovery_groups(str(source), str(art / "recovery_group_trajectories.png")), plot_place_cell_stability(str(code), str(art / "place_cell_stability.png"), str(source))],
    }
