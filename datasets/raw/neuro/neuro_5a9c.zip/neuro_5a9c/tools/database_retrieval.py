from __future__ import annotations

from pathlib import Path
import subprocess

from .data_processing import list_files


def local_code_inventory(data_root: str) -> dict:
    return {
        "root": str(Path(data_root).resolve()),
        "files": list_files(data_root),
        "code_files": list_files(data_root, suffixes={".cpp", ".h", ".m", ".rtf", ".zip"}),
    }


def reference_inventory(reference_root: str) -> dict:
    return {
        "root": str(Path(reference_root).resolve()),
        "files": list_files(reference_root, suffixes={".pdf", ".html"}),
    }


def extract_pdf_text(path: str) -> dict:
    result = subprocess.run(["pdftotext", path, "-"], capture_output=True, text=True, check=True)
    return {"path": path, "text": result.stdout}


def find_pdf_lines(path: str, patterns: list[str]) -> dict:
    text = extract_pdf_text(path)["text"]
    matches = []
    for i, line in enumerate(text.splitlines(), start=1):
        lower = line.lower()
        for pattern in patterns:
            if pattern.lower() in lower:
                matches.append({"line_number": i, "pattern": pattern, "line": line.strip()})
                break
    return {"path": path, "patterns": patterns, "matches": matches}
