This tool directory is split into three layers:

- `data_processing.py`: generic local file helpers
- `database_retrieval.py`: local reference/code inventory and lightweight PDF text lookup
- `neuro_tools.py`: core analysis primitives for the released microstrokes workflow

The core tool file exposes:

- microsphere-load versus task-performance summaries
- place-cell stability summaries
- recovery-group comparisons
- artifact-generating plotting helpers
